/**
 * SemNetNameRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.query.sem;

public class SemNetNameRequest  extends gov.nih.nlm.kss.query.sem.SNExpansionRequest  implements java.io.Serializable {
    private boolean basicFlag;

    private java.lang.String networkName;

    public SemNetNameRequest() {
    }

    public SemNetNameRequest(
           java.lang.String casTicket,
           java.lang.String release,
           boolean expansionFlag,
           int expansionLevel,
           boolean basicFlag,
           java.lang.String networkName) {
        super(
            casTicket,
            release,
            expansionFlag,
            expansionLevel);
        this.basicFlag = basicFlag;
        this.networkName = networkName;
    }


    /**
     * Gets the basicFlag value for this SemNetNameRequest.
     * 
     * @return basicFlag
     */
    public boolean isBasicFlag() {
        return basicFlag;
    }


    /**
     * Sets the basicFlag value for this SemNetNameRequest.
     * 
     * @param basicFlag
     */
    public void setBasicFlag(boolean basicFlag) {
        this.basicFlag = basicFlag;
    }


    /**
     * Gets the networkName value for this SemNetNameRequest.
     * 
     * @return networkName
     */
    public java.lang.String getNetworkName() {
        return networkName;
    }


    /**
     * Sets the networkName value for this SemNetNameRequest.
     * 
     * @param networkName
     */
    public void setNetworkName(java.lang.String networkName) {
        this.networkName = networkName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SemNetNameRequest)) return false;
        SemNetNameRequest other = (SemNetNameRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.basicFlag == other.isBasicFlag() &&
            ((this.networkName==null && other.getNetworkName()==null) || 
             (this.networkName!=null &&
              this.networkName.equals(other.getNetworkName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isBasicFlag() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getNetworkName() != null) {
            _hashCode += getNetworkName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SemNetNameRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemNetNameRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("basicFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "basicFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("networkName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "networkName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
