/**
 * AuthorizationPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.umlsks.authorization;

public interface AuthorizationPortType extends java.rmi.Remote {
    public java.lang.String getProxyGrantTicket(java.lang.String in0, java.lang.String in1) throws java.rmi.RemoteException;
    public java.lang.String getProxyTicket(java.lang.String in0, java.lang.String in1) throws java.rmi.RemoteException;
    public java.lang.String validateProxyTicket(java.lang.String in0, java.lang.String in1) throws java.rmi.RemoteException;
}
