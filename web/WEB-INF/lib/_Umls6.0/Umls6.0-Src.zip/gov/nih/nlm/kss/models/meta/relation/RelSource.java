/**
 * RelSource.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.relation;

public class RelSource  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String AUI;

    private java.lang.String CN;

    private java.lang.String CUI;

    private java.lang.String RUI;

    private java.lang.String SRUI;

    private java.lang.String autoGen;

    private boolean directionality;

    private java.lang.String rel;

    private java.lang.String relA;

    private java.lang.String type;

    public RelSource() {
    }

    public RelSource(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String AUI,
           java.lang.String CN,
           java.lang.String CUI,
           java.lang.String RUI,
           java.lang.String SRUI,
           java.lang.String autoGen,
           boolean directionality,
           java.lang.String rel,
           java.lang.String relA,
           java.lang.String type) {
        super(
            key,
            performanceMode);
        this.AUI = AUI;
        this.CN = CN;
        this.CUI = CUI;
        this.RUI = RUI;
        this.SRUI = SRUI;
        this.autoGen = autoGen;
        this.directionality = directionality;
        this.rel = rel;
        this.relA = relA;
        this.type = type;
    }


    /**
     * Gets the AUI value for this RelSource.
     * 
     * @return AUI
     */
    public java.lang.String getAUI() {
        return AUI;
    }


    /**
     * Sets the AUI value for this RelSource.
     * 
     * @param AUI
     */
    public void setAUI(java.lang.String AUI) {
        this.AUI = AUI;
    }


    /**
     * Gets the CN value for this RelSource.
     * 
     * @return CN
     */
    public java.lang.String getCN() {
        return CN;
    }


    /**
     * Sets the CN value for this RelSource.
     * 
     * @param CN
     */
    public void setCN(java.lang.String CN) {
        this.CN = CN;
    }


    /**
     * Gets the CUI value for this RelSource.
     * 
     * @return CUI
     */
    public java.lang.String getCUI() {
        return CUI;
    }


    /**
     * Sets the CUI value for this RelSource.
     * 
     * @param CUI
     */
    public void setCUI(java.lang.String CUI) {
        this.CUI = CUI;
    }


    /**
     * Gets the RUI value for this RelSource.
     * 
     * @return RUI
     */
    public java.lang.String getRUI() {
        return RUI;
    }


    /**
     * Sets the RUI value for this RelSource.
     * 
     * @param RUI
     */
    public void setRUI(java.lang.String RUI) {
        this.RUI = RUI;
    }


    /**
     * Gets the SRUI value for this RelSource.
     * 
     * @return SRUI
     */
    public java.lang.String getSRUI() {
        return SRUI;
    }


    /**
     * Sets the SRUI value for this RelSource.
     * 
     * @param SRUI
     */
    public void setSRUI(java.lang.String SRUI) {
        this.SRUI = SRUI;
    }


    /**
     * Gets the autoGen value for this RelSource.
     * 
     * @return autoGen
     */
    public java.lang.String getAutoGen() {
        return autoGen;
    }


    /**
     * Sets the autoGen value for this RelSource.
     * 
     * @param autoGen
     */
    public void setAutoGen(java.lang.String autoGen) {
        this.autoGen = autoGen;
    }


    /**
     * Gets the directionality value for this RelSource.
     * 
     * @return directionality
     */
    public boolean isDirectionality() {
        return directionality;
    }


    /**
     * Sets the directionality value for this RelSource.
     * 
     * @param directionality
     */
    public void setDirectionality(boolean directionality) {
        this.directionality = directionality;
    }


    /**
     * Gets the rel value for this RelSource.
     * 
     * @return rel
     */
    public java.lang.String getRel() {
        return rel;
    }


    /**
     * Sets the rel value for this RelSource.
     * 
     * @param rel
     */
    public void setRel(java.lang.String rel) {
        this.rel = rel;
    }


    /**
     * Gets the relA value for this RelSource.
     * 
     * @return relA
     */
    public java.lang.String getRelA() {
        return relA;
    }


    /**
     * Sets the relA value for this RelSource.
     * 
     * @param relA
     */
    public void setRelA(java.lang.String relA) {
        this.relA = relA;
    }


    /**
     * Gets the type value for this RelSource.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this RelSource.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RelSource)) return false;
        RelSource other = (RelSource) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.AUI==null && other.getAUI()==null) || 
             (this.AUI!=null &&
              this.AUI.equals(other.getAUI()))) &&
            ((this.CN==null && other.getCN()==null) || 
             (this.CN!=null &&
              this.CN.equals(other.getCN()))) &&
            ((this.CUI==null && other.getCUI()==null) || 
             (this.CUI!=null &&
              this.CUI.equals(other.getCUI()))) &&
            ((this.RUI==null && other.getRUI()==null) || 
             (this.RUI!=null &&
              this.RUI.equals(other.getRUI()))) &&
            ((this.SRUI==null && other.getSRUI()==null) || 
             (this.SRUI!=null &&
              this.SRUI.equals(other.getSRUI()))) &&
            ((this.autoGen==null && other.getAutoGen()==null) || 
             (this.autoGen!=null &&
              this.autoGen.equals(other.getAutoGen()))) &&
            this.directionality == other.isDirectionality() &&
            ((this.rel==null && other.getRel()==null) || 
             (this.rel!=null &&
              this.rel.equals(other.getRel()))) &&
            ((this.relA==null && other.getRelA()==null) || 
             (this.relA!=null &&
              this.relA.equals(other.getRelA()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAUI() != null) {
            _hashCode += getAUI().hashCode();
        }
        if (getCN() != null) {
            _hashCode += getCN().hashCode();
        }
        if (getCUI() != null) {
            _hashCode += getCUI().hashCode();
        }
        if (getRUI() != null) {
            _hashCode += getRUI().hashCode();
        }
        if (getSRUI() != null) {
            _hashCode += getSRUI().hashCode();
        }
        if (getAutoGen() != null) {
            _hashCode += getAutoGen().hashCode();
        }
        _hashCode += (isDirectionality() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getRel() != null) {
            _hashCode += getRel().hashCode();
        }
        if (getRelA() != null) {
            _hashCode += getRelA().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RelSource.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://relation.meta.models.kss.nlm.nih.gov", "RelSource"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SRUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SRUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("autoGen");
        elemField.setXmlName(new javax.xml.namespace.QName("", "autoGen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("directionality");
        elemField.setXmlName(new javax.xml.namespace.QName("", "directionality"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relA");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
