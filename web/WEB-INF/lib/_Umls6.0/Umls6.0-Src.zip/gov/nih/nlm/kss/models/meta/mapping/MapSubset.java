/**
 * MapSubset.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.mapping;

public class MapSubset  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private gov.nih.nlm.kss.models.meta.mapping.MappedRelation[] mappedRelations;

    private java.lang.String subsetId;

    public MapSubset() {
    }

    public MapSubset(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.models.meta.mapping.MappedRelation[] mappedRelations,
           java.lang.String subsetId) {
        super(
            key,
            performanceMode);
        this.mappedRelations = mappedRelations;
        this.subsetId = subsetId;
    }


    /**
     * Gets the mappedRelations value for this MapSubset.
     * 
     * @return mappedRelations
     */
    public gov.nih.nlm.kss.models.meta.mapping.MappedRelation[] getMappedRelations() {
        return mappedRelations;
    }


    /**
     * Sets the mappedRelations value for this MapSubset.
     * 
     * @param mappedRelations
     */
    public void setMappedRelations(gov.nih.nlm.kss.models.meta.mapping.MappedRelation[] mappedRelations) {
        this.mappedRelations = mappedRelations;
    }


    /**
     * Gets the subsetId value for this MapSubset.
     * 
     * @return subsetId
     */
    public java.lang.String getSubsetId() {
        return subsetId;
    }


    /**
     * Sets the subsetId value for this MapSubset.
     * 
     * @param subsetId
     */
    public void setSubsetId(java.lang.String subsetId) {
        this.subsetId = subsetId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MapSubset)) return false;
        MapSubset other = (MapSubset) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.mappedRelations==null && other.getMappedRelations()==null) || 
             (this.mappedRelations!=null &&
              java.util.Arrays.equals(this.mappedRelations, other.getMappedRelations()))) &&
            ((this.subsetId==null && other.getSubsetId()==null) || 
             (this.subsetId!=null &&
              this.subsetId.equals(other.getSubsetId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getMappedRelations() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMappedRelations());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMappedRelations(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSubsetId() != null) {
            _hashCode += getSubsetId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MapSubset.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapSubset"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mappedRelations");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mappedRelations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MappedRelation"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subsetId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subsetId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
