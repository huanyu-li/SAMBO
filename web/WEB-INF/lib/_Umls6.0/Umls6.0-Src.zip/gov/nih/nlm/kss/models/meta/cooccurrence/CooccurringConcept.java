/**
 * CooccurringConcept.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.cooccurrence;

public class CooccurringConcept  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String AUI1;

    private java.lang.String CN2;

    private java.lang.String CUI2;

    private gov.nih.nlm.kss.models.meta.cooccurrence.COContext[] coContexts;

    public CooccurringConcept() {
    }

    public CooccurringConcept(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String AUI1,
           java.lang.String CN2,
           java.lang.String CUI2,
           gov.nih.nlm.kss.models.meta.cooccurrence.COContext[] coContexts) {
        super(
            key,
            performanceMode);
        this.AUI1 = AUI1;
        this.CN2 = CN2;
        this.CUI2 = CUI2;
        this.coContexts = coContexts;
    }


    /**
     * Gets the AUI1 value for this CooccurringConcept.
     * 
     * @return AUI1
     */
    public java.lang.String getAUI1() {
        return AUI1;
    }


    /**
     * Sets the AUI1 value for this CooccurringConcept.
     * 
     * @param AUI1
     */
    public void setAUI1(java.lang.String AUI1) {
        this.AUI1 = AUI1;
    }


    /**
     * Gets the CN2 value for this CooccurringConcept.
     * 
     * @return CN2
     */
    public java.lang.String getCN2() {
        return CN2;
    }


    /**
     * Sets the CN2 value for this CooccurringConcept.
     * 
     * @param CN2
     */
    public void setCN2(java.lang.String CN2) {
        this.CN2 = CN2;
    }


    /**
     * Gets the CUI2 value for this CooccurringConcept.
     * 
     * @return CUI2
     */
    public java.lang.String getCUI2() {
        return CUI2;
    }


    /**
     * Sets the CUI2 value for this CooccurringConcept.
     * 
     * @param CUI2
     */
    public void setCUI2(java.lang.String CUI2) {
        this.CUI2 = CUI2;
    }


    /**
     * Gets the coContexts value for this CooccurringConcept.
     * 
     * @return coContexts
     */
    public gov.nih.nlm.kss.models.meta.cooccurrence.COContext[] getCoContexts() {
        return coContexts;
    }


    /**
     * Sets the coContexts value for this CooccurringConcept.
     * 
     * @param coContexts
     */
    public void setCoContexts(gov.nih.nlm.kss.models.meta.cooccurrence.COContext[] coContexts) {
        this.coContexts = coContexts;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CooccurringConcept)) return false;
        CooccurringConcept other = (CooccurringConcept) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.AUI1==null && other.getAUI1()==null) || 
             (this.AUI1!=null &&
              this.AUI1.equals(other.getAUI1()))) &&
            ((this.CN2==null && other.getCN2()==null) || 
             (this.CN2!=null &&
              this.CN2.equals(other.getCN2()))) &&
            ((this.CUI2==null && other.getCUI2()==null) || 
             (this.CUI2!=null &&
              this.CUI2.equals(other.getCUI2()))) &&
            ((this.coContexts==null && other.getCoContexts()==null) || 
             (this.coContexts!=null &&
              java.util.Arrays.equals(this.coContexts, other.getCoContexts())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAUI1() != null) {
            _hashCode += getAUI1().hashCode();
        }
        if (getCN2() != null) {
            _hashCode += getCN2().hashCode();
        }
        if (getCUI2() != null) {
            _hashCode += getCUI2().hashCode();
        }
        if (getCoContexts() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCoContexts());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCoContexts(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CooccurringConcept.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cooccurrence.meta.models.kss.nlm.nih.gov", "CooccurringConcept"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AUI1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AUI1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CN2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CN2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUI2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CUI2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("coContexts");
        elemField.setXmlName(new javax.xml.namespace.QName("", "coContexts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://cooccurrence.meta.models.kss.nlm.nih.gov", "COContext"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
