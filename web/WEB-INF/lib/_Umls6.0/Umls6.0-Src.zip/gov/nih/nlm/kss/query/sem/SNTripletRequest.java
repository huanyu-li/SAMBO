/**
 * SNTripletRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.query.sem;

public class SNTripletRequest  extends gov.nih.nlm.kss.query.ReleaseInputRequest  implements java.io.Serializable {
    private java.lang.String LName;

    private java.lang.String RName;

    private java.lang.String relation;

    public SNTripletRequest() {
    }

    public SNTripletRequest(
           java.lang.String casTicket,
           java.lang.String release,
           java.lang.String LName,
           java.lang.String RName,
           java.lang.String relation) {
        super(
            casTicket,
            release);
        this.LName = LName;
        this.RName = RName;
        this.relation = relation;
    }


    /**
     * Gets the LName value for this SNTripletRequest.
     * 
     * @return LName
     */
    public java.lang.String getLName() {
        return LName;
    }


    /**
     * Sets the LName value for this SNTripletRequest.
     * 
     * @param LName
     */
    public void setLName(java.lang.String LName) {
        this.LName = LName;
    }


    /**
     * Gets the RName value for this SNTripletRequest.
     * 
     * @return RName
     */
    public java.lang.String getRName() {
        return RName;
    }


    /**
     * Sets the RName value for this SNTripletRequest.
     * 
     * @param RName
     */
    public void setRName(java.lang.String RName) {
        this.RName = RName;
    }


    /**
     * Gets the relation value for this SNTripletRequest.
     * 
     * @return relation
     */
    public java.lang.String getRelation() {
        return relation;
    }


    /**
     * Sets the relation value for this SNTripletRequest.
     * 
     * @param relation
     */
    public void setRelation(java.lang.String relation) {
        this.relation = relation;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SNTripletRequest)) return false;
        SNTripletRequest other = (SNTripletRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.LName==null && other.getLName()==null) || 
             (this.LName!=null &&
              this.LName.equals(other.getLName()))) &&
            ((this.RName==null && other.getRName()==null) || 
             (this.RName!=null &&
              this.RName.equals(other.getRName()))) &&
            ((this.relation==null && other.getRelation()==null) || 
             (this.relation!=null &&
              this.relation.equals(other.getRelation())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLName() != null) {
            _hashCode += getLName().hashCode();
        }
        if (getRName() != null) {
            _hashCode += getRName().hashCode();
        }
        if (getRelation() != null) {
            _hashCode += getRelation().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SNTripletRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SNTripletRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "LName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
