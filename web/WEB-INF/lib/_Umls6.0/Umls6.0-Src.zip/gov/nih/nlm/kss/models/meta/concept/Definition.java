/**
 * Definition.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.concept;

public class Definition  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String ATUI;

    private java.lang.String AUI;

    private java.lang.String DEF;

    private java.lang.String SAB;

    private java.lang.String SATUI;

    public Definition() {
    }

    public Definition(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String ATUI,
           java.lang.String AUI,
           java.lang.String DEF,
           java.lang.String SAB,
           java.lang.String SATUI) {
        super(
            key,
            performanceMode);
        this.ATUI = ATUI;
        this.AUI = AUI;
        this.DEF = DEF;
        this.SAB = SAB;
        this.SATUI = SATUI;
    }


    /**
     * Gets the ATUI value for this Definition.
     * 
     * @return ATUI
     */
    public java.lang.String getATUI() {
        return ATUI;
    }


    /**
     * Sets the ATUI value for this Definition.
     * 
     * @param ATUI
     */
    public void setATUI(java.lang.String ATUI) {
        this.ATUI = ATUI;
    }


    /**
     * Gets the AUI value for this Definition.
     * 
     * @return AUI
     */
    public java.lang.String getAUI() {
        return AUI;
    }


    /**
     * Sets the AUI value for this Definition.
     * 
     * @param AUI
     */
    public void setAUI(java.lang.String AUI) {
        this.AUI = AUI;
    }


    /**
     * Gets the DEF value for this Definition.
     * 
     * @return DEF
     */
    public java.lang.String getDEF() {
        return DEF;
    }


    /**
     * Sets the DEF value for this Definition.
     * 
     * @param DEF
     */
    public void setDEF(java.lang.String DEF) {
        this.DEF = DEF;
    }


    /**
     * Gets the SAB value for this Definition.
     * 
     * @return SAB
     */
    public java.lang.String getSAB() {
        return SAB;
    }


    /**
     * Sets the SAB value for this Definition.
     * 
     * @param SAB
     */
    public void setSAB(java.lang.String SAB) {
        this.SAB = SAB;
    }


    /**
     * Gets the SATUI value for this Definition.
     * 
     * @return SATUI
     */
    public java.lang.String getSATUI() {
        return SATUI;
    }


    /**
     * Sets the SATUI value for this Definition.
     * 
     * @param SATUI
     */
    public void setSATUI(java.lang.String SATUI) {
        this.SATUI = SATUI;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Definition)) return false;
        Definition other = (Definition) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.ATUI==null && other.getATUI()==null) || 
             (this.ATUI!=null &&
              this.ATUI.equals(other.getATUI()))) &&
            ((this.AUI==null && other.getAUI()==null) || 
             (this.AUI!=null &&
              this.AUI.equals(other.getAUI()))) &&
            ((this.DEF==null && other.getDEF()==null) || 
             (this.DEF!=null &&
              this.DEF.equals(other.getDEF()))) &&
            ((this.SAB==null && other.getSAB()==null) || 
             (this.SAB!=null &&
              this.SAB.equals(other.getSAB()))) &&
            ((this.SATUI==null && other.getSATUI()==null) || 
             (this.SATUI!=null &&
              this.SATUI.equals(other.getSATUI())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getATUI() != null) {
            _hashCode += getATUI().hashCode();
        }
        if (getAUI() != null) {
            _hashCode += getAUI().hashCode();
        }
        if (getDEF() != null) {
            _hashCode += getDEF().hashCode();
        }
        if (getSAB() != null) {
            _hashCode += getSAB().hashCode();
        }
        if (getSATUI() != null) {
            _hashCode += getSATUI().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Definition.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "Definition"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ATUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ATUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DEF");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DEF"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAB");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SAB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SATUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SATUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
