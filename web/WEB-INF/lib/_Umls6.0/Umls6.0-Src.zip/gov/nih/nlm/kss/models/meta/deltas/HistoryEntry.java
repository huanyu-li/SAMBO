/**
 * HistoryEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.deltas;

public class HistoryEntry  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String CUI;

    private java.lang.String changeKey;

    private java.lang.String changeType;

    private java.lang.String reason;

    private java.lang.String sourceVersion;

    private java.lang.String value;

    public HistoryEntry() {
    }

    public HistoryEntry(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String CUI,
           java.lang.String changeKey,
           java.lang.String changeType,
           java.lang.String reason,
           java.lang.String sourceVersion,
           java.lang.String value) {
        super(
            key,
            performanceMode);
        this.CUI = CUI;
        this.changeKey = changeKey;
        this.changeType = changeType;
        this.reason = reason;
        this.sourceVersion = sourceVersion;
        this.value = value;
    }


    /**
     * Gets the CUI value for this HistoryEntry.
     * 
     * @return CUI
     */
    public java.lang.String getCUI() {
        return CUI;
    }


    /**
     * Sets the CUI value for this HistoryEntry.
     * 
     * @param CUI
     */
    public void setCUI(java.lang.String CUI) {
        this.CUI = CUI;
    }


    /**
     * Gets the changeKey value for this HistoryEntry.
     * 
     * @return changeKey
     */
    public java.lang.String getChangeKey() {
        return changeKey;
    }


    /**
     * Sets the changeKey value for this HistoryEntry.
     * 
     * @param changeKey
     */
    public void setChangeKey(java.lang.String changeKey) {
        this.changeKey = changeKey;
    }


    /**
     * Gets the changeType value for this HistoryEntry.
     * 
     * @return changeType
     */
    public java.lang.String getChangeType() {
        return changeType;
    }


    /**
     * Sets the changeType value for this HistoryEntry.
     * 
     * @param changeType
     */
    public void setChangeType(java.lang.String changeType) {
        this.changeType = changeType;
    }


    /**
     * Gets the reason value for this HistoryEntry.
     * 
     * @return reason
     */
    public java.lang.String getReason() {
        return reason;
    }


    /**
     * Sets the reason value for this HistoryEntry.
     * 
     * @param reason
     */
    public void setReason(java.lang.String reason) {
        this.reason = reason;
    }


    /**
     * Gets the sourceVersion value for this HistoryEntry.
     * 
     * @return sourceVersion
     */
    public java.lang.String getSourceVersion() {
        return sourceVersion;
    }


    /**
     * Sets the sourceVersion value for this HistoryEntry.
     * 
     * @param sourceVersion
     */
    public void setSourceVersion(java.lang.String sourceVersion) {
        this.sourceVersion = sourceVersion;
    }


    /**
     * Gets the value value for this HistoryEntry.
     * 
     * @return value
     */
    public java.lang.String getValue() {
        return value;
    }


    /**
     * Sets the value value for this HistoryEntry.
     * 
     * @param value
     */
    public void setValue(java.lang.String value) {
        this.value = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HistoryEntry)) return false;
        HistoryEntry other = (HistoryEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.CUI==null && other.getCUI()==null) || 
             (this.CUI!=null &&
              this.CUI.equals(other.getCUI()))) &&
            ((this.changeKey==null && other.getChangeKey()==null) || 
             (this.changeKey!=null &&
              this.changeKey.equals(other.getChangeKey()))) &&
            ((this.changeType==null && other.getChangeType()==null) || 
             (this.changeType!=null &&
              this.changeType.equals(other.getChangeType()))) &&
            ((this.reason==null && other.getReason()==null) || 
             (this.reason!=null &&
              this.reason.equals(other.getReason()))) &&
            ((this.sourceVersion==null && other.getSourceVersion()==null) || 
             (this.sourceVersion!=null &&
              this.sourceVersion.equals(other.getSourceVersion()))) &&
            ((this.value==null && other.getValue()==null) || 
             (this.value!=null &&
              this.value.equals(other.getValue())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCUI() != null) {
            _hashCode += getCUI().hashCode();
        }
        if (getChangeKey() != null) {
            _hashCode += getChangeKey().hashCode();
        }
        if (getChangeType() != null) {
            _hashCode += getChangeType().hashCode();
        }
        if (getReason() != null) {
            _hashCode += getReason().hashCode();
        }
        if (getSourceVersion() != null) {
            _hashCode += getSourceVersion().hashCode();
        }
        if (getValue() != null) {
            _hashCode += getValue().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HistoryEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "HistoryEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("changeKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "changeKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("changeType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "changeType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reason");
        elemField.setXmlName(new javax.xml.namespace.QName("", "reason"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sourceVersion");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sourceVersion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("", "value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
