/**
 * RawRecordsRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.query;

public class RawRecordsRequest  extends gov.nih.nlm.kss.query.ReleaseInputRequest  implements java.io.Serializable {
    private java.lang.String restrictionSQL;

    private java.lang.String table;

    public RawRecordsRequest() {
    }

    public RawRecordsRequest(
           java.lang.String casTicket,
           java.lang.String release,
           java.lang.String restrictionSQL,
           java.lang.String table) {
        super(
            casTicket,
            release);
        this.restrictionSQL = restrictionSQL;
        this.table = table;
    }


    /**
     * Gets the restrictionSQL value for this RawRecordsRequest.
     * 
     * @return restrictionSQL
     */
    public java.lang.String getRestrictionSQL() {
        return restrictionSQL;
    }


    /**
     * Sets the restrictionSQL value for this RawRecordsRequest.
     * 
     * @param restrictionSQL
     */
    public void setRestrictionSQL(java.lang.String restrictionSQL) {
        this.restrictionSQL = restrictionSQL;
    }


    /**
     * Gets the table value for this RawRecordsRequest.
     * 
     * @return table
     */
    public java.lang.String getTable() {
        return table;
    }


    /**
     * Sets the table value for this RawRecordsRequest.
     * 
     * @param table
     */
    public void setTable(java.lang.String table) {
        this.table = table;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RawRecordsRequest)) return false;
        RawRecordsRequest other = (RawRecordsRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.restrictionSQL==null && other.getRestrictionSQL()==null) || 
             (this.restrictionSQL!=null &&
              this.restrictionSQL.equals(other.getRestrictionSQL()))) &&
            ((this.table==null && other.getTable()==null) || 
             (this.table!=null &&
              this.table.equals(other.getTable())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getRestrictionSQL() != null) {
            _hashCode += getRestrictionSQL().hashCode();
        }
        if (getTable() != null) {
            _hashCode += getTable().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RawRecordsRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "RawRecordsRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("restrictionSQL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "restrictionSQL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("table");
        elemField.setXmlName(new javax.xml.namespace.QName("", "table"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
