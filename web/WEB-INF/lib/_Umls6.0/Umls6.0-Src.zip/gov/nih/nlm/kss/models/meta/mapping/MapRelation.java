/**
 * MapRelation.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.mapping;

public class MapRelation  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String relation;

    private java.lang.String relationAttribute;

    public MapRelation() {
    }

    public MapRelation(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String relation,
           java.lang.String relationAttribute) {
        super(
            key,
            performanceMode);
        this.relation = relation;
        this.relationAttribute = relationAttribute;
    }


    /**
     * Gets the relation value for this MapRelation.
     * 
     * @return relation
     */
    public java.lang.String getRelation() {
        return relation;
    }


    /**
     * Sets the relation value for this MapRelation.
     * 
     * @param relation
     */
    public void setRelation(java.lang.String relation) {
        this.relation = relation;
    }


    /**
     * Gets the relationAttribute value for this MapRelation.
     * 
     * @return relationAttribute
     */
    public java.lang.String getRelationAttribute() {
        return relationAttribute;
    }


    /**
     * Sets the relationAttribute value for this MapRelation.
     * 
     * @param relationAttribute
     */
    public void setRelationAttribute(java.lang.String relationAttribute) {
        this.relationAttribute = relationAttribute;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MapRelation)) return false;
        MapRelation other = (MapRelation) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.relation==null && other.getRelation()==null) || 
             (this.relation!=null &&
              this.relation.equals(other.getRelation()))) &&
            ((this.relationAttribute==null && other.getRelationAttribute()==null) || 
             (this.relationAttribute!=null &&
              this.relationAttribute.equals(other.getRelationAttribute())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getRelation() != null) {
            _hashCode += getRelation().hashCode();
        }
        if (getRelationAttribute() != null) {
            _hashCode += getRelationAttribute().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MapRelation.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapRelation"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relationAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relationAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
