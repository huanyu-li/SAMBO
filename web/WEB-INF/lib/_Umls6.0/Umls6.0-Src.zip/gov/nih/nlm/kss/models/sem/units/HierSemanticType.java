/**
 * HierSemanticType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.sem.units;

public class HierSemanticType  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String NHFlag;

    private java.lang.String UI;

    private java.lang.String abbrev;

    private gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup children;

    private java.lang.String[] childrenUIs;

    private java.lang.String def;

    private java.lang.String[] examples;

    private boolean expanded;

    private java.lang.String name;

    private java.lang.String parentUI;

    private java.lang.String treeNum;

    private java.lang.String usage;

    public HierSemanticType() {
    }

    public HierSemanticType(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String NHFlag,
           java.lang.String UI,
           java.lang.String abbrev,
           gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup children,
           java.lang.String[] childrenUIs,
           java.lang.String def,
           java.lang.String[] examples,
           boolean expanded,
           java.lang.String name,
           java.lang.String parentUI,
           java.lang.String treeNum,
           java.lang.String usage) {
        super(
            key,
            performanceMode);
        this.NHFlag = NHFlag;
        this.UI = UI;
        this.abbrev = abbrev;
        this.children = children;
        this.childrenUIs = childrenUIs;
        this.def = def;
        this.examples = examples;
        this.expanded = expanded;
        this.name = name;
        this.parentUI = parentUI;
        this.treeNum = treeNum;
        this.usage = usage;
    }


    /**
     * Gets the NHFlag value for this HierSemanticType.
     * 
     * @return NHFlag
     */
    public java.lang.String getNHFlag() {
        return NHFlag;
    }


    /**
     * Sets the NHFlag value for this HierSemanticType.
     * 
     * @param NHFlag
     */
    public void setNHFlag(java.lang.String NHFlag) {
        this.NHFlag = NHFlag;
    }


    /**
     * Gets the UI value for this HierSemanticType.
     * 
     * @return UI
     */
    public java.lang.String getUI() {
        return UI;
    }


    /**
     * Sets the UI value for this HierSemanticType.
     * 
     * @param UI
     */
    public void setUI(java.lang.String UI) {
        this.UI = UI;
    }


    /**
     * Gets the abbrev value for this HierSemanticType.
     * 
     * @return abbrev
     */
    public java.lang.String getAbbrev() {
        return abbrev;
    }


    /**
     * Sets the abbrev value for this HierSemanticType.
     * 
     * @param abbrev
     */
    public void setAbbrev(java.lang.String abbrev) {
        this.abbrev = abbrev;
    }


    /**
     * Gets the children value for this HierSemanticType.
     * 
     * @return children
     */
    public gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup getChildren() {
        return children;
    }


    /**
     * Sets the children value for this HierSemanticType.
     * 
     * @param children
     */
    public void setChildren(gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup children) {
        this.children = children;
    }


    /**
     * Gets the childrenUIs value for this HierSemanticType.
     * 
     * @return childrenUIs
     */
    public java.lang.String[] getChildrenUIs() {
        return childrenUIs;
    }


    /**
     * Sets the childrenUIs value for this HierSemanticType.
     * 
     * @param childrenUIs
     */
    public void setChildrenUIs(java.lang.String[] childrenUIs) {
        this.childrenUIs = childrenUIs;
    }


    /**
     * Gets the def value for this HierSemanticType.
     * 
     * @return def
     */
    public java.lang.String getDef() {
        return def;
    }


    /**
     * Sets the def value for this HierSemanticType.
     * 
     * @param def
     */
    public void setDef(java.lang.String def) {
        this.def = def;
    }


    /**
     * Gets the examples value for this HierSemanticType.
     * 
     * @return examples
     */
    public java.lang.String[] getExamples() {
        return examples;
    }


    /**
     * Sets the examples value for this HierSemanticType.
     * 
     * @param examples
     */
    public void setExamples(java.lang.String[] examples) {
        this.examples = examples;
    }


    /**
     * Gets the expanded value for this HierSemanticType.
     * 
     * @return expanded
     */
    public boolean isExpanded() {
        return expanded;
    }


    /**
     * Sets the expanded value for this HierSemanticType.
     * 
     * @param expanded
     */
    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }


    /**
     * Gets the name value for this HierSemanticType.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this HierSemanticType.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the parentUI value for this HierSemanticType.
     * 
     * @return parentUI
     */
    public java.lang.String getParentUI() {
        return parentUI;
    }


    /**
     * Sets the parentUI value for this HierSemanticType.
     * 
     * @param parentUI
     */
    public void setParentUI(java.lang.String parentUI) {
        this.parentUI = parentUI;
    }


    /**
     * Gets the treeNum value for this HierSemanticType.
     * 
     * @return treeNum
     */
    public java.lang.String getTreeNum() {
        return treeNum;
    }


    /**
     * Sets the treeNum value for this HierSemanticType.
     * 
     * @param treeNum
     */
    public void setTreeNum(java.lang.String treeNum) {
        this.treeNum = treeNum;
    }


    /**
     * Gets the usage value for this HierSemanticType.
     * 
     * @return usage
     */
    public java.lang.String getUsage() {
        return usage;
    }


    /**
     * Sets the usage value for this HierSemanticType.
     * 
     * @param usage
     */
    public void setUsage(java.lang.String usage) {
        this.usage = usage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HierSemanticType)) return false;
        HierSemanticType other = (HierSemanticType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.NHFlag==null && other.getNHFlag()==null) || 
             (this.NHFlag!=null &&
              this.NHFlag.equals(other.getNHFlag()))) &&
            ((this.UI==null && other.getUI()==null) || 
             (this.UI!=null &&
              this.UI.equals(other.getUI()))) &&
            ((this.abbrev==null && other.getAbbrev()==null) || 
             (this.abbrev!=null &&
              this.abbrev.equals(other.getAbbrev()))) &&
            ((this.children==null && other.getChildren()==null) || 
             (this.children!=null &&
              this.children.equals(other.getChildren()))) &&
            ((this.childrenUIs==null && other.getChildrenUIs()==null) || 
             (this.childrenUIs!=null &&
              java.util.Arrays.equals(this.childrenUIs, other.getChildrenUIs()))) &&
            ((this.def==null && other.getDef()==null) || 
             (this.def!=null &&
              this.def.equals(other.getDef()))) &&
            ((this.examples==null && other.getExamples()==null) || 
             (this.examples!=null &&
              java.util.Arrays.equals(this.examples, other.getExamples()))) &&
            this.expanded == other.isExpanded() &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.parentUI==null && other.getParentUI()==null) || 
             (this.parentUI!=null &&
              this.parentUI.equals(other.getParentUI()))) &&
            ((this.treeNum==null && other.getTreeNum()==null) || 
             (this.treeNum!=null &&
              this.treeNum.equals(other.getTreeNum()))) &&
            ((this.usage==null && other.getUsage()==null) || 
             (this.usage!=null &&
              this.usage.equals(other.getUsage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getNHFlag() != null) {
            _hashCode += getNHFlag().hashCode();
        }
        if (getUI() != null) {
            _hashCode += getUI().hashCode();
        }
        if (getAbbrev() != null) {
            _hashCode += getAbbrev().hashCode();
        }
        if (getChildren() != null) {
            _hashCode += getChildren().hashCode();
        }
        if (getChildrenUIs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getChildrenUIs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getChildrenUIs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDef() != null) {
            _hashCode += getDef().hashCode();
        }
        if (getExamples() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getExamples());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getExamples(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += (isExpanded() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getParentUI() != null) {
            _hashCode += getParentUI().hashCode();
        }
        if (getTreeNum() != null) {
            _hashCode += getTreeNum().hashCode();
        }
        if (getUsage() != null) {
            _hashCode += getUsage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HierSemanticType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NHFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "NHFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("abbrev");
        elemField.setXmlName(new javax.xml.namespace.QName("", "abbrev"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("children");
        elemField.setXmlName(new javax.xml.namespace.QName("", "children"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticTypeGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("childrenUIs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "childrenUIs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("def");
        elemField.setXmlName(new javax.xml.namespace.QName("", "def"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("examples");
        elemField.setXmlName(new javax.xml.namespace.QName("", "examples"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expanded");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expanded"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parentUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "parentUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("treeNum");
        elemField.setXmlName(new javax.xml.namespace.QName("", "treeNum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "usage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
