/**
 * UIHistoryEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.deltas;

public class UIHistoryEntry  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private gov.nih.nlm.kss.models.meta.deltas.HistoryEntry[] entries;

    private java.lang.String sourceUI;

    public UIHistoryEntry() {
    }

    public UIHistoryEntry(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.models.meta.deltas.HistoryEntry[] entries,
           java.lang.String sourceUI) {
        super(
            key,
            performanceMode);
        this.entries = entries;
        this.sourceUI = sourceUI;
    }


    /**
     * Gets the entries value for this UIHistoryEntry.
     * 
     * @return entries
     */
    public gov.nih.nlm.kss.models.meta.deltas.HistoryEntry[] getEntries() {
        return entries;
    }


    /**
     * Sets the entries value for this UIHistoryEntry.
     * 
     * @param entries
     */
    public void setEntries(gov.nih.nlm.kss.models.meta.deltas.HistoryEntry[] entries) {
        this.entries = entries;
    }


    /**
     * Gets the sourceUI value for this UIHistoryEntry.
     * 
     * @return sourceUI
     */
    public java.lang.String getSourceUI() {
        return sourceUI;
    }


    /**
     * Sets the sourceUI value for this UIHistoryEntry.
     * 
     * @param sourceUI
     */
    public void setSourceUI(java.lang.String sourceUI) {
        this.sourceUI = sourceUI;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UIHistoryEntry)) return false;
        UIHistoryEntry other = (UIHistoryEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.entries==null && other.getEntries()==null) || 
             (this.entries!=null &&
              java.util.Arrays.equals(this.entries, other.getEntries()))) &&
            ((this.sourceUI==null && other.getSourceUI()==null) || 
             (this.sourceUI!=null &&
              this.sourceUI.equals(other.getSourceUI())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getEntries() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEntries());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEntries(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSourceUI() != null) {
            _hashCode += getSourceUI().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UIHistoryEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "UIHistoryEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("entries");
        elemField.setXmlName(new javax.xml.namespace.QName("", "entries"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "HistoryEntry"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sourceUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sourceUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
