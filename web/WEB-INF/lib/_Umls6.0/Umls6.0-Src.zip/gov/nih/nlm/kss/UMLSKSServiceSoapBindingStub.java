/**
 * UMLSKSServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss;

public class UMLSKSServiceSoapBindingStub extends org.apache.axis.client.Stub implements gov.nih.nlm.kss.UMLSKSServicePortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[50];
        _initOperationDesc1();
        _initOperationDesc2();
        _initOperationDesc3();
        _initOperationDesc4();
        _initOperationDesc5();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("query");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "XMLQueryRequest"), gov.nih.nlm.kss.query.XMLQueryRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "RowGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.RowGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "queryReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getMapping");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "MapRequest"), gov.nih.nlm.kss.query.meta.MapRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapSetGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.mapping.MapSetGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getMappingReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("words");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "WordRequest"), gov.nih.nlm.kss.query.WordRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSStringGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.KSStringGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "wordsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("identity");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "UMLSKSRequest"), gov.nih.nlm.kss.query.UMLSKSRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "identityReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCurrentUMLSVersion");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "CurrentUMLSRequest"), gov.nih.nlm.kss.query.CurrentUMLSRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getCurrentUMLSVersionReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("login");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        oper.setReturnClass(boolean.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "loginReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("listUMLSReleases");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "ListUMLSReleasesRequest"), gov.nih.nlm.kss.query.ListUMLSReleasesRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_xsd_string"));
        oper.setReturnClass(java.lang.String[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "listUMLSReleasesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSoftwareVersion");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "SWVersionRequest"), gov.nih.nlm.kss.query.SWVersionRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getSoftwareVersionReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("normalizeString");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "NormalizeStringRequest"), gov.nih.nlm.kss.query.NormalizeStringRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSStringGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.KSStringGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "normalizeStringReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("undiacritic");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "UndiacriticRequest"), gov.nih.nlm.kss.query.UndiacriticRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSStringGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.KSStringGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "undiacriticReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCUIByApproximateMatch");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "ConceptIdApproximateMatchRequest"), gov.nih.nlm.kss.query.ConceptIdApproximateMatchRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCUIByApproximateMatchReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("suggestSpelling");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "SuggestSpellingRequest"), gov.nih.nlm.kss.query.SuggestSpellingRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "SpellingSuggestionsGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.SpellingSuggestionsGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "suggestSpellingReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getRawRecords");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "RawRecordsRequest"), gov.nih.nlm.kss.query.RawRecordsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getRawRecordsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("describeRawTables");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "DescribeTablesRequest"), gov.nih.nlm.kss.query.DescribeTablesRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "TableGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.TableGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "describeRawTablesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCUIByExact");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdExactRequest"), gov.nih.nlm.kss.query.meta.ConceptIdExactRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCUIByExactReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCUIByNormString");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdNormStringRequest"), gov.nih.nlm.kss.query.meta.ConceptIdNormStringRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCUIByNormStringReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCUIByNormWord");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdNormWordRequest"), gov.nih.nlm.kss.query.meta.ConceptIdNormWordRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCUIByNormWordReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCUIByWord");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdWordRequest"), gov.nih.nlm.kss.query.meta.ConceptIdWordRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCUIByWordReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCUIByRightTruncation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdRightTruncationRequest"), gov.nih.nlm.kss.query.meta.ConceptIdRightTruncationRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCUIByRightTruncationReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[18] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCUIByLeftTruncation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdLeftTruncationRequest"), gov.nih.nlm.kss.query.meta.ConceptIdLeftTruncationRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCUIByLeftTruncationReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[19] = oper;

    }

    private static void _initOperationDesc3(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCUIBySemType");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdSemTypeRequest"), gov.nih.nlm.kss.query.meta.ConceptIdSemTypeRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCUIBySemTypeReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[20] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCUIBySabCode");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdSabCodeRequest"), gov.nih.nlm.kss.query.meta.ConceptIdSabCodeRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCUIBySabCodeReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[21] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getConceptProperties");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptRequest"), gov.nih.nlm.kss.query.meta.ConceptRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.ConceptGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getConceptPropertiesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[22] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("listDocEntryTypes");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "DocEntryRequest"), gov.nih.nlm.kss.query.meta.DocEntryRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://meta.models.kss.nlm.nih.gov", "DocEntryGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.DocEntryGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "listDocEntryTypesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[23] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getStringsForSUI");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "StringIdRequest"), gov.nih.nlm.kss.query.meta.StringIdRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.StringIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getStringsForSUIReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[24] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findSUI");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "SUIRequest"), gov.nih.nlm.kss.query.meta.SUIRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.StringIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findSUIReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[25] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getAUIDetails");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "AUIDetailsRequest"), gov.nih.nlm.kss.query.meta.AUIDetailsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.StringIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getAUIDetailsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[26] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getTermsForLUI");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "TermIdRequest"), gov.nih.nlm.kss.query.meta.TermIdRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "TermIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.TermIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getTermsForLUIReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[27] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findLUI");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "LUIRequest"), gov.nih.nlm.kss.query.meta.LUIRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "TermIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.concept.TermIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findLUIReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[28] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("describeSources");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "SourceRequest"), gov.nih.nlm.kss.query.meta.SourceRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://source.meta.models.kss.nlm.nih.gov", "SourceGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.source.SourceGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "describeSourcesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[29] = oper;

    }

    private static void _initOperationDesc4(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("describeUMLSChanges");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "DescribeChangesRequest"), gov.nih.nlm.kss.query.meta.DescribeChangesRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "ReleaseDeltaGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.deltas.ReleaseDeltaGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "describeUMLSChangesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[30] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getMeSHEntries");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "MeSHEntryRequest"), gov.nih.nlm.kss.query.meta.MeSHEntryRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://meshentry.meta.models.kss.nlm.nih.gov", "MeSHEntryGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.meshentry.MeSHEntryGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getMeSHEntriesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[31] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getMeSHInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "MeSHInfoRequest"), gov.nih.nlm.kss.query.meta.MeSHInfoRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://meshentry.meta.models.kss.nlm.nih.gov", "MeSHInfoGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.meshentry.MeSHInfoGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getMeSHInfoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[32] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findSemNetId");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SearchStringRequest"), gov.nih.nlm.kss.query.sem.SearchStringRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemNetIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.units.SemNetIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findSemNetIdReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[33] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("listSemTypeIds");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "ListSemTypeIdsRequest"), gov.nih.nlm.kss.query.sem.ListSemTypeIdsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemNetIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.units.SemNetIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "listSemTypeIdsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[34] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSemTypeProperties");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypePropsRequest"), gov.nih.nlm.kss.query.sem.SemTypePropsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticTypeGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getSemTypePropertiesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[35] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSemTypeAncestors");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypeAncestorsRequest"), gov.nih.nlm.kss.query.sem.SemTypeAncestorsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticTypeGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getSemTypeAncestorsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[36] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSemTypeSiblings");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypeSiblingsRequest"), gov.nih.nlm.kss.query.sem.SemTypeSiblingsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticTypeGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getSemTypeSiblingsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[37] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("listSemRelationIds");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "ListSemRelationIdsRequest"), gov.nih.nlm.kss.query.sem.ListSemRelationIdsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemNetIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.units.SemNetIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "listSemRelationIdsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[38] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSemRelationProperties");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemRelationPropsRequest"), gov.nih.nlm.kss.query.sem.SemRelationPropsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticRelationGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getSemRelationPropertiesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[39] = oper;

    }

    private static void _initOperationDesc5(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSemRelationAncestors");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemRelationAncestorsRequest"), gov.nih.nlm.kss.query.sem.SemRelationAncestorsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticRelationGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getSemRelationAncestorsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[40] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("existsAssociativeRelation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "AssociativeRelExistsRequest"), gov.nih.nlm.kss.query.sem.AssociativeRelExistsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "AssociativeRelExistence"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.rels.AssociativeRelExistence.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "existsAssociativeRelationReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[41] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getAssociativeRelations");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "AssociativeRelationsRequest"), gov.nih.nlm.kss.query.sem.AssociativeRelationsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "AssociativeRelationGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.rels.AssociativeRelationGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getAssociativeRelationsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[42] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("existsHierRelRelation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "HierRelRelExistsRequest"), gov.nih.nlm.kss.query.sem.HierRelRelExistsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "HierRelRelExistence"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.rels.HierRelRelExistence.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "existsHierRelRelationReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[43] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("listSemGroups");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemGroupListRequest"), gov.nih.nlm.kss.query.sem.SemGroupListRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemGroupGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.units.SemGroupGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "listSemGroupsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[44] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("listSemTypesForGroup");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypesForGroupRequest"), gov.nih.nlm.kss.query.sem.SemTypesForGroupRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemNetIdGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.sem.units.SemNetIdGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "listSemTypesForGroupReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[45] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getLexicalRecords");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "LexicalRecordRequest"), gov.nih.nlm.kss.query.LexicalRecordRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getLexicalRecordsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[46] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("listDictionaries");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "DictionaryRequest"), gov.nih.nlm.kss.query.DictionaryRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "DictionaryGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.DictionaryGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "listDictionariesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[47] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("listSourceRankings");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ListSourceRankingsRequest"), gov.nih.nlm.kss.query.meta.ListSourceRankingsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://rank.meta.models.kss.nlm.nih.gov", "SourceRankGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.rank.SourceRankGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "listSourceRankingsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[48] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSourceChanges");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "SourceHistoryRequest"), gov.nih.nlm.kss.query.meta.SourceHistoryRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "SourceHistoryGroup"));
        oper.setReturnClass(gov.nih.nlm.kss.models.meta.deltas.SourceHistoryGroup.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getSourceChangesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[49] = oper;

    }

    public UMLSKSServiceSoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public UMLSKSServiceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public UMLSKSServiceSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "Attr");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.attribute.Attr.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "AttributeContext");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.attribute.AttributeContext.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "AttributeValue");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.attribute.AttributeValue.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "ConceptAttribute");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.attribute.ConceptAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "ConceptAttributeGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.attribute.ConceptAttributeGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "RelationshipAttribute");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.attribute.RelationshipAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "RelationshipAttributeGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.attribute.RelationshipAttributeGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "Concept");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.Concept.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.ConceptGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptId");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.ConceptId.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "Definition");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.Definition.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "DefinitionGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.DefinitionGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "SemType");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.SemType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "SemTypeGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.SemTypeGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "SourceInfo");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.SourceInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringId");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.StringId.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringIdGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.StringIdGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringInfo");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.StringInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringSource");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.StringSource.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "Term");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.Term.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "TermGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.TermGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "TermId");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.TermId.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "TermIdGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.TermIdGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "Context");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.context.Context.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "ContextGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.context.ContextGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "CxtMember");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.context.CxtMember.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "SourceCxt");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.context.SourceCxt.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "StringCxt");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.context.StringCxt.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cooccurrence.meta.models.kss.nlm.nih.gov", "COContext");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.cooccurrence.COContext.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cooccurrence.meta.models.kss.nlm.nih.gov", "CooccurrenceGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.cooccurrence.CooccurrenceGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cooccurrence.meta.models.kss.nlm.nih.gov", "CooccurringConcept");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.cooccurrence.CooccurringConcept.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cooccurrence.meta.models.kss.nlm.nih.gov", "MeSHQualifier");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.cooccurrence.MeSHQualifier.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://cooccurrence.meta.models.kss.nlm.nih.gov", "QualifierFrequency");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.cooccurrence.QualifierFrequency.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "ConceptDelta");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.deltas.ConceptDelta.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "HistoryEntry");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.deltas.HistoryEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "ReleaseDelta");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.deltas.ReleaseDelta.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "ReleaseDeltaGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.deltas.ReleaseDeltaGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "SourceHistory");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.deltas.SourceHistory.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "SourceHistoryGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.deltas.SourceHistoryGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "UIHistoryEntry");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.deltas.UIHistoryEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns11_MappedRelation");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.mapping.MappedRelation[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MappedRelation");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns11_MapSubset");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.mapping.MapSubset[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapSubset");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns12_SourceInfo");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.SourceInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "SourceInfo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns12_StringInfo");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.StringInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringInfo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns12_StringSource");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.concept.StringSource[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringSource");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns14_RelSource");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.relation.RelSource[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://relation.meta.models.kss.nlm.nih.gov", "RelSource");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns15_AttributeContext");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.attribute.AttributeContext[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "AttributeContext");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns15_AttributeValue");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.attribute.AttributeValue[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "AttributeValue");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns19_ConceptDelta");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.deltas.ConceptDelta[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "ConceptDelta");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns19_HistoryEntry");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.deltas.HistoryEntry[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "HistoryEntry");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns19_UIHistoryEntry");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.deltas.UIHistoryEntry[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "UIHistoryEntry");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns20_CxtMember");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.context.CxtMember[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "CxtMember");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns20_SourceCxt");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.context.SourceCxt[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "SourceCxt");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns20_StringCxt");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.context.StringCxt[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "StringCxt");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns2_Rank");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.rank.Rank[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://rank.meta.models.kss.nlm.nih.gov", "Rank");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns5_COContext");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.cooccurrence.COContext[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://cooccurrence.meta.models.kss.nlm.nih.gov", "COContext");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns5_QualifierFrequency");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.cooccurrence.QualifierFrequency[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://cooccurrence.meta.models.kss.nlm.nih.gov", "QualifierFrequency");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns8_ColumnDescription");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.ColumnDescription[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "ColumnDescription");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_tns8_ColumnValue");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.ColumnValue[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "ColumnValue");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_xsd_anyType");
            cachedSerQNames.add(qName);
            cls = java.lang.Object[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_xsd_string");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapEntry");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.mapping.MapEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MappedRelation");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.mapping.MappedRelation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapRelation");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.mapping.MapRelation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapSet");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.mapping.MapSet.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapSetGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.mapping.MapSetGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapSubset");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.mapping.MapSubset.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meshentry.meta.models.kss.nlm.nih.gov", "MeSHEntry");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.meshentry.MeSHEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meshentry.meta.models.kss.nlm.nih.gov", "MeSHEntryGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.meshentry.MeSHEntryGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meshentry.meta.models.kss.nlm.nih.gov", "MeSHInfo");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.meshentry.MeSHInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meshentry.meta.models.kss.nlm.nih.gov", "MeSHInfoGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.meshentry.MeSHInfoGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.models.kss.nlm.nih.gov", "DocEntryGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.DocEntryGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.models.kss.nlm.nih.gov", "DocEntryType");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.DocEntryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.models.kss.nlm.nih.gov", "DocEntryTypeGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.DocEntryTypeGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "AUIDetailsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.AUIDetailsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdExactRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ConceptIdExactRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdLeftTruncationRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ConceptIdLeftTruncationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdNormStringRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ConceptIdNormStringRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdNormWordRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ConceptIdNormWordRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdRightTruncationRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ConceptIdRightTruncationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdSabCodeRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ConceptIdSabCodeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdSemTypeRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ConceptIdSemTypeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdWordRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ConceptIdWordRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ConceptRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "CUIInputRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.CUIInputRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "DescribeChangesRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.DescribeChangesRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "DocEntryRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.DocEntryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ListSourceRankingsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ListSourceRankingsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "LUIRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.LUIRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "MapRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.MapRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "MeSHEntryRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.MeSHEntryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "MeSHInfoRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.MeSHInfoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ReleaseSearchStringRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.ReleaseSearchStringRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "RestrictedSearchStringRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.RestrictedSearchStringRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "SourceHistoryRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.SourceHistoryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "SourceRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.SourceRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "StringIdRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.StringIdRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "SUIRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.SUIRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "TermIdRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.meta.TermIdRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "ColumnDescription");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.ColumnDescription.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "ColumnValue");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.ColumnValue.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "DictionaryGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.DictionaryGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "HomogeneousGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.HomogeneousGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSCuiGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.KSCuiGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.KSGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSObj");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.KSObj.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSObject");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.KSObject.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSStringGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.KSStringGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "Row");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.Row.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "RowGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.RowGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "SpellingSuggestionsGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.SpellingSuggestionsGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "Table");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.Table.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "TableGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.TableGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "ConceptIdApproximateMatchRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.ConceptIdApproximateMatchRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "ContentViewRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.ContentViewRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "CurrentUMLSRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.CurrentUMLSRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "DescribeTablesRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.DescribeTablesRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "DictionaryRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.DictionaryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "LexicalRecordRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.LexicalRecordRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "ListUMLSReleasesRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.ListUMLSReleasesRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "NormalizeStringRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.NormalizeStringRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "RawRecordsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.RawRecordsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "ReleaseInputRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.ReleaseInputRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "SuggestSpellingRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.SuggestSpellingRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "SWVersionRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.SWVersionRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "UMLSKSRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.UMLSKSRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "UndiacriticRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.UndiacriticRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "WordRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.WordRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "XMLQueryRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.XMLQueryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://rank.meta.models.kss.nlm.nih.gov", "Rank");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.rank.Rank.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://rank.meta.models.kss.nlm.nih.gov", "SourceRank");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.rank.SourceRank.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://rank.meta.models.kss.nlm.nih.gov", "SourceRankGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.rank.SourceRankGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://relation.meta.models.kss.nlm.nih.gov", "Relation");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.relation.Relation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://relation.meta.models.kss.nlm.nih.gov", "RelationGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.relation.RelationGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://relation.meta.models.kss.nlm.nih.gov", "RelSource");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.relation.RelSource.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "AssociativeRelation");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.rels.AssociativeRelation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "AssociativeRelationGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.rels.AssociativeRelationGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "AssociativeRelExistence");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.rels.AssociativeRelExistence.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "HierRelRelExistence");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.rels.HierRelRelExistence.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "AssociativeRelationsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.AssociativeRelationsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "AssociativeRelExistsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.AssociativeRelExistsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "HierRelRelExistsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.HierRelRelExistsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "IdentifiersRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.IdentifiersRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "ListSemRelationIdsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.ListSemRelationIdsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "ListSemTypeIdsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.ListSemTypeIdsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SearchStringRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SearchStringRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemGroupListRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SemGroupListRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemNetNameRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SemNetNameRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemRelationAncestorsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SemRelationAncestorsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemRelationPropsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SemRelationPropsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypeAncestorsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SemTypeAncestorsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypePropsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SemTypePropsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypesForGroupRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SemTypesForGroupRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypeSiblingsRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SemTypeSiblingsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SNExpansionRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SNExpansionRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SNExpTripletRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SNExpTripletRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SNTripletRequest");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.query.sem.SNTripletRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://source.meta.models.kss.nlm.nih.gov", "Source");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.source.Source.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://source.meta.models.kss.nlm.nih.gov", "SourceGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.meta.source.SourceGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticRelation");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.units.HierSemanticRelation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticRelationGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticType");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.units.HierSemanticType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticTypeGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.units.SemGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemGroupGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.units.SemGroupGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemNetId");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.units.SemNetId.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemNetIdGroup");
            cachedSerQNames.add(qName);
            cls = gov.nih.nlm.kss.models.sem.units.SemNetIdGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
                    _call.setEncodingStyle(org.apache.axis.Constants.URI_SOAP11_ENC);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public gov.nih.nlm.kss.models.RowGroup query(gov.nih.nlm.kss.query.XMLQueryRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "query"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.RowGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.RowGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.RowGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.mapping.MapSetGroup getMapping(gov.nih.nlm.kss.query.meta.MapRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getMapping"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.mapping.MapSetGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.mapping.MapSetGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.mapping.MapSetGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.KSStringGroup words(gov.nih.nlm.kss.query.WordRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "words"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.KSStringGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.KSStringGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.KSStringGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String identity(gov.nih.nlm.kss.query.UMLSKSRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "identity"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getCurrentUMLSVersion(gov.nih.nlm.kss.query.CurrentUMLSRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getCurrentUMLSVersion"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public boolean login(java.lang.String in0, java.lang.String in1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "login"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {in0, in1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Boolean) _resp).booleanValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_resp, boolean.class)).booleanValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String[] listUMLSReleases(gov.nih.nlm.kss.query.ListUMLSReleasesRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listUMLSReleases"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getSoftwareVersion(gov.nih.nlm.kss.query.SWVersionRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSoftwareVersion"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.KSStringGroup normalizeString(gov.nih.nlm.kss.query.NormalizeStringRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "normalizeString"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.KSStringGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.KSStringGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.KSStringGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.KSStringGroup undiacritic(gov.nih.nlm.kss.query.UndiacriticRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "undiacritic"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.KSStringGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.KSStringGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.KSStringGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByApproximateMatch(gov.nih.nlm.kss.query.ConceptIdApproximateMatchRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByApproximateMatch"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.SpellingSuggestionsGroup suggestSpelling(gov.nih.nlm.kss.query.SuggestSpellingRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "suggestSpelling"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.SpellingSuggestionsGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.SpellingSuggestionsGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.SpellingSuggestionsGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getRawRecords(gov.nih.nlm.kss.query.RawRecordsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getRawRecords"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.TableGroup describeRawTables(gov.nih.nlm.kss.query.DescribeTablesRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "describeRawTables"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.TableGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.TableGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.TableGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByExact(gov.nih.nlm.kss.query.meta.ConceptIdExactRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByExact"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByNormString(gov.nih.nlm.kss.query.meta.ConceptIdNormStringRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByNormString"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByNormWord(gov.nih.nlm.kss.query.meta.ConceptIdNormWordRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByNormWord"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByWord(gov.nih.nlm.kss.query.meta.ConceptIdWordRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByWord"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByRightTruncation(gov.nih.nlm.kss.query.meta.ConceptIdRightTruncationRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByRightTruncation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByLeftTruncation(gov.nih.nlm.kss.query.meta.ConceptIdLeftTruncationRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[19]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByLeftTruncation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIBySemType(gov.nih.nlm.kss.query.meta.ConceptIdSemTypeRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[20]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIBySemType"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIBySabCode(gov.nih.nlm.kss.query.meta.ConceptIdSabCodeRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[21]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIBySabCode"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptGroup getConceptProperties(gov.nih.nlm.kss.query.meta.ConceptRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[22]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getConceptProperties"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.ConceptGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.ConceptGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.DocEntryGroup listDocEntryTypes(gov.nih.nlm.kss.query.meta.DocEntryRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[23]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listDocEntryTypes"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.DocEntryGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.DocEntryGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.DocEntryGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.StringIdGroup getStringsForSUI(gov.nih.nlm.kss.query.meta.StringIdRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[24]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getStringsForSUI"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.StringIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.StringIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.StringIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.StringIdGroup findSUI(gov.nih.nlm.kss.query.meta.SUIRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[25]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findSUI"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.StringIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.StringIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.StringIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.StringIdGroup getAUIDetails(gov.nih.nlm.kss.query.meta.AUIDetailsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[26]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getAUIDetails"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.StringIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.StringIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.StringIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.TermIdGroup getTermsForLUI(gov.nih.nlm.kss.query.meta.TermIdRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[27]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getTermsForLUI"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.TermIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.TermIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.TermIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.concept.TermIdGroup findLUI(gov.nih.nlm.kss.query.meta.LUIRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[28]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findLUI"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.concept.TermIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.concept.TermIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.concept.TermIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.source.SourceGroup describeSources(gov.nih.nlm.kss.query.meta.SourceRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[29]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "describeSources"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.source.SourceGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.source.SourceGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.source.SourceGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.deltas.ReleaseDeltaGroup describeUMLSChanges(gov.nih.nlm.kss.query.meta.DescribeChangesRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[30]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "describeUMLSChanges"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.deltas.ReleaseDeltaGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.deltas.ReleaseDeltaGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.deltas.ReleaseDeltaGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.meshentry.MeSHEntryGroup getMeSHEntries(gov.nih.nlm.kss.query.meta.MeSHEntryRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[31]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getMeSHEntries"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.meshentry.MeSHEntryGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.meshentry.MeSHEntryGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.meshentry.MeSHEntryGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.meshentry.MeSHInfoGroup getMeSHInfo(gov.nih.nlm.kss.query.meta.MeSHInfoRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[32]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getMeSHInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.meshentry.MeSHInfoGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.meshentry.MeSHInfoGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.meshentry.MeSHInfoGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup findSemNetId(gov.nih.nlm.kss.query.sem.SearchStringRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[33]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findSemNetId"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.units.SemNetIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.units.SemNetIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.units.SemNetIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup listSemTypeIds(gov.nih.nlm.kss.query.sem.ListSemTypeIdsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[34]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listSemTypeIds"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.units.SemNetIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.units.SemNetIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.units.SemNetIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup getSemTypeProperties(gov.nih.nlm.kss.query.sem.SemTypePropsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[35]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSemTypeProperties"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup getSemTypeAncestors(gov.nih.nlm.kss.query.sem.SemTypeAncestorsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[36]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSemTypeAncestors"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup getSemTypeSiblings(gov.nih.nlm.kss.query.sem.SemTypeSiblingsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[37]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSemTypeSiblings"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup listSemRelationIds(gov.nih.nlm.kss.query.sem.ListSemRelationIdsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[38]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listSemRelationIds"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.units.SemNetIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.units.SemNetIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.units.SemNetIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup getSemRelationProperties(gov.nih.nlm.kss.query.sem.SemRelationPropsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[39]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSemRelationProperties"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup getSemRelationAncestors(gov.nih.nlm.kss.query.sem.SemRelationAncestorsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[40]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSemRelationAncestors"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.rels.AssociativeRelExistence existsAssociativeRelation(gov.nih.nlm.kss.query.sem.AssociativeRelExistsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[41]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "existsAssociativeRelation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.rels.AssociativeRelExistence) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.rels.AssociativeRelExistence) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.rels.AssociativeRelExistence.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.rels.AssociativeRelationGroup getAssociativeRelations(gov.nih.nlm.kss.query.sem.AssociativeRelationsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[42]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getAssociativeRelations"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.rels.AssociativeRelationGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.rels.AssociativeRelationGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.rels.AssociativeRelationGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.rels.HierRelRelExistence existsHierRelRelation(gov.nih.nlm.kss.query.sem.HierRelRelExistsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[43]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "existsHierRelRelation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.rels.HierRelRelExistence) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.rels.HierRelRelExistence) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.rels.HierRelRelExistence.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.units.SemGroupGroup listSemGroups(gov.nih.nlm.kss.query.sem.SemGroupListRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[44]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listSemGroups"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.units.SemGroupGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.units.SemGroupGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.units.SemGroupGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup listSemTypesForGroup(gov.nih.nlm.kss.query.sem.SemTypesForGroupRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[45]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listSemTypesForGroup"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.sem.units.SemNetIdGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.sem.units.SemNetIdGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.sem.units.SemNetIdGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getLexicalRecords(gov.nih.nlm.kss.query.LexicalRecordRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[46]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getLexicalRecords"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.DictionaryGroup listDictionaries(gov.nih.nlm.kss.query.DictionaryRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[47]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listDictionaries"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.DictionaryGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.DictionaryGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.DictionaryGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.rank.SourceRankGroup listSourceRankings(gov.nih.nlm.kss.query.meta.ListSourceRankingsRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[48]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listSourceRankings"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.rank.SourceRankGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.rank.SourceRankGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.rank.SourceRankGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public gov.nih.nlm.kss.models.meta.deltas.SourceHistoryGroup getSourceChanges(gov.nih.nlm.kss.query.meta.SourceHistoryRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[49]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSourceChanges"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (gov.nih.nlm.kss.models.meta.deltas.SourceHistoryGroup) _resp;
            } catch (java.lang.Exception _exception) {
                return (gov.nih.nlm.kss.models.meta.deltas.SourceHistoryGroup) org.apache.axis.utils.JavaUtils.convert(_resp, gov.nih.nlm.kss.models.meta.deltas.SourceHistoryGroup.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
