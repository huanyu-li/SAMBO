/**
 * MapEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.mapping;

public class MapEntry  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String UMLSIdentifier;

    private java.lang.String name;

    private java.lang.String restriction;

    private java.lang.String rule;

    private java.lang.String srcIdentifier;

    private java.lang.String type;

    public MapEntry() {
    }

    public MapEntry(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String UMLSIdentifier,
           java.lang.String name,
           java.lang.String restriction,
           java.lang.String rule,
           java.lang.String srcIdentifier,
           java.lang.String type) {
        super(
            key,
            performanceMode);
        this.UMLSIdentifier = UMLSIdentifier;
        this.name = name;
        this.restriction = restriction;
        this.rule = rule;
        this.srcIdentifier = srcIdentifier;
        this.type = type;
    }


    /**
     * Gets the UMLSIdentifier value for this MapEntry.
     * 
     * @return UMLSIdentifier
     */
    public java.lang.String getUMLSIdentifier() {
        return UMLSIdentifier;
    }


    /**
     * Sets the UMLSIdentifier value for this MapEntry.
     * 
     * @param UMLSIdentifier
     */
    public void setUMLSIdentifier(java.lang.String UMLSIdentifier) {
        this.UMLSIdentifier = UMLSIdentifier;
    }


    /**
     * Gets the name value for this MapEntry.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this MapEntry.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the restriction value for this MapEntry.
     * 
     * @return restriction
     */
    public java.lang.String getRestriction() {
        return restriction;
    }


    /**
     * Sets the restriction value for this MapEntry.
     * 
     * @param restriction
     */
    public void setRestriction(java.lang.String restriction) {
        this.restriction = restriction;
    }


    /**
     * Gets the rule value for this MapEntry.
     * 
     * @return rule
     */
    public java.lang.String getRule() {
        return rule;
    }


    /**
     * Sets the rule value for this MapEntry.
     * 
     * @param rule
     */
    public void setRule(java.lang.String rule) {
        this.rule = rule;
    }


    /**
     * Gets the srcIdentifier value for this MapEntry.
     * 
     * @return srcIdentifier
     */
    public java.lang.String getSrcIdentifier() {
        return srcIdentifier;
    }


    /**
     * Sets the srcIdentifier value for this MapEntry.
     * 
     * @param srcIdentifier
     */
    public void setSrcIdentifier(java.lang.String srcIdentifier) {
        this.srcIdentifier = srcIdentifier;
    }


    /**
     * Gets the type value for this MapEntry.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this MapEntry.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MapEntry)) return false;
        MapEntry other = (MapEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.UMLSIdentifier==null && other.getUMLSIdentifier()==null) || 
             (this.UMLSIdentifier!=null &&
              this.UMLSIdentifier.equals(other.getUMLSIdentifier()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.restriction==null && other.getRestriction()==null) || 
             (this.restriction!=null &&
              this.restriction.equals(other.getRestriction()))) &&
            ((this.rule==null && other.getRule()==null) || 
             (this.rule!=null &&
              this.rule.equals(other.getRule()))) &&
            ((this.srcIdentifier==null && other.getSrcIdentifier()==null) || 
             (this.srcIdentifier!=null &&
              this.srcIdentifier.equals(other.getSrcIdentifier()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getUMLSIdentifier() != null) {
            _hashCode += getUMLSIdentifier().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getRestriction() != null) {
            _hashCode += getRestriction().hashCode();
        }
        if (getRule() != null) {
            _hashCode += getRule().hashCode();
        }
        if (getSrcIdentifier() != null) {
            _hashCode += getSrcIdentifier().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MapEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UMLSIdentifier");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UMLSIdentifier"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("restriction");
        elemField.setXmlName(new javax.xml.namespace.QName("", "restriction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rule");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rule"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("srcIdentifier");
        elemField.setXmlName(new javax.xml.namespace.QName("", "srcIdentifier"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
