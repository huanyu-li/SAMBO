/**
 * StringSource.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.concept;

public class StringSource  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String SAB;

    private java.lang.String SRL;

    private java.lang.String code;

    private gov.nih.nlm.kss.models.meta.concept.SourceInfo[] srcInfos;

    public StringSource() {
    }

    public StringSource(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String SAB,
           java.lang.String SRL,
           java.lang.String code,
           gov.nih.nlm.kss.models.meta.concept.SourceInfo[] srcInfos) {
        super(
            key,
            performanceMode);
        this.SAB = SAB;
        this.SRL = SRL;
        this.code = code;
        this.srcInfos = srcInfos;
    }


    /**
     * Gets the SAB value for this StringSource.
     * 
     * @return SAB
     */
    public java.lang.String getSAB() {
        return SAB;
    }


    /**
     * Sets the SAB value for this StringSource.
     * 
     * @param SAB
     */
    public void setSAB(java.lang.String SAB) {
        this.SAB = SAB;
    }


    /**
     * Gets the SRL value for this StringSource.
     * 
     * @return SRL
     */
    public java.lang.String getSRL() {
        return SRL;
    }


    /**
     * Sets the SRL value for this StringSource.
     * 
     * @param SRL
     */
    public void setSRL(java.lang.String SRL) {
        this.SRL = SRL;
    }


    /**
     * Gets the code value for this StringSource.
     * 
     * @return code
     */
    public java.lang.String getCode() {
        return code;
    }


    /**
     * Sets the code value for this StringSource.
     * 
     * @param code
     */
    public void setCode(java.lang.String code) {
        this.code = code;
    }


    /**
     * Gets the srcInfos value for this StringSource.
     * 
     * @return srcInfos
     */
    public gov.nih.nlm.kss.models.meta.concept.SourceInfo[] getSrcInfos() {
        return srcInfos;
    }


    /**
     * Sets the srcInfos value for this StringSource.
     * 
     * @param srcInfos
     */
    public void setSrcInfos(gov.nih.nlm.kss.models.meta.concept.SourceInfo[] srcInfos) {
        this.srcInfos = srcInfos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof StringSource)) return false;
        StringSource other = (StringSource) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.SAB==null && other.getSAB()==null) || 
             (this.SAB!=null &&
              this.SAB.equals(other.getSAB()))) &&
            ((this.SRL==null && other.getSRL()==null) || 
             (this.SRL!=null &&
              this.SRL.equals(other.getSRL()))) &&
            ((this.code==null && other.getCode()==null) || 
             (this.code!=null &&
              this.code.equals(other.getCode()))) &&
            ((this.srcInfos==null && other.getSrcInfos()==null) || 
             (this.srcInfos!=null &&
              java.util.Arrays.equals(this.srcInfos, other.getSrcInfos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getSAB() != null) {
            _hashCode += getSAB().hashCode();
        }
        if (getSRL() != null) {
            _hashCode += getSRL().hashCode();
        }
        if (getCode() != null) {
            _hashCode += getCode().hashCode();
        }
        if (getSrcInfos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSrcInfos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSrcInfos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(StringSource.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringSource"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAB");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SAB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SRL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SRL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("code");
        elemField.setXmlName(new javax.xml.namespace.QName("", "code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("srcInfos");
        elemField.setXmlName(new javax.xml.namespace.QName("", "srcInfos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "SourceInfo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
