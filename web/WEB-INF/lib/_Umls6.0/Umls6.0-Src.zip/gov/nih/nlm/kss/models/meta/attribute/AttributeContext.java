/**
 * AttributeContext.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.attribute;

public class AttributeContext  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String SAB;

    private java.lang.String UI;

    private gov.nih.nlm.kss.models.meta.attribute.AttributeValue[] attribs;

    private java.lang.String code;

    private java.lang.String type;

    public AttributeContext() {
    }

    public AttributeContext(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String SAB,
           java.lang.String UI,
           gov.nih.nlm.kss.models.meta.attribute.AttributeValue[] attribs,
           java.lang.String code,
           java.lang.String type) {
        super(
            key,
            performanceMode);
        this.SAB = SAB;
        this.UI = UI;
        this.attribs = attribs;
        this.code = code;
        this.type = type;
    }


    /**
     * Gets the SAB value for this AttributeContext.
     * 
     * @return SAB
     */
    public java.lang.String getSAB() {
        return SAB;
    }


    /**
     * Sets the SAB value for this AttributeContext.
     * 
     * @param SAB
     */
    public void setSAB(java.lang.String SAB) {
        this.SAB = SAB;
    }


    /**
     * Gets the UI value for this AttributeContext.
     * 
     * @return UI
     */
    public java.lang.String getUI() {
        return UI;
    }


    /**
     * Sets the UI value for this AttributeContext.
     * 
     * @param UI
     */
    public void setUI(java.lang.String UI) {
        this.UI = UI;
    }


    /**
     * Gets the attribs value for this AttributeContext.
     * 
     * @return attribs
     */
    public gov.nih.nlm.kss.models.meta.attribute.AttributeValue[] getAttribs() {
        return attribs;
    }


    /**
     * Sets the attribs value for this AttributeContext.
     * 
     * @param attribs
     */
    public void setAttribs(gov.nih.nlm.kss.models.meta.attribute.AttributeValue[] attribs) {
        this.attribs = attribs;
    }


    /**
     * Gets the code value for this AttributeContext.
     * 
     * @return code
     */
    public java.lang.String getCode() {
        return code;
    }


    /**
     * Sets the code value for this AttributeContext.
     * 
     * @param code
     */
    public void setCode(java.lang.String code) {
        this.code = code;
    }


    /**
     * Gets the type value for this AttributeContext.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this AttributeContext.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AttributeContext)) return false;
        AttributeContext other = (AttributeContext) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.SAB==null && other.getSAB()==null) || 
             (this.SAB!=null &&
              this.SAB.equals(other.getSAB()))) &&
            ((this.UI==null && other.getUI()==null) || 
             (this.UI!=null &&
              this.UI.equals(other.getUI()))) &&
            ((this.attribs==null && other.getAttribs()==null) || 
             (this.attribs!=null &&
              java.util.Arrays.equals(this.attribs, other.getAttribs()))) &&
            ((this.code==null && other.getCode()==null) || 
             (this.code!=null &&
              this.code.equals(other.getCode()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getSAB() != null) {
            _hashCode += getSAB().hashCode();
        }
        if (getUI() != null) {
            _hashCode += getUI().hashCode();
        }
        if (getAttribs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttribs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttribs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCode() != null) {
            _hashCode += getCode().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AttributeContext.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "AttributeContext"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAB");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SAB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attribs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "attribs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "AttributeValue"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("code");
        elemField.setXmlName(new javax.xml.namespace.QName("", "code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
