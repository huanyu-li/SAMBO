/**
 * SourceCxt.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.context;

public class SourceCxt  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private gov.nih.nlm.kss.models.meta.context.CxtMember[] ANC;

    private gov.nih.nlm.kss.models.meta.context.CxtMember CCP;

    private gov.nih.nlm.kss.models.meta.context.CxtMember[] CHD;

    private java.lang.String CXN;

    private gov.nih.nlm.kss.models.meta.context.CxtMember[] DES;

    private gov.nih.nlm.kss.models.meta.context.CxtMember[] SIB;

    public SourceCxt() {
    }

    public SourceCxt(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.models.meta.context.CxtMember[] ANC,
           gov.nih.nlm.kss.models.meta.context.CxtMember CCP,
           gov.nih.nlm.kss.models.meta.context.CxtMember[] CHD,
           java.lang.String CXN,
           gov.nih.nlm.kss.models.meta.context.CxtMember[] DES,
           gov.nih.nlm.kss.models.meta.context.CxtMember[] SIB) {
        super(
            key,
            performanceMode);
        this.ANC = ANC;
        this.CCP = CCP;
        this.CHD = CHD;
        this.CXN = CXN;
        this.DES = DES;
        this.SIB = SIB;
    }


    /**
     * Gets the ANC value for this SourceCxt.
     * 
     * @return ANC
     */
    public gov.nih.nlm.kss.models.meta.context.CxtMember[] getANC() {
        return ANC;
    }


    /**
     * Sets the ANC value for this SourceCxt.
     * 
     * @param ANC
     */
    public void setANC(gov.nih.nlm.kss.models.meta.context.CxtMember[] ANC) {
        this.ANC = ANC;
    }


    /**
     * Gets the CCP value for this SourceCxt.
     * 
     * @return CCP
     */
    public gov.nih.nlm.kss.models.meta.context.CxtMember getCCP() {
        return CCP;
    }


    /**
     * Sets the CCP value for this SourceCxt.
     * 
     * @param CCP
     */
    public void setCCP(gov.nih.nlm.kss.models.meta.context.CxtMember CCP) {
        this.CCP = CCP;
    }


    /**
     * Gets the CHD value for this SourceCxt.
     * 
     * @return CHD
     */
    public gov.nih.nlm.kss.models.meta.context.CxtMember[] getCHD() {
        return CHD;
    }


    /**
     * Sets the CHD value for this SourceCxt.
     * 
     * @param CHD
     */
    public void setCHD(gov.nih.nlm.kss.models.meta.context.CxtMember[] CHD) {
        this.CHD = CHD;
    }


    /**
     * Gets the CXN value for this SourceCxt.
     * 
     * @return CXN
     */
    public java.lang.String getCXN() {
        return CXN;
    }


    /**
     * Sets the CXN value for this SourceCxt.
     * 
     * @param CXN
     */
    public void setCXN(java.lang.String CXN) {
        this.CXN = CXN;
    }


    /**
     * Gets the DES value for this SourceCxt.
     * 
     * @return DES
     */
    public gov.nih.nlm.kss.models.meta.context.CxtMember[] getDES() {
        return DES;
    }


    /**
     * Sets the DES value for this SourceCxt.
     * 
     * @param DES
     */
    public void setDES(gov.nih.nlm.kss.models.meta.context.CxtMember[] DES) {
        this.DES = DES;
    }


    /**
     * Gets the SIB value for this SourceCxt.
     * 
     * @return SIB
     */
    public gov.nih.nlm.kss.models.meta.context.CxtMember[] getSIB() {
        return SIB;
    }


    /**
     * Sets the SIB value for this SourceCxt.
     * 
     * @param SIB
     */
    public void setSIB(gov.nih.nlm.kss.models.meta.context.CxtMember[] SIB) {
        this.SIB = SIB;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SourceCxt)) return false;
        SourceCxt other = (SourceCxt) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.ANC==null && other.getANC()==null) || 
             (this.ANC!=null &&
              java.util.Arrays.equals(this.ANC, other.getANC()))) &&
            ((this.CCP==null && other.getCCP()==null) || 
             (this.CCP!=null &&
              this.CCP.equals(other.getCCP()))) &&
            ((this.CHD==null && other.getCHD()==null) || 
             (this.CHD!=null &&
              java.util.Arrays.equals(this.CHD, other.getCHD()))) &&
            ((this.CXN==null && other.getCXN()==null) || 
             (this.CXN!=null &&
              this.CXN.equals(other.getCXN()))) &&
            ((this.DES==null && other.getDES()==null) || 
             (this.DES!=null &&
              java.util.Arrays.equals(this.DES, other.getDES()))) &&
            ((this.SIB==null && other.getSIB()==null) || 
             (this.SIB!=null &&
              java.util.Arrays.equals(this.SIB, other.getSIB())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getANC() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getANC());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getANC(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCCP() != null) {
            _hashCode += getCCP().hashCode();
        }
        if (getCHD() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCHD());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCHD(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCXN() != null) {
            _hashCode += getCXN().hashCode();
        }
        if (getDES() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDES());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDES(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSIB() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSIB());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSIB(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SourceCxt.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "SourceCxt"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ANC");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ANC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "CxtMember"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CCP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "CxtMember"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CHD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "CxtMember"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CXN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CXN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DES");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DES"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "CxtMember"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SIB");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SIB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "CxtMember"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
