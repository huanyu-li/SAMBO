/**
 * Concept.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.concept;

public class Concept  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private gov.nih.nlm.kss.models.meta.attribute.ConceptAttributeGroup CAs;

    private java.lang.String CN;

    private gov.nih.nlm.kss.models.meta.cooccurrence.CooccurrenceGroup COCs;

    private java.lang.String CUI;

    private gov.nih.nlm.kss.models.meta.context.ContextGroup CXTs;

    private gov.nih.nlm.kss.models.meta.attribute.RelationshipAttributeGroup RAs;

    private gov.nih.nlm.kss.models.sem.units.SemGroupGroup SGs;

    private gov.nih.nlm.kss.models.meta.concept.SemTypeGroup STYs;

    private gov.nih.nlm.kss.models.meta.concept.DefinitionGroup defs;

    private gov.nih.nlm.kss.models.meta.relation.RelationGroup rels;

    private gov.nih.nlm.kss.models.meta.concept.TermGroup terms;

    public Concept() {
    }

    public Concept(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.models.meta.attribute.ConceptAttributeGroup CAs,
           java.lang.String CN,
           gov.nih.nlm.kss.models.meta.cooccurrence.CooccurrenceGroup COCs,
           java.lang.String CUI,
           gov.nih.nlm.kss.models.meta.context.ContextGroup CXTs,
           gov.nih.nlm.kss.models.meta.attribute.RelationshipAttributeGroup RAs,
           gov.nih.nlm.kss.models.sem.units.SemGroupGroup SGs,
           gov.nih.nlm.kss.models.meta.concept.SemTypeGroup STYs,
           gov.nih.nlm.kss.models.meta.concept.DefinitionGroup defs,
           gov.nih.nlm.kss.models.meta.relation.RelationGroup rels,
           gov.nih.nlm.kss.models.meta.concept.TermGroup terms) {
        super(
            key,
            performanceMode);
        this.CAs = CAs;
        this.CN = CN;
        this.COCs = COCs;
        this.CUI = CUI;
        this.CXTs = CXTs;
        this.RAs = RAs;
        this.SGs = SGs;
        this.STYs = STYs;
        this.defs = defs;
        this.rels = rels;
        this.terms = terms;
    }


    /**
     * Gets the CAs value for this Concept.
     * 
     * @return CAs
     */
    public gov.nih.nlm.kss.models.meta.attribute.ConceptAttributeGroup getCAs() {
        return CAs;
    }


    /**
     * Sets the CAs value for this Concept.
     * 
     * @param CAs
     */
    public void setCAs(gov.nih.nlm.kss.models.meta.attribute.ConceptAttributeGroup CAs) {
        this.CAs = CAs;
    }


    /**
     * Gets the CN value for this Concept.
     * 
     * @return CN
     */
    public java.lang.String getCN() {
        return CN;
    }


    /**
     * Sets the CN value for this Concept.
     * 
     * @param CN
     */
    public void setCN(java.lang.String CN) {
        this.CN = CN;
    }


    /**
     * Gets the COCs value for this Concept.
     * 
     * @return COCs
     */
    public gov.nih.nlm.kss.models.meta.cooccurrence.CooccurrenceGroup getCOCs() {
        return COCs;
    }


    /**
     * Sets the COCs value for this Concept.
     * 
     * @param COCs
     */
    public void setCOCs(gov.nih.nlm.kss.models.meta.cooccurrence.CooccurrenceGroup COCs) {
        this.COCs = COCs;
    }


    /**
     * Gets the CUI value for this Concept.
     * 
     * @return CUI
     */
    public java.lang.String getCUI() {
        return CUI;
    }


    /**
     * Sets the CUI value for this Concept.
     * 
     * @param CUI
     */
    public void setCUI(java.lang.String CUI) {
        this.CUI = CUI;
    }


    /**
     * Gets the CXTs value for this Concept.
     * 
     * @return CXTs
     */
    public gov.nih.nlm.kss.models.meta.context.ContextGroup getCXTs() {
        return CXTs;
    }


    /**
     * Sets the CXTs value for this Concept.
     * 
     * @param CXTs
     */
    public void setCXTs(gov.nih.nlm.kss.models.meta.context.ContextGroup CXTs) {
        this.CXTs = CXTs;
    }


    /**
     * Gets the RAs value for this Concept.
     * 
     * @return RAs
     */
    public gov.nih.nlm.kss.models.meta.attribute.RelationshipAttributeGroup getRAs() {
        return RAs;
    }


    /**
     * Sets the RAs value for this Concept.
     * 
     * @param RAs
     */
    public void setRAs(gov.nih.nlm.kss.models.meta.attribute.RelationshipAttributeGroup RAs) {
        this.RAs = RAs;
    }


    /**
     * Gets the SGs value for this Concept.
     * 
     * @return SGs
     */
    public gov.nih.nlm.kss.models.sem.units.SemGroupGroup getSGs() {
        return SGs;
    }


    /**
     * Sets the SGs value for this Concept.
     * 
     * @param SGs
     */
    public void setSGs(gov.nih.nlm.kss.models.sem.units.SemGroupGroup SGs) {
        this.SGs = SGs;
    }


    /**
     * Gets the STYs value for this Concept.
     * 
     * @return STYs
     */
    public gov.nih.nlm.kss.models.meta.concept.SemTypeGroup getSTYs() {
        return STYs;
    }


    /**
     * Sets the STYs value for this Concept.
     * 
     * @param STYs
     */
    public void setSTYs(gov.nih.nlm.kss.models.meta.concept.SemTypeGroup STYs) {
        this.STYs = STYs;
    }


    /**
     * Gets the defs value for this Concept.
     * 
     * @return defs
     */
    public gov.nih.nlm.kss.models.meta.concept.DefinitionGroup getDefs() {
        return defs;
    }


    /**
     * Sets the defs value for this Concept.
     * 
     * @param defs
     */
    public void setDefs(gov.nih.nlm.kss.models.meta.concept.DefinitionGroup defs) {
        this.defs = defs;
    }


    /**
     * Gets the rels value for this Concept.
     * 
     * @return rels
     */
    public gov.nih.nlm.kss.models.meta.relation.RelationGroup getRels() {
        return rels;
    }


    /**
     * Sets the rels value for this Concept.
     * 
     * @param rels
     */
    public void setRels(gov.nih.nlm.kss.models.meta.relation.RelationGroup rels) {
        this.rels = rels;
    }


    /**
     * Gets the terms value for this Concept.
     * 
     * @return terms
     */
    public gov.nih.nlm.kss.models.meta.concept.TermGroup getTerms() {
        return terms;
    }


    /**
     * Sets the terms value for this Concept.
     * 
     * @param terms
     */
    public void setTerms(gov.nih.nlm.kss.models.meta.concept.TermGroup terms) {
        this.terms = terms;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Concept)) return false;
        Concept other = (Concept) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.CAs==null && other.getCAs()==null) || 
             (this.CAs!=null &&
              this.CAs.equals(other.getCAs()))) &&
            ((this.CN==null && other.getCN()==null) || 
             (this.CN!=null &&
              this.CN.equals(other.getCN()))) &&
            ((this.COCs==null && other.getCOCs()==null) || 
             (this.COCs!=null &&
              this.COCs.equals(other.getCOCs()))) &&
            ((this.CUI==null && other.getCUI()==null) || 
             (this.CUI!=null &&
              this.CUI.equals(other.getCUI()))) &&
            ((this.CXTs==null && other.getCXTs()==null) || 
             (this.CXTs!=null &&
              this.CXTs.equals(other.getCXTs()))) &&
            ((this.RAs==null && other.getRAs()==null) || 
             (this.RAs!=null &&
              this.RAs.equals(other.getRAs()))) &&
            ((this.SGs==null && other.getSGs()==null) || 
             (this.SGs!=null &&
              this.SGs.equals(other.getSGs()))) &&
            ((this.STYs==null && other.getSTYs()==null) || 
             (this.STYs!=null &&
              this.STYs.equals(other.getSTYs()))) &&
            ((this.defs==null && other.getDefs()==null) || 
             (this.defs!=null &&
              this.defs.equals(other.getDefs()))) &&
            ((this.rels==null && other.getRels()==null) || 
             (this.rels!=null &&
              this.rels.equals(other.getRels()))) &&
            ((this.terms==null && other.getTerms()==null) || 
             (this.terms!=null &&
              this.terms.equals(other.getTerms())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCAs() != null) {
            _hashCode += getCAs().hashCode();
        }
        if (getCN() != null) {
            _hashCode += getCN().hashCode();
        }
        if (getCOCs() != null) {
            _hashCode += getCOCs().hashCode();
        }
        if (getCUI() != null) {
            _hashCode += getCUI().hashCode();
        }
        if (getCXTs() != null) {
            _hashCode += getCXTs().hashCode();
        }
        if (getRAs() != null) {
            _hashCode += getRAs().hashCode();
        }
        if (getSGs() != null) {
            _hashCode += getSGs().hashCode();
        }
        if (getSTYs() != null) {
            _hashCode += getSTYs().hashCode();
        }
        if (getDefs() != null) {
            _hashCode += getDefs().hashCode();
        }
        if (getRels() != null) {
            _hashCode += getRels().hashCode();
        }
        if (getTerms() != null) {
            _hashCode += getTerms().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Concept.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "Concept"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CAs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CAs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "ConceptAttributeGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COCs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "COCs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://cooccurrence.meta.models.kss.nlm.nih.gov", "CooccurrenceGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CXTs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CXTs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "ContextGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RAs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RAs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "RelationshipAttributeGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SGs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SGs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemGroupGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STYs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STYs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "SemTypeGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "defs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "DefinitionGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rels");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rels"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://relation.meta.models.kss.nlm.nih.gov", "RelationGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terms");
        elemField.setXmlName(new javax.xml.namespace.QName("", "terms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "TermGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
