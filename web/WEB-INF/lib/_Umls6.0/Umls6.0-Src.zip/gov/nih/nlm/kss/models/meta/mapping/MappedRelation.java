/**
 * MappedRelation.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.mapping;

public class MappedRelation  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String attributeName;

    private java.lang.String attributeValue;

    private java.lang.String id;

    private gov.nih.nlm.kss.models.meta.mapping.MapRelation mapRelation;

    private int rank;

    private java.lang.String restriction;

    private java.lang.String rule;

    private gov.nih.nlm.kss.models.meta.mapping.MapEntry sourceMapEntry;

    private java.lang.String srcId;

    private gov.nih.nlm.kss.models.meta.mapping.MapEntry targetMapEntry;

    private java.lang.String type;

    public MappedRelation() {
    }

    public MappedRelation(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String attributeName,
           java.lang.String attributeValue,
           java.lang.String id,
           gov.nih.nlm.kss.models.meta.mapping.MapRelation mapRelation,
           int rank,
           java.lang.String restriction,
           java.lang.String rule,
           gov.nih.nlm.kss.models.meta.mapping.MapEntry sourceMapEntry,
           java.lang.String srcId,
           gov.nih.nlm.kss.models.meta.mapping.MapEntry targetMapEntry,
           java.lang.String type) {
        super(
            key,
            performanceMode);
        this.attributeName = attributeName;
        this.attributeValue = attributeValue;
        this.id = id;
        this.mapRelation = mapRelation;
        this.rank = rank;
        this.restriction = restriction;
        this.rule = rule;
        this.sourceMapEntry = sourceMapEntry;
        this.srcId = srcId;
        this.targetMapEntry = targetMapEntry;
        this.type = type;
    }


    /**
     * Gets the attributeName value for this MappedRelation.
     * 
     * @return attributeName
     */
    public java.lang.String getAttributeName() {
        return attributeName;
    }


    /**
     * Sets the attributeName value for this MappedRelation.
     * 
     * @param attributeName
     */
    public void setAttributeName(java.lang.String attributeName) {
        this.attributeName = attributeName;
    }


    /**
     * Gets the attributeValue value for this MappedRelation.
     * 
     * @return attributeValue
     */
    public java.lang.String getAttributeValue() {
        return attributeValue;
    }


    /**
     * Sets the attributeValue value for this MappedRelation.
     * 
     * @param attributeValue
     */
    public void setAttributeValue(java.lang.String attributeValue) {
        this.attributeValue = attributeValue;
    }


    /**
     * Gets the id value for this MappedRelation.
     * 
     * @return id
     */
    public java.lang.String getId() {
        return id;
    }


    /**
     * Sets the id value for this MappedRelation.
     * 
     * @param id
     */
    public void setId(java.lang.String id) {
        this.id = id;
    }


    /**
     * Gets the mapRelation value for this MappedRelation.
     * 
     * @return mapRelation
     */
    public gov.nih.nlm.kss.models.meta.mapping.MapRelation getMapRelation() {
        return mapRelation;
    }


    /**
     * Sets the mapRelation value for this MappedRelation.
     * 
     * @param mapRelation
     */
    public void setMapRelation(gov.nih.nlm.kss.models.meta.mapping.MapRelation mapRelation) {
        this.mapRelation = mapRelation;
    }


    /**
     * Gets the rank value for this MappedRelation.
     * 
     * @return rank
     */
    public int getRank() {
        return rank;
    }


    /**
     * Sets the rank value for this MappedRelation.
     * 
     * @param rank
     */
    public void setRank(int rank) {
        this.rank = rank;
    }


    /**
     * Gets the restriction value for this MappedRelation.
     * 
     * @return restriction
     */
    public java.lang.String getRestriction() {
        return restriction;
    }


    /**
     * Sets the restriction value for this MappedRelation.
     * 
     * @param restriction
     */
    public void setRestriction(java.lang.String restriction) {
        this.restriction = restriction;
    }


    /**
     * Gets the rule value for this MappedRelation.
     * 
     * @return rule
     */
    public java.lang.String getRule() {
        return rule;
    }


    /**
     * Sets the rule value for this MappedRelation.
     * 
     * @param rule
     */
    public void setRule(java.lang.String rule) {
        this.rule = rule;
    }


    /**
     * Gets the sourceMapEntry value for this MappedRelation.
     * 
     * @return sourceMapEntry
     */
    public gov.nih.nlm.kss.models.meta.mapping.MapEntry getSourceMapEntry() {
        return sourceMapEntry;
    }


    /**
     * Sets the sourceMapEntry value for this MappedRelation.
     * 
     * @param sourceMapEntry
     */
    public void setSourceMapEntry(gov.nih.nlm.kss.models.meta.mapping.MapEntry sourceMapEntry) {
        this.sourceMapEntry = sourceMapEntry;
    }


    /**
     * Gets the srcId value for this MappedRelation.
     * 
     * @return srcId
     */
    public java.lang.String getSrcId() {
        return srcId;
    }


    /**
     * Sets the srcId value for this MappedRelation.
     * 
     * @param srcId
     */
    public void setSrcId(java.lang.String srcId) {
        this.srcId = srcId;
    }


    /**
     * Gets the targetMapEntry value for this MappedRelation.
     * 
     * @return targetMapEntry
     */
    public gov.nih.nlm.kss.models.meta.mapping.MapEntry getTargetMapEntry() {
        return targetMapEntry;
    }


    /**
     * Sets the targetMapEntry value for this MappedRelation.
     * 
     * @param targetMapEntry
     */
    public void setTargetMapEntry(gov.nih.nlm.kss.models.meta.mapping.MapEntry targetMapEntry) {
        this.targetMapEntry = targetMapEntry;
    }


    /**
     * Gets the type value for this MappedRelation.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this MappedRelation.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MappedRelation)) return false;
        MappedRelation other = (MappedRelation) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.attributeName==null && other.getAttributeName()==null) || 
             (this.attributeName!=null &&
              this.attributeName.equals(other.getAttributeName()))) &&
            ((this.attributeValue==null && other.getAttributeValue()==null) || 
             (this.attributeValue!=null &&
              this.attributeValue.equals(other.getAttributeValue()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.mapRelation==null && other.getMapRelation()==null) || 
             (this.mapRelation!=null &&
              this.mapRelation.equals(other.getMapRelation()))) &&
            this.rank == other.getRank() &&
            ((this.restriction==null && other.getRestriction()==null) || 
             (this.restriction!=null &&
              this.restriction.equals(other.getRestriction()))) &&
            ((this.rule==null && other.getRule()==null) || 
             (this.rule!=null &&
              this.rule.equals(other.getRule()))) &&
            ((this.sourceMapEntry==null && other.getSourceMapEntry()==null) || 
             (this.sourceMapEntry!=null &&
              this.sourceMapEntry.equals(other.getSourceMapEntry()))) &&
            ((this.srcId==null && other.getSrcId()==null) || 
             (this.srcId!=null &&
              this.srcId.equals(other.getSrcId()))) &&
            ((this.targetMapEntry==null && other.getTargetMapEntry()==null) || 
             (this.targetMapEntry!=null &&
              this.targetMapEntry.equals(other.getTargetMapEntry()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAttributeName() != null) {
            _hashCode += getAttributeName().hashCode();
        }
        if (getAttributeValue() != null) {
            _hashCode += getAttributeValue().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getMapRelation() != null) {
            _hashCode += getMapRelation().hashCode();
        }
        _hashCode += getRank();
        if (getRestriction() != null) {
            _hashCode += getRestriction().hashCode();
        }
        if (getRule() != null) {
            _hashCode += getRule().hashCode();
        }
        if (getSourceMapEntry() != null) {
            _hashCode += getSourceMapEntry().hashCode();
        }
        if (getSrcId() != null) {
            _hashCode += getSrcId().hashCode();
        }
        if (getTargetMapEntry() != null) {
            _hashCode += getTargetMapEntry().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MappedRelation.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MappedRelation"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attributeName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "attributeName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attributeValue");
        elemField.setXmlName(new javax.xml.namespace.QName("", "attributeValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mapRelation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mapRelation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapRelation"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rank");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rank"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("restriction");
        elemField.setXmlName(new javax.xml.namespace.QName("", "restriction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rule");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rule"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sourceMapEntry");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sourceMapEntry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapEntry"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("srcId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "srcId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("targetMapEntry");
        elemField.setXmlName(new javax.xml.namespace.QName("", "targetMapEntry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapEntry"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
