/**
 * MapSet.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.mapping;

public class MapSet  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String CUI;

    private java.lang.String SAB;

    private java.lang.String name;

    private gov.nih.nlm.kss.models.meta.mapping.MapSubset[] subsetMaps;

    public MapSet() {
    }

    public MapSet(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String CUI,
           java.lang.String SAB,
           java.lang.String name,
           gov.nih.nlm.kss.models.meta.mapping.MapSubset[] subsetMaps) {
        super(
            key,
            performanceMode);
        this.CUI = CUI;
        this.SAB = SAB;
        this.name = name;
        this.subsetMaps = subsetMaps;
    }


    /**
     * Gets the CUI value for this MapSet.
     * 
     * @return CUI
     */
    public java.lang.String getCUI() {
        return CUI;
    }


    /**
     * Sets the CUI value for this MapSet.
     * 
     * @param CUI
     */
    public void setCUI(java.lang.String CUI) {
        this.CUI = CUI;
    }


    /**
     * Gets the SAB value for this MapSet.
     * 
     * @return SAB
     */
    public java.lang.String getSAB() {
        return SAB;
    }


    /**
     * Sets the SAB value for this MapSet.
     * 
     * @param SAB
     */
    public void setSAB(java.lang.String SAB) {
        this.SAB = SAB;
    }


    /**
     * Gets the name value for this MapSet.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this MapSet.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the subsetMaps value for this MapSet.
     * 
     * @return subsetMaps
     */
    public gov.nih.nlm.kss.models.meta.mapping.MapSubset[] getSubsetMaps() {
        return subsetMaps;
    }


    /**
     * Sets the subsetMaps value for this MapSet.
     * 
     * @param subsetMaps
     */
    public void setSubsetMaps(gov.nih.nlm.kss.models.meta.mapping.MapSubset[] subsetMaps) {
        this.subsetMaps = subsetMaps;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MapSet)) return false;
        MapSet other = (MapSet) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.CUI==null && other.getCUI()==null) || 
             (this.CUI!=null &&
              this.CUI.equals(other.getCUI()))) &&
            ((this.SAB==null && other.getSAB()==null) || 
             (this.SAB!=null &&
              this.SAB.equals(other.getSAB()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.subsetMaps==null && other.getSubsetMaps()==null) || 
             (this.subsetMaps!=null &&
              java.util.Arrays.equals(this.subsetMaps, other.getSubsetMaps())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCUI() != null) {
            _hashCode += getCUI().hashCode();
        }
        if (getSAB() != null) {
            _hashCode += getSAB().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getSubsetMaps() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSubsetMaps());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSubsetMaps(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MapSet.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapSet"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAB");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SAB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subsetMaps");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subsetMaps"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapSubset"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
