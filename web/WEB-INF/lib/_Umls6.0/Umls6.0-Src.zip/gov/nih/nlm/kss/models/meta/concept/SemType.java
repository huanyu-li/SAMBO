/**
 * SemType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.concept;

public class SemType  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String ATUI;

    private java.lang.String STY;

    private java.lang.String TUI;

    public SemType() {
    }

    public SemType(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String ATUI,
           java.lang.String STY,
           java.lang.String TUI) {
        super(
            key,
            performanceMode);
        this.ATUI = ATUI;
        this.STY = STY;
        this.TUI = TUI;
    }


    /**
     * Gets the ATUI value for this SemType.
     * 
     * @return ATUI
     */
    public java.lang.String getATUI() {
        return ATUI;
    }


    /**
     * Sets the ATUI value for this SemType.
     * 
     * @param ATUI
     */
    public void setATUI(java.lang.String ATUI) {
        this.ATUI = ATUI;
    }


    /**
     * Gets the STY value for this SemType.
     * 
     * @return STY
     */
    public java.lang.String getSTY() {
        return STY;
    }


    /**
     * Sets the STY value for this SemType.
     * 
     * @param STY
     */
    public void setSTY(java.lang.String STY) {
        this.STY = STY;
    }


    /**
     * Gets the TUI value for this SemType.
     * 
     * @return TUI
     */
    public java.lang.String getTUI() {
        return TUI;
    }


    /**
     * Sets the TUI value for this SemType.
     * 
     * @param TUI
     */
    public void setTUI(java.lang.String TUI) {
        this.TUI = TUI;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SemType)) return false;
        SemType other = (SemType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.ATUI==null && other.getATUI()==null) || 
             (this.ATUI!=null &&
              this.ATUI.equals(other.getATUI()))) &&
            ((this.STY==null && other.getSTY()==null) || 
             (this.STY!=null &&
              this.STY.equals(other.getSTY()))) &&
            ((this.TUI==null && other.getTUI()==null) || 
             (this.TUI!=null &&
              this.TUI.equals(other.getTUI())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getATUI() != null) {
            _hashCode += getATUI().hashCode();
        }
        if (getSTY() != null) {
            _hashCode += getSTY().hashCode();
        }
        if (getTUI() != null) {
            _hashCode += getTUI().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SemType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "SemType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ATUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ATUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
