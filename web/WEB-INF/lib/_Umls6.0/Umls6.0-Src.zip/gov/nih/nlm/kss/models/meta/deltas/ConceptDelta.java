/**
 * ConceptDelta.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.deltas;

public class ConceptDelta  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String CUI;

    private java.lang.String changeAttribute;

    private int changeType;

    private java.lang.String mapReason;

    private java.lang.String mergeCUI;

    public ConceptDelta() {
    }

    public ConceptDelta(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String CUI,
           java.lang.String changeAttribute,
           int changeType,
           java.lang.String mapReason,
           java.lang.String mergeCUI) {
        super(
            key,
            performanceMode);
        this.CUI = CUI;
        this.changeAttribute = changeAttribute;
        this.changeType = changeType;
        this.mapReason = mapReason;
        this.mergeCUI = mergeCUI;
    }


    /**
     * Gets the CUI value for this ConceptDelta.
     * 
     * @return CUI
     */
    public java.lang.String getCUI() {
        return CUI;
    }


    /**
     * Sets the CUI value for this ConceptDelta.
     * 
     * @param CUI
     */
    public void setCUI(java.lang.String CUI) {
        this.CUI = CUI;
    }


    /**
     * Gets the changeAttribute value for this ConceptDelta.
     * 
     * @return changeAttribute
     */
    public java.lang.String getChangeAttribute() {
        return changeAttribute;
    }


    /**
     * Sets the changeAttribute value for this ConceptDelta.
     * 
     * @param changeAttribute
     */
    public void setChangeAttribute(java.lang.String changeAttribute) {
        this.changeAttribute = changeAttribute;
    }


    /**
     * Gets the changeType value for this ConceptDelta.
     * 
     * @return changeType
     */
    public int getChangeType() {
        return changeType;
    }


    /**
     * Sets the changeType value for this ConceptDelta.
     * 
     * @param changeType
     */
    public void setChangeType(int changeType) {
        this.changeType = changeType;
    }


    /**
     * Gets the mapReason value for this ConceptDelta.
     * 
     * @return mapReason
     */
    public java.lang.String getMapReason() {
        return mapReason;
    }


    /**
     * Sets the mapReason value for this ConceptDelta.
     * 
     * @param mapReason
     */
    public void setMapReason(java.lang.String mapReason) {
        this.mapReason = mapReason;
    }


    /**
     * Gets the mergeCUI value for this ConceptDelta.
     * 
     * @return mergeCUI
     */
    public java.lang.String getMergeCUI() {
        return mergeCUI;
    }


    /**
     * Sets the mergeCUI value for this ConceptDelta.
     * 
     * @param mergeCUI
     */
    public void setMergeCUI(java.lang.String mergeCUI) {
        this.mergeCUI = mergeCUI;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConceptDelta)) return false;
        ConceptDelta other = (ConceptDelta) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.CUI==null && other.getCUI()==null) || 
             (this.CUI!=null &&
              this.CUI.equals(other.getCUI()))) &&
            ((this.changeAttribute==null && other.getChangeAttribute()==null) || 
             (this.changeAttribute!=null &&
              this.changeAttribute.equals(other.getChangeAttribute()))) &&
            this.changeType == other.getChangeType() &&
            ((this.mapReason==null && other.getMapReason()==null) || 
             (this.mapReason!=null &&
              this.mapReason.equals(other.getMapReason()))) &&
            ((this.mergeCUI==null && other.getMergeCUI()==null) || 
             (this.mergeCUI!=null &&
              this.mergeCUI.equals(other.getMergeCUI())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCUI() != null) {
            _hashCode += getCUI().hashCode();
        }
        if (getChangeAttribute() != null) {
            _hashCode += getChangeAttribute().hashCode();
        }
        _hashCode += getChangeType();
        if (getMapReason() != null) {
            _hashCode += getMapReason().hashCode();
        }
        if (getMergeCUI() != null) {
            _hashCode += getMergeCUI().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConceptDelta.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "ConceptDelta"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("changeAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "changeAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("changeType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "changeType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mapReason");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mapReason"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mergeCUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mergeCUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
