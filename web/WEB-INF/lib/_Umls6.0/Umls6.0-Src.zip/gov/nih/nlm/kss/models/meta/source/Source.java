/**
 * Source.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.source;

public class Source  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private int CUIFrequency;

    private java.lang.String RCUI;

    private java.lang.String RSAB;

    private java.lang.String SAB;

    private java.lang.String SCIT;

    private java.lang.String VCUI;

    private java.lang.String VSAB;

    private java.lang.String[] attrNameList;

    private java.lang.String charEncode;

    private java.lang.String contentContact;

    private java.lang.String context;

    private boolean currentVersion;

    private java.lang.String family;

    private java.lang.String insert;

    private java.lang.String language;

    private java.lang.String licenseContact;

    private java.lang.String metaEnd;

    private java.lang.String metaStart;

    private java.lang.String name;

    private java.lang.String nickName;

    private java.lang.String remove;

    private boolean sabin;

    private int termFrequency;

    private java.lang.String[] termTypeList;

    private java.lang.String version;

    public Source() {
    }

    public Source(
           java.lang.String key,
           boolean performanceMode,
           int CUIFrequency,
           java.lang.String RCUI,
           java.lang.String RSAB,
           java.lang.String SAB,
           java.lang.String SCIT,
           java.lang.String VCUI,
           java.lang.String VSAB,
           java.lang.String[] attrNameList,
           java.lang.String charEncode,
           java.lang.String contentContact,
           java.lang.String context,
           boolean currentVersion,
           java.lang.String family,
           java.lang.String insert,
           java.lang.String language,
           java.lang.String licenseContact,
           java.lang.String metaEnd,
           java.lang.String metaStart,
           java.lang.String name,
           java.lang.String nickName,
           java.lang.String remove,
           boolean sabin,
           int termFrequency,
           java.lang.String[] termTypeList,
           java.lang.String version) {
        super(
            key,
            performanceMode);
        this.CUIFrequency = CUIFrequency;
        this.RCUI = RCUI;
        this.RSAB = RSAB;
        this.SAB = SAB;
        this.SCIT = SCIT;
        this.VCUI = VCUI;
        this.VSAB = VSAB;
        this.attrNameList = attrNameList;
        this.charEncode = charEncode;
        this.contentContact = contentContact;
        this.context = context;
        this.currentVersion = currentVersion;
        this.family = family;
        this.insert = insert;
        this.language = language;
        this.licenseContact = licenseContact;
        this.metaEnd = metaEnd;
        this.metaStart = metaStart;
        this.name = name;
        this.nickName = nickName;
        this.remove = remove;
        this.sabin = sabin;
        this.termFrequency = termFrequency;
        this.termTypeList = termTypeList;
        this.version = version;
    }


    /**
     * Gets the CUIFrequency value for this Source.
     * 
     * @return CUIFrequency
     */
    public int getCUIFrequency() {
        return CUIFrequency;
    }


    /**
     * Sets the CUIFrequency value for this Source.
     * 
     * @param CUIFrequency
     */
    public void setCUIFrequency(int CUIFrequency) {
        this.CUIFrequency = CUIFrequency;
    }


    /**
     * Gets the RCUI value for this Source.
     * 
     * @return RCUI
     */
    public java.lang.String getRCUI() {
        return RCUI;
    }


    /**
     * Sets the RCUI value for this Source.
     * 
     * @param RCUI
     */
    public void setRCUI(java.lang.String RCUI) {
        this.RCUI = RCUI;
    }


    /**
     * Gets the RSAB value for this Source.
     * 
     * @return RSAB
     */
    public java.lang.String getRSAB() {
        return RSAB;
    }


    /**
     * Sets the RSAB value for this Source.
     * 
     * @param RSAB
     */
    public void setRSAB(java.lang.String RSAB) {
        this.RSAB = RSAB;
    }


    /**
     * Gets the SAB value for this Source.
     * 
     * @return SAB
     */
    public java.lang.String getSAB() {
        return SAB;
    }


    /**
     * Sets the SAB value for this Source.
     * 
     * @param SAB
     */
    public void setSAB(java.lang.String SAB) {
        this.SAB = SAB;
    }


    /**
     * Gets the SCIT value for this Source.
     * 
     * @return SCIT
     */
    public java.lang.String getSCIT() {
        return SCIT;
    }


    /**
     * Sets the SCIT value for this Source.
     * 
     * @param SCIT
     */
    public void setSCIT(java.lang.String SCIT) {
        this.SCIT = SCIT;
    }


    /**
     * Gets the VCUI value for this Source.
     * 
     * @return VCUI
     */
    public java.lang.String getVCUI() {
        return VCUI;
    }


    /**
     * Sets the VCUI value for this Source.
     * 
     * @param VCUI
     */
    public void setVCUI(java.lang.String VCUI) {
        this.VCUI = VCUI;
    }


    /**
     * Gets the VSAB value for this Source.
     * 
     * @return VSAB
     */
    public java.lang.String getVSAB() {
        return VSAB;
    }


    /**
     * Sets the VSAB value for this Source.
     * 
     * @param VSAB
     */
    public void setVSAB(java.lang.String VSAB) {
        this.VSAB = VSAB;
    }


    /**
     * Gets the attrNameList value for this Source.
     * 
     * @return attrNameList
     */
    public java.lang.String[] getAttrNameList() {
        return attrNameList;
    }


    /**
     * Sets the attrNameList value for this Source.
     * 
     * @param attrNameList
     */
    public void setAttrNameList(java.lang.String[] attrNameList) {
        this.attrNameList = attrNameList;
    }


    /**
     * Gets the charEncode value for this Source.
     * 
     * @return charEncode
     */
    public java.lang.String getCharEncode() {
        return charEncode;
    }


    /**
     * Sets the charEncode value for this Source.
     * 
     * @param charEncode
     */
    public void setCharEncode(java.lang.String charEncode) {
        this.charEncode = charEncode;
    }


    /**
     * Gets the contentContact value for this Source.
     * 
     * @return contentContact
     */
    public java.lang.String getContentContact() {
        return contentContact;
    }


    /**
     * Sets the contentContact value for this Source.
     * 
     * @param contentContact
     */
    public void setContentContact(java.lang.String contentContact) {
        this.contentContact = contentContact;
    }


    /**
     * Gets the context value for this Source.
     * 
     * @return context
     */
    public java.lang.String getContext() {
        return context;
    }


    /**
     * Sets the context value for this Source.
     * 
     * @param context
     */
    public void setContext(java.lang.String context) {
        this.context = context;
    }


    /**
     * Gets the currentVersion value for this Source.
     * 
     * @return currentVersion
     */
    public boolean isCurrentVersion() {
        return currentVersion;
    }


    /**
     * Sets the currentVersion value for this Source.
     * 
     * @param currentVersion
     */
    public void setCurrentVersion(boolean currentVersion) {
        this.currentVersion = currentVersion;
    }


    /**
     * Gets the family value for this Source.
     * 
     * @return family
     */
    public java.lang.String getFamily() {
        return family;
    }


    /**
     * Sets the family value for this Source.
     * 
     * @param family
     */
    public void setFamily(java.lang.String family) {
        this.family = family;
    }


    /**
     * Gets the insert value for this Source.
     * 
     * @return insert
     */
    public java.lang.String getInsert() {
        return insert;
    }


    /**
     * Sets the insert value for this Source.
     * 
     * @param insert
     */
    public void setInsert(java.lang.String insert) {
        this.insert = insert;
    }


    /**
     * Gets the language value for this Source.
     * 
     * @return language
     */
    public java.lang.String getLanguage() {
        return language;
    }


    /**
     * Sets the language value for this Source.
     * 
     * @param language
     */
    public void setLanguage(java.lang.String language) {
        this.language = language;
    }


    /**
     * Gets the licenseContact value for this Source.
     * 
     * @return licenseContact
     */
    public java.lang.String getLicenseContact() {
        return licenseContact;
    }


    /**
     * Sets the licenseContact value for this Source.
     * 
     * @param licenseContact
     */
    public void setLicenseContact(java.lang.String licenseContact) {
        this.licenseContact = licenseContact;
    }


    /**
     * Gets the metaEnd value for this Source.
     * 
     * @return metaEnd
     */
    public java.lang.String getMetaEnd() {
        return metaEnd;
    }


    /**
     * Sets the metaEnd value for this Source.
     * 
     * @param metaEnd
     */
    public void setMetaEnd(java.lang.String metaEnd) {
        this.metaEnd = metaEnd;
    }


    /**
     * Gets the metaStart value for this Source.
     * 
     * @return metaStart
     */
    public java.lang.String getMetaStart() {
        return metaStart;
    }


    /**
     * Sets the metaStart value for this Source.
     * 
     * @param metaStart
     */
    public void setMetaStart(java.lang.String metaStart) {
        this.metaStart = metaStart;
    }


    /**
     * Gets the name value for this Source.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Source.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the nickName value for this Source.
     * 
     * @return nickName
     */
    public java.lang.String getNickName() {
        return nickName;
    }


    /**
     * Sets the nickName value for this Source.
     * 
     * @param nickName
     */
    public void setNickName(java.lang.String nickName) {
        this.nickName = nickName;
    }


    /**
     * Gets the remove value for this Source.
     * 
     * @return remove
     */
    public java.lang.String getRemove() {
        return remove;
    }


    /**
     * Sets the remove value for this Source.
     * 
     * @param remove
     */
    public void setRemove(java.lang.String remove) {
        this.remove = remove;
    }


    /**
     * Gets the sabin value for this Source.
     * 
     * @return sabin
     */
    public boolean isSabin() {
        return sabin;
    }


    /**
     * Sets the sabin value for this Source.
     * 
     * @param sabin
     */
    public void setSabin(boolean sabin) {
        this.sabin = sabin;
    }


    /**
     * Gets the termFrequency value for this Source.
     * 
     * @return termFrequency
     */
    public int getTermFrequency() {
        return termFrequency;
    }


    /**
     * Sets the termFrequency value for this Source.
     * 
     * @param termFrequency
     */
    public void setTermFrequency(int termFrequency) {
        this.termFrequency = termFrequency;
    }


    /**
     * Gets the termTypeList value for this Source.
     * 
     * @return termTypeList
     */
    public java.lang.String[] getTermTypeList() {
        return termTypeList;
    }


    /**
     * Sets the termTypeList value for this Source.
     * 
     * @param termTypeList
     */
    public void setTermTypeList(java.lang.String[] termTypeList) {
        this.termTypeList = termTypeList;
    }


    /**
     * Gets the version value for this Source.
     * 
     * @return version
     */
    public java.lang.String getVersion() {
        return version;
    }


    /**
     * Sets the version value for this Source.
     * 
     * @param version
     */
    public void setVersion(java.lang.String version) {
        this.version = version;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Source)) return false;
        Source other = (Source) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.CUIFrequency == other.getCUIFrequency() &&
            ((this.RCUI==null && other.getRCUI()==null) || 
             (this.RCUI!=null &&
              this.RCUI.equals(other.getRCUI()))) &&
            ((this.RSAB==null && other.getRSAB()==null) || 
             (this.RSAB!=null &&
              this.RSAB.equals(other.getRSAB()))) &&
            ((this.SAB==null && other.getSAB()==null) || 
             (this.SAB!=null &&
              this.SAB.equals(other.getSAB()))) &&
            ((this.SCIT==null && other.getSCIT()==null) || 
             (this.SCIT!=null &&
              this.SCIT.equals(other.getSCIT()))) &&
            ((this.VCUI==null && other.getVCUI()==null) || 
             (this.VCUI!=null &&
              this.VCUI.equals(other.getVCUI()))) &&
            ((this.VSAB==null && other.getVSAB()==null) || 
             (this.VSAB!=null &&
              this.VSAB.equals(other.getVSAB()))) &&
            ((this.attrNameList==null && other.getAttrNameList()==null) || 
             (this.attrNameList!=null &&
              java.util.Arrays.equals(this.attrNameList, other.getAttrNameList()))) &&
            ((this.charEncode==null && other.getCharEncode()==null) || 
             (this.charEncode!=null &&
              this.charEncode.equals(other.getCharEncode()))) &&
            ((this.contentContact==null && other.getContentContact()==null) || 
             (this.contentContact!=null &&
              this.contentContact.equals(other.getContentContact()))) &&
            ((this.context==null && other.getContext()==null) || 
             (this.context!=null &&
              this.context.equals(other.getContext()))) &&
            this.currentVersion == other.isCurrentVersion() &&
            ((this.family==null && other.getFamily()==null) || 
             (this.family!=null &&
              this.family.equals(other.getFamily()))) &&
            ((this.insert==null && other.getInsert()==null) || 
             (this.insert!=null &&
              this.insert.equals(other.getInsert()))) &&
            ((this.language==null && other.getLanguage()==null) || 
             (this.language!=null &&
              this.language.equals(other.getLanguage()))) &&
            ((this.licenseContact==null && other.getLicenseContact()==null) || 
             (this.licenseContact!=null &&
              this.licenseContact.equals(other.getLicenseContact()))) &&
            ((this.metaEnd==null && other.getMetaEnd()==null) || 
             (this.metaEnd!=null &&
              this.metaEnd.equals(other.getMetaEnd()))) &&
            ((this.metaStart==null && other.getMetaStart()==null) || 
             (this.metaStart!=null &&
              this.metaStart.equals(other.getMetaStart()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.nickName==null && other.getNickName()==null) || 
             (this.nickName!=null &&
              this.nickName.equals(other.getNickName()))) &&
            ((this.remove==null && other.getRemove()==null) || 
             (this.remove!=null &&
              this.remove.equals(other.getRemove()))) &&
            this.sabin == other.isSabin() &&
            this.termFrequency == other.getTermFrequency() &&
            ((this.termTypeList==null && other.getTermTypeList()==null) || 
             (this.termTypeList!=null &&
              java.util.Arrays.equals(this.termTypeList, other.getTermTypeList()))) &&
            ((this.version==null && other.getVersion()==null) || 
             (this.version!=null &&
              this.version.equals(other.getVersion())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getCUIFrequency();
        if (getRCUI() != null) {
            _hashCode += getRCUI().hashCode();
        }
        if (getRSAB() != null) {
            _hashCode += getRSAB().hashCode();
        }
        if (getSAB() != null) {
            _hashCode += getSAB().hashCode();
        }
        if (getSCIT() != null) {
            _hashCode += getSCIT().hashCode();
        }
        if (getVCUI() != null) {
            _hashCode += getVCUI().hashCode();
        }
        if (getVSAB() != null) {
            _hashCode += getVSAB().hashCode();
        }
        if (getAttrNameList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttrNameList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttrNameList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCharEncode() != null) {
            _hashCode += getCharEncode().hashCode();
        }
        if (getContentContact() != null) {
            _hashCode += getContentContact().hashCode();
        }
        if (getContext() != null) {
            _hashCode += getContext().hashCode();
        }
        _hashCode += (isCurrentVersion() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getFamily() != null) {
            _hashCode += getFamily().hashCode();
        }
        if (getInsert() != null) {
            _hashCode += getInsert().hashCode();
        }
        if (getLanguage() != null) {
            _hashCode += getLanguage().hashCode();
        }
        if (getLicenseContact() != null) {
            _hashCode += getLicenseContact().hashCode();
        }
        if (getMetaEnd() != null) {
            _hashCode += getMetaEnd().hashCode();
        }
        if (getMetaStart() != null) {
            _hashCode += getMetaStart().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNickName() != null) {
            _hashCode += getNickName().hashCode();
        }
        if (getRemove() != null) {
            _hashCode += getRemove().hashCode();
        }
        _hashCode += (isSabin() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getTermFrequency();
        if (getTermTypeList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTermTypeList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTermTypeList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getVersion() != null) {
            _hashCode += getVersion().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Source.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://source.meta.models.kss.nlm.nih.gov", "Source"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUIFrequency");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CUIFrequency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RCUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RCUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RSAB");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RSAB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAB");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SAB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCIT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SCIT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VCUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "VCUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VSAB");
        elemField.setXmlName(new javax.xml.namespace.QName("", "VSAB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attrNameList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "attrNameList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("charEncode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "charEncode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contentContact");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contentContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("context");
        elemField.setXmlName(new javax.xml.namespace.QName("", "context"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentVersion");
        elemField.setXmlName(new javax.xml.namespace.QName("", "currentVersion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("family");
        elemField.setXmlName(new javax.xml.namespace.QName("", "family"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insert");
        elemField.setXmlName(new javax.xml.namespace.QName("", "insert"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("language");
        elemField.setXmlName(new javax.xml.namespace.QName("", "language"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("licenseContact");
        elemField.setXmlName(new javax.xml.namespace.QName("", "licenseContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metaEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "metaEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metaStart");
        elemField.setXmlName(new javax.xml.namespace.QName("", "metaStart"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nickName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nickName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remove");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remove"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sabin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sabin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("termFrequency");
        elemField.setXmlName(new javax.xml.namespace.QName("", "termFrequency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("termTypeList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "termTypeList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
