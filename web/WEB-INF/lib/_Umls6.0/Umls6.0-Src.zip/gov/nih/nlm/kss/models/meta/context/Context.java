/**
 * Context.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.context;

public class Context  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private gov.nih.nlm.kss.models.meta.context.StringCxt[] CXT;

    private java.lang.String SUI;

    public Context() {
    }

    public Context(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.models.meta.context.StringCxt[] CXT,
           java.lang.String SUI) {
        super(
            key,
            performanceMode);
        this.CXT = CXT;
        this.SUI = SUI;
    }


    /**
     * Gets the CXT value for this Context.
     * 
     * @return CXT
     */
    public gov.nih.nlm.kss.models.meta.context.StringCxt[] getCXT() {
        return CXT;
    }


    /**
     * Sets the CXT value for this Context.
     * 
     * @param CXT
     */
    public void setCXT(gov.nih.nlm.kss.models.meta.context.StringCxt[] CXT) {
        this.CXT = CXT;
    }


    /**
     * Gets the SUI value for this Context.
     * 
     * @return SUI
     */
    public java.lang.String getSUI() {
        return SUI;
    }


    /**
     * Sets the SUI value for this Context.
     * 
     * @param SUI
     */
    public void setSUI(java.lang.String SUI) {
        this.SUI = SUI;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Context)) return false;
        Context other = (Context) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.CXT==null && other.getCXT()==null) || 
             (this.CXT!=null &&
              java.util.Arrays.equals(this.CXT, other.getCXT()))) &&
            ((this.SUI==null && other.getSUI()==null) || 
             (this.SUI!=null &&
              this.SUI.equals(other.getSUI())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCXT() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCXT());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCXT(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSUI() != null) {
            _hashCode += getSUI().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Context.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "Context"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CXT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CXT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "StringCxt"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
