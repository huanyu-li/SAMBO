/**
 * AssociativeRelExistence.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.sem.rels;

public class AssociativeRelExistence  extends gov.nih.nlm.kss.models.KSObject  implements java.io.Serializable {
    private java.lang.String LHSSemType;

    private java.lang.String RHSSemType;

    private int exists;

    private java.lang.String relation;

    public AssociativeRelExistence() {
    }

    public AssociativeRelExistence(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.query.UMLSKSRequest queryInput,
           java.lang.String release,
           java.lang.String LHSSemType,
           java.lang.String RHSSemType,
           int exists,
           java.lang.String relation) {
        super(
            key,
            performanceMode,
            queryInput,
            release);
        this.LHSSemType = LHSSemType;
        this.RHSSemType = RHSSemType;
        this.exists = exists;
        this.relation = relation;
    }


    /**
     * Gets the LHSSemType value for this AssociativeRelExistence.
     * 
     * @return LHSSemType
     */
    public java.lang.String getLHSSemType() {
        return LHSSemType;
    }


    /**
     * Sets the LHSSemType value for this AssociativeRelExistence.
     * 
     * @param LHSSemType
     */
    public void setLHSSemType(java.lang.String LHSSemType) {
        this.LHSSemType = LHSSemType;
    }


    /**
     * Gets the RHSSemType value for this AssociativeRelExistence.
     * 
     * @return RHSSemType
     */
    public java.lang.String getRHSSemType() {
        return RHSSemType;
    }


    /**
     * Sets the RHSSemType value for this AssociativeRelExistence.
     * 
     * @param RHSSemType
     */
    public void setRHSSemType(java.lang.String RHSSemType) {
        this.RHSSemType = RHSSemType;
    }


    /**
     * Gets the exists value for this AssociativeRelExistence.
     * 
     * @return exists
     */
    public int getExists() {
        return exists;
    }


    /**
     * Sets the exists value for this AssociativeRelExistence.
     * 
     * @param exists
     */
    public void setExists(int exists) {
        this.exists = exists;
    }


    /**
     * Gets the relation value for this AssociativeRelExistence.
     * 
     * @return relation
     */
    public java.lang.String getRelation() {
        return relation;
    }


    /**
     * Sets the relation value for this AssociativeRelExistence.
     * 
     * @param relation
     */
    public void setRelation(java.lang.String relation) {
        this.relation = relation;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AssociativeRelExistence)) return false;
        AssociativeRelExistence other = (AssociativeRelExistence) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.LHSSemType==null && other.getLHSSemType()==null) || 
             (this.LHSSemType!=null &&
              this.LHSSemType.equals(other.getLHSSemType()))) &&
            ((this.RHSSemType==null && other.getRHSSemType()==null) || 
             (this.RHSSemType!=null &&
              this.RHSSemType.equals(other.getRHSSemType()))) &&
            this.exists == other.getExists() &&
            ((this.relation==null && other.getRelation()==null) || 
             (this.relation!=null &&
              this.relation.equals(other.getRelation())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLHSSemType() != null) {
            _hashCode += getLHSSemType().hashCode();
        }
        if (getRHSSemType() != null) {
            _hashCode += getRHSSemType().hashCode();
        }
        _hashCode += getExists();
        if (getRelation() != null) {
            _hashCode += getRelation().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AssociativeRelExistence.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "AssociativeRelExistence"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LHSSemType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "LHSSemType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RHSSemType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RHSSemType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exists");
        elemField.setXmlName(new javax.xml.namespace.QName("", "exists"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
