/**
 * AttributeValue.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.attribute;

public class AttributeValue  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private gov.nih.nlm.kss.models.meta.attribute.Attr AT;

    private java.lang.String ATUI;

    private java.lang.String ATV;

    private java.lang.String SATUI;

    public AttributeValue() {
    }

    public AttributeValue(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.models.meta.attribute.Attr AT,
           java.lang.String ATUI,
           java.lang.String ATV,
           java.lang.String SATUI) {
        super(
            key,
            performanceMode);
        this.AT = AT;
        this.ATUI = ATUI;
        this.ATV = ATV;
        this.SATUI = SATUI;
    }


    /**
     * Gets the AT value for this AttributeValue.
     * 
     * @return AT
     */
    public gov.nih.nlm.kss.models.meta.attribute.Attr getAT() {
        return AT;
    }


    /**
     * Sets the AT value for this AttributeValue.
     * 
     * @param AT
     */
    public void setAT(gov.nih.nlm.kss.models.meta.attribute.Attr AT) {
        this.AT = AT;
    }


    /**
     * Gets the ATUI value for this AttributeValue.
     * 
     * @return ATUI
     */
    public java.lang.String getATUI() {
        return ATUI;
    }


    /**
     * Sets the ATUI value for this AttributeValue.
     * 
     * @param ATUI
     */
    public void setATUI(java.lang.String ATUI) {
        this.ATUI = ATUI;
    }


    /**
     * Gets the ATV value for this AttributeValue.
     * 
     * @return ATV
     */
    public java.lang.String getATV() {
        return ATV;
    }


    /**
     * Sets the ATV value for this AttributeValue.
     * 
     * @param ATV
     */
    public void setATV(java.lang.String ATV) {
        this.ATV = ATV;
    }


    /**
     * Gets the SATUI value for this AttributeValue.
     * 
     * @return SATUI
     */
    public java.lang.String getSATUI() {
        return SATUI;
    }


    /**
     * Sets the SATUI value for this AttributeValue.
     * 
     * @param SATUI
     */
    public void setSATUI(java.lang.String SATUI) {
        this.SATUI = SATUI;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AttributeValue)) return false;
        AttributeValue other = (AttributeValue) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.AT==null && other.getAT()==null) || 
             (this.AT!=null &&
              this.AT.equals(other.getAT()))) &&
            ((this.ATUI==null && other.getATUI()==null) || 
             (this.ATUI!=null &&
              this.ATUI.equals(other.getATUI()))) &&
            ((this.ATV==null && other.getATV()==null) || 
             (this.ATV!=null &&
              this.ATV.equals(other.getATV()))) &&
            ((this.SATUI==null && other.getSATUI()==null) || 
             (this.SATUI!=null &&
              this.SATUI.equals(other.getSATUI())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAT() != null) {
            _hashCode += getAT().hashCode();
        }
        if (getATUI() != null) {
            _hashCode += getATUI().hashCode();
        }
        if (getATV() != null) {
            _hashCode += getATV().hashCode();
        }
        if (getSATUI() != null) {
            _hashCode += getSATUI().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AttributeValue.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "AttributeValue"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "Attr"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ATUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ATUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ATV");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ATV"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SATUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SATUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
