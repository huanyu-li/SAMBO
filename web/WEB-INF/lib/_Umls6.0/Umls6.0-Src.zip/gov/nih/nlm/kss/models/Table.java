/**
 * Table.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models;

public class Table  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private gov.nih.nlm.kss.models.ColumnDescription[] columns;

    private java.lang.String knowledgeSource;

    private java.lang.String name;

    private boolean selectAll;

    public Table() {
    }

    public Table(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.models.ColumnDescription[] columns,
           java.lang.String knowledgeSource,
           java.lang.String name,
           boolean selectAll) {
        super(
            key,
            performanceMode);
        this.columns = columns;
        this.knowledgeSource = knowledgeSource;
        this.name = name;
        this.selectAll = selectAll;
    }


    /**
     * Gets the columns value for this Table.
     * 
     * @return columns
     */
    public gov.nih.nlm.kss.models.ColumnDescription[] getColumns() {
        return columns;
    }


    /**
     * Sets the columns value for this Table.
     * 
     * @param columns
     */
    public void setColumns(gov.nih.nlm.kss.models.ColumnDescription[] columns) {
        this.columns = columns;
    }


    /**
     * Gets the knowledgeSource value for this Table.
     * 
     * @return knowledgeSource
     */
    public java.lang.String getKnowledgeSource() {
        return knowledgeSource;
    }


    /**
     * Sets the knowledgeSource value for this Table.
     * 
     * @param knowledgeSource
     */
    public void setKnowledgeSource(java.lang.String knowledgeSource) {
        this.knowledgeSource = knowledgeSource;
    }


    /**
     * Gets the name value for this Table.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Table.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the selectAll value for this Table.
     * 
     * @return selectAll
     */
    public boolean isSelectAll() {
        return selectAll;
    }


    /**
     * Sets the selectAll value for this Table.
     * 
     * @param selectAll
     */
    public void setSelectAll(boolean selectAll) {
        this.selectAll = selectAll;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Table)) return false;
        Table other = (Table) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.columns==null && other.getColumns()==null) || 
             (this.columns!=null &&
              java.util.Arrays.equals(this.columns, other.getColumns()))) &&
            ((this.knowledgeSource==null && other.getKnowledgeSource()==null) || 
             (this.knowledgeSource!=null &&
              this.knowledgeSource.equals(other.getKnowledgeSource()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            this.selectAll == other.isSelectAll();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getColumns() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getColumns());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getColumns(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getKnowledgeSource() != null) {
            _hashCode += getKnowledgeSource().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        _hashCode += (isSelectAll() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Table.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "Table"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columns");
        elemField.setXmlName(new javax.xml.namespace.QName("", "columns"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "ColumnDescription"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("knowledgeSource");
        elemField.setXmlName(new javax.xml.namespace.QName("", "knowledgeSource"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("selectAll");
        elemField.setXmlName(new javax.xml.namespace.QName("", "selectAll"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
