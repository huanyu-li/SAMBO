/**
 * UMLSKSServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss;

public interface UMLSKSServicePortType extends java.rmi.Remote {
    public gov.nih.nlm.kss.models.RowGroup query(gov.nih.nlm.kss.query.XMLQueryRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.mapping.MapSetGroup getMapping(gov.nih.nlm.kss.query.meta.MapRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.KSStringGroup words(gov.nih.nlm.kss.query.WordRequest request) throws java.rmi.RemoteException;
    public java.lang.String identity(gov.nih.nlm.kss.query.UMLSKSRequest request) throws java.rmi.RemoteException;
    public java.lang.String getCurrentUMLSVersion(gov.nih.nlm.kss.query.CurrentUMLSRequest request) throws java.rmi.RemoteException;
    public boolean login(java.lang.String in0, java.lang.String in1) throws java.rmi.RemoteException;
    public java.lang.String[] listUMLSReleases(gov.nih.nlm.kss.query.ListUMLSReleasesRequest request) throws java.rmi.RemoteException;
    public java.lang.String getSoftwareVersion(gov.nih.nlm.kss.query.SWVersionRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.KSStringGroup normalizeString(gov.nih.nlm.kss.query.NormalizeStringRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.KSStringGroup undiacritic(gov.nih.nlm.kss.query.UndiacriticRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByApproximateMatch(gov.nih.nlm.kss.query.ConceptIdApproximateMatchRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.SpellingSuggestionsGroup suggestSpelling(gov.nih.nlm.kss.query.SuggestSpellingRequest request) throws java.rmi.RemoteException;
    public java.lang.String getRawRecords(gov.nih.nlm.kss.query.RawRecordsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.TableGroup describeRawTables(gov.nih.nlm.kss.query.DescribeTablesRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByExact(gov.nih.nlm.kss.query.meta.ConceptIdExactRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByNormString(gov.nih.nlm.kss.query.meta.ConceptIdNormStringRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByNormWord(gov.nih.nlm.kss.query.meta.ConceptIdNormWordRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByWord(gov.nih.nlm.kss.query.meta.ConceptIdWordRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByRightTruncation(gov.nih.nlm.kss.query.meta.ConceptIdRightTruncationRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByLeftTruncation(gov.nih.nlm.kss.query.meta.ConceptIdLeftTruncationRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIBySemType(gov.nih.nlm.kss.query.meta.ConceptIdSemTypeRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIBySabCode(gov.nih.nlm.kss.query.meta.ConceptIdSabCodeRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.ConceptGroup getConceptProperties(gov.nih.nlm.kss.query.meta.ConceptRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.DocEntryGroup listDocEntryTypes(gov.nih.nlm.kss.query.meta.DocEntryRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.StringIdGroup getStringsForSUI(gov.nih.nlm.kss.query.meta.StringIdRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.StringIdGroup findSUI(gov.nih.nlm.kss.query.meta.SUIRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.StringIdGroup getAUIDetails(gov.nih.nlm.kss.query.meta.AUIDetailsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.TermIdGroup getTermsForLUI(gov.nih.nlm.kss.query.meta.TermIdRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.concept.TermIdGroup findLUI(gov.nih.nlm.kss.query.meta.LUIRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.source.SourceGroup describeSources(gov.nih.nlm.kss.query.meta.SourceRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.deltas.ReleaseDeltaGroup describeUMLSChanges(gov.nih.nlm.kss.query.meta.DescribeChangesRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.meshentry.MeSHEntryGroup getMeSHEntries(gov.nih.nlm.kss.query.meta.MeSHEntryRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.meshentry.MeSHInfoGroup getMeSHInfo(gov.nih.nlm.kss.query.meta.MeSHInfoRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup findSemNetId(gov.nih.nlm.kss.query.sem.SearchStringRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup listSemTypeIds(gov.nih.nlm.kss.query.sem.ListSemTypeIdsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup getSemTypeProperties(gov.nih.nlm.kss.query.sem.SemTypePropsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup getSemTypeAncestors(gov.nih.nlm.kss.query.sem.SemTypeAncestorsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup getSemTypeSiblings(gov.nih.nlm.kss.query.sem.SemTypeSiblingsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup listSemRelationIds(gov.nih.nlm.kss.query.sem.ListSemRelationIdsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup getSemRelationProperties(gov.nih.nlm.kss.query.sem.SemRelationPropsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup getSemRelationAncestors(gov.nih.nlm.kss.query.sem.SemRelationAncestorsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.rels.AssociativeRelExistence existsAssociativeRelation(gov.nih.nlm.kss.query.sem.AssociativeRelExistsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.rels.AssociativeRelationGroup getAssociativeRelations(gov.nih.nlm.kss.query.sem.AssociativeRelationsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.rels.HierRelRelExistence existsHierRelRelation(gov.nih.nlm.kss.query.sem.HierRelRelExistsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.units.SemGroupGroup listSemGroups(gov.nih.nlm.kss.query.sem.SemGroupListRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup listSemTypesForGroup(gov.nih.nlm.kss.query.sem.SemTypesForGroupRequest request) throws java.rmi.RemoteException;
    public java.lang.String getLexicalRecords(gov.nih.nlm.kss.query.LexicalRecordRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.DictionaryGroup listDictionaries(gov.nih.nlm.kss.query.DictionaryRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.rank.SourceRankGroup listSourceRankings(gov.nih.nlm.kss.query.meta.ListSourceRankingsRequest request) throws java.rmi.RemoteException;
    public gov.nih.nlm.kss.models.meta.deltas.SourceHistoryGroup getSourceChanges(gov.nih.nlm.kss.query.meta.SourceHistoryRequest request) throws java.rmi.RemoteException;
}
