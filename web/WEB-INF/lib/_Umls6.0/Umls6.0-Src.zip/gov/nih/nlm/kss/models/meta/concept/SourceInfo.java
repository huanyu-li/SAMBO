/**
 * SourceInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.concept;

public class SourceInfo  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String AUI;

    private java.lang.String SAUI;

    private java.lang.String SCUI;

    private java.lang.String SDUI;

    private java.lang.String TTY;

    private gov.nih.nlm.kss.models.meta.attribute.AttributeContext[] attributes;

    private boolean suppressible;

    private java.lang.String suppressibleReason;

    public SourceInfo() {
    }

    public SourceInfo(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String AUI,
           java.lang.String SAUI,
           java.lang.String SCUI,
           java.lang.String SDUI,
           java.lang.String TTY,
           gov.nih.nlm.kss.models.meta.attribute.AttributeContext[] attributes,
           boolean suppressible,
           java.lang.String suppressibleReason) {
        super(
            key,
            performanceMode);
        this.AUI = AUI;
        this.SAUI = SAUI;
        this.SCUI = SCUI;
        this.SDUI = SDUI;
        this.TTY = TTY;
        this.attributes = attributes;
        this.suppressible = suppressible;
        this.suppressibleReason = suppressibleReason;
    }


    /**
     * Gets the AUI value for this SourceInfo.
     * 
     * @return AUI
     */
    public java.lang.String getAUI() {
        return AUI;
    }


    /**
     * Sets the AUI value for this SourceInfo.
     * 
     * @param AUI
     */
    public void setAUI(java.lang.String AUI) {
        this.AUI = AUI;
    }


    /**
     * Gets the SAUI value for this SourceInfo.
     * 
     * @return SAUI
     */
    public java.lang.String getSAUI() {
        return SAUI;
    }


    /**
     * Sets the SAUI value for this SourceInfo.
     * 
     * @param SAUI
     */
    public void setSAUI(java.lang.String SAUI) {
        this.SAUI = SAUI;
    }


    /**
     * Gets the SCUI value for this SourceInfo.
     * 
     * @return SCUI
     */
    public java.lang.String getSCUI() {
        return SCUI;
    }


    /**
     * Sets the SCUI value for this SourceInfo.
     * 
     * @param SCUI
     */
    public void setSCUI(java.lang.String SCUI) {
        this.SCUI = SCUI;
    }


    /**
     * Gets the SDUI value for this SourceInfo.
     * 
     * @return SDUI
     */
    public java.lang.String getSDUI() {
        return SDUI;
    }


    /**
     * Sets the SDUI value for this SourceInfo.
     * 
     * @param SDUI
     */
    public void setSDUI(java.lang.String SDUI) {
        this.SDUI = SDUI;
    }


    /**
     * Gets the TTY value for this SourceInfo.
     * 
     * @return TTY
     */
    public java.lang.String getTTY() {
        return TTY;
    }


    /**
     * Sets the TTY value for this SourceInfo.
     * 
     * @param TTY
     */
    public void setTTY(java.lang.String TTY) {
        this.TTY = TTY;
    }


    /**
     * Gets the attributes value for this SourceInfo.
     * 
     * @return attributes
     */
    public gov.nih.nlm.kss.models.meta.attribute.AttributeContext[] getAttributes() {
        return attributes;
    }


    /**
     * Sets the attributes value for this SourceInfo.
     * 
     * @param attributes
     */
    public void setAttributes(gov.nih.nlm.kss.models.meta.attribute.AttributeContext[] attributes) {
        this.attributes = attributes;
    }


    /**
     * Gets the suppressible value for this SourceInfo.
     * 
     * @return suppressible
     */
    public boolean isSuppressible() {
        return suppressible;
    }


    /**
     * Sets the suppressible value for this SourceInfo.
     * 
     * @param suppressible
     */
    public void setSuppressible(boolean suppressible) {
        this.suppressible = suppressible;
    }


    /**
     * Gets the suppressibleReason value for this SourceInfo.
     * 
     * @return suppressibleReason
     */
    public java.lang.String getSuppressibleReason() {
        return suppressibleReason;
    }


    /**
     * Sets the suppressibleReason value for this SourceInfo.
     * 
     * @param suppressibleReason
     */
    public void setSuppressibleReason(java.lang.String suppressibleReason) {
        this.suppressibleReason = suppressibleReason;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SourceInfo)) return false;
        SourceInfo other = (SourceInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.AUI==null && other.getAUI()==null) || 
             (this.AUI!=null &&
              this.AUI.equals(other.getAUI()))) &&
            ((this.SAUI==null && other.getSAUI()==null) || 
             (this.SAUI!=null &&
              this.SAUI.equals(other.getSAUI()))) &&
            ((this.SCUI==null && other.getSCUI()==null) || 
             (this.SCUI!=null &&
              this.SCUI.equals(other.getSCUI()))) &&
            ((this.SDUI==null && other.getSDUI()==null) || 
             (this.SDUI!=null &&
              this.SDUI.equals(other.getSDUI()))) &&
            ((this.TTY==null && other.getTTY()==null) || 
             (this.TTY!=null &&
              this.TTY.equals(other.getTTY()))) &&
            ((this.attributes==null && other.getAttributes()==null) || 
             (this.attributes!=null &&
              java.util.Arrays.equals(this.attributes, other.getAttributes()))) &&
            this.suppressible == other.isSuppressible() &&
            ((this.suppressibleReason==null && other.getSuppressibleReason()==null) || 
             (this.suppressibleReason!=null &&
              this.suppressibleReason.equals(other.getSuppressibleReason())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAUI() != null) {
            _hashCode += getAUI().hashCode();
        }
        if (getSAUI() != null) {
            _hashCode += getSAUI().hashCode();
        }
        if (getSCUI() != null) {
            _hashCode += getSCUI().hashCode();
        }
        if (getSDUI() != null) {
            _hashCode += getSDUI().hashCode();
        }
        if (getTTY() != null) {
            _hashCode += getTTY().hashCode();
        }
        if (getAttributes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttributes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttributes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += (isSuppressible() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getSuppressibleReason() != null) {
            _hashCode += getSuppressibleReason().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SourceInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "SourceInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SAUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SCUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SDUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SDUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TTY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TTY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attributes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "attributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://attribute.meta.models.kss.nlm.nih.gov", "AttributeContext"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppressible");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suppressible"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppressibleReason");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suppressibleReason"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
