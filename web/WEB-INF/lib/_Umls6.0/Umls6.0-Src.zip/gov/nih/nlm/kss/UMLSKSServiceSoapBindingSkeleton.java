/**
 * UMLSKSServiceSoapBindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss;

public class UMLSKSServiceSoapBindingSkeleton implements gov.nih.nlm.kss.UMLSKSServicePortType, org.apache.axis.wsdl.Skeleton {
    private gov.nih.nlm.kss.UMLSKSServicePortType impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "XMLQueryRequest"), gov.nih.nlm.kss.query.XMLQueryRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("query", _params, new javax.xml.namespace.QName("", "queryReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "RowGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "query"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("query") == null) {
            _myOperations.put("query", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("query")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "MapRequest"), gov.nih.nlm.kss.query.meta.MapRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getMapping", _params, new javax.xml.namespace.QName("", "getMappingReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://mapping.meta.models.kss.nlm.nih.gov", "MapSetGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getMapping"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getMapping") == null) {
            _myOperations.put("getMapping", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getMapping")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "WordRequest"), gov.nih.nlm.kss.query.WordRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("words", _params, new javax.xml.namespace.QName("", "wordsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSStringGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "words"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("words") == null) {
            _myOperations.put("words", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("words")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "UMLSKSRequest"), gov.nih.nlm.kss.query.UMLSKSRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("identity", _params, new javax.xml.namespace.QName("", "identityReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "identity"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("identity") == null) {
            _myOperations.put("identity", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("identity")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "CurrentUMLSRequest"), gov.nih.nlm.kss.query.CurrentUMLSRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getCurrentUMLSVersion", _params, new javax.xml.namespace.QName("", "getCurrentUMLSVersionReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getCurrentUMLSVersion"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getCurrentUMLSVersion") == null) {
            _myOperations.put("getCurrentUMLSVersion", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getCurrentUMLSVersion")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("login", _params, new javax.xml.namespace.QName("", "loginReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "login"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("login") == null) {
            _myOperations.put("login", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("login")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "ListUMLSReleasesRequest"), gov.nih.nlm.kss.query.ListUMLSReleasesRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("listUMLSReleases", _params, new javax.xml.namespace.QName("", "listUMLSReleasesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "ArrayOf_xsd_string"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listUMLSReleases"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("listUMLSReleases") == null) {
            _myOperations.put("listUMLSReleases", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("listUMLSReleases")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "SWVersionRequest"), gov.nih.nlm.kss.query.SWVersionRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getSoftwareVersion", _params, new javax.xml.namespace.QName("", "getSoftwareVersionReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSoftwareVersion"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSoftwareVersion") == null) {
            _myOperations.put("getSoftwareVersion", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSoftwareVersion")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "NormalizeStringRequest"), gov.nih.nlm.kss.query.NormalizeStringRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("normalizeString", _params, new javax.xml.namespace.QName("", "normalizeStringReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSStringGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "normalizeString"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("normalizeString") == null) {
            _myOperations.put("normalizeString", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("normalizeString")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "UndiacriticRequest"), gov.nih.nlm.kss.query.UndiacriticRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("undiacritic", _params, new javax.xml.namespace.QName("", "undiacriticReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "KSStringGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "undiacritic"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("undiacritic") == null) {
            _myOperations.put("undiacritic", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("undiacritic")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "ConceptIdApproximateMatchRequest"), gov.nih.nlm.kss.query.ConceptIdApproximateMatchRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findCUIByApproximateMatch", _params, new javax.xml.namespace.QName("", "findCUIByApproximateMatchReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByApproximateMatch"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findCUIByApproximateMatch") == null) {
            _myOperations.put("findCUIByApproximateMatch", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findCUIByApproximateMatch")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "SuggestSpellingRequest"), gov.nih.nlm.kss.query.SuggestSpellingRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("suggestSpelling", _params, new javax.xml.namespace.QName("", "suggestSpellingReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "SpellingSuggestionsGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "suggestSpelling"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("suggestSpelling") == null) {
            _myOperations.put("suggestSpelling", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("suggestSpelling")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "RawRecordsRequest"), gov.nih.nlm.kss.query.RawRecordsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getRawRecords", _params, new javax.xml.namespace.QName("", "getRawRecordsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getRawRecords"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getRawRecords") == null) {
            _myOperations.put("getRawRecords", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getRawRecords")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "DescribeTablesRequest"), gov.nih.nlm.kss.query.DescribeTablesRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("describeRawTables", _params, new javax.xml.namespace.QName("", "describeRawTablesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "TableGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "describeRawTables"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("describeRawTables") == null) {
            _myOperations.put("describeRawTables", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("describeRawTables")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdExactRequest"), gov.nih.nlm.kss.query.meta.ConceptIdExactRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findCUIByExact", _params, new javax.xml.namespace.QName("", "findCUIByExactReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByExact"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findCUIByExact") == null) {
            _myOperations.put("findCUIByExact", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findCUIByExact")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdNormStringRequest"), gov.nih.nlm.kss.query.meta.ConceptIdNormStringRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findCUIByNormString", _params, new javax.xml.namespace.QName("", "findCUIByNormStringReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByNormString"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findCUIByNormString") == null) {
            _myOperations.put("findCUIByNormString", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findCUIByNormString")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdNormWordRequest"), gov.nih.nlm.kss.query.meta.ConceptIdNormWordRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findCUIByNormWord", _params, new javax.xml.namespace.QName("", "findCUIByNormWordReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByNormWord"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findCUIByNormWord") == null) {
            _myOperations.put("findCUIByNormWord", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findCUIByNormWord")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdWordRequest"), gov.nih.nlm.kss.query.meta.ConceptIdWordRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findCUIByWord", _params, new javax.xml.namespace.QName("", "findCUIByWordReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByWord"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findCUIByWord") == null) {
            _myOperations.put("findCUIByWord", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findCUIByWord")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdRightTruncationRequest"), gov.nih.nlm.kss.query.meta.ConceptIdRightTruncationRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findCUIByRightTruncation", _params, new javax.xml.namespace.QName("", "findCUIByRightTruncationReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByRightTruncation"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findCUIByRightTruncation") == null) {
            _myOperations.put("findCUIByRightTruncation", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findCUIByRightTruncation")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdLeftTruncationRequest"), gov.nih.nlm.kss.query.meta.ConceptIdLeftTruncationRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findCUIByLeftTruncation", _params, new javax.xml.namespace.QName("", "findCUIByLeftTruncationReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIByLeftTruncation"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findCUIByLeftTruncation") == null) {
            _myOperations.put("findCUIByLeftTruncation", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findCUIByLeftTruncation")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdSemTypeRequest"), gov.nih.nlm.kss.query.meta.ConceptIdSemTypeRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findCUIBySemType", _params, new javax.xml.namespace.QName("", "findCUIBySemTypeReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIBySemType"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findCUIBySemType") == null) {
            _myOperations.put("findCUIBySemType", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findCUIBySemType")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptIdSabCodeRequest"), gov.nih.nlm.kss.query.meta.ConceptIdSabCodeRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findCUIBySabCode", _params, new javax.xml.namespace.QName("", "findCUIBySabCodeReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findCUIBySabCode"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findCUIBySabCode") == null) {
            _myOperations.put("findCUIBySabCode", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findCUIBySabCode")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptRequest"), gov.nih.nlm.kss.query.meta.ConceptRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConceptProperties", _params, new javax.xml.namespace.QName("", "getConceptPropertiesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "ConceptGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getConceptProperties"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConceptProperties") == null) {
            _myOperations.put("getConceptProperties", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConceptProperties")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "DocEntryRequest"), gov.nih.nlm.kss.query.meta.DocEntryRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("listDocEntryTypes", _params, new javax.xml.namespace.QName("", "listDocEntryTypesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://meta.models.kss.nlm.nih.gov", "DocEntryGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listDocEntryTypes"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("listDocEntryTypes") == null) {
            _myOperations.put("listDocEntryTypes", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("listDocEntryTypes")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "StringIdRequest"), gov.nih.nlm.kss.query.meta.StringIdRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getStringsForSUI", _params, new javax.xml.namespace.QName("", "getStringsForSUIReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getStringsForSUI"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getStringsForSUI") == null) {
            _myOperations.put("getStringsForSUI", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getStringsForSUI")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "SUIRequest"), gov.nih.nlm.kss.query.meta.SUIRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findSUI", _params, new javax.xml.namespace.QName("", "findSUIReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findSUI"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findSUI") == null) {
            _myOperations.put("findSUI", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findSUI")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "AUIDetailsRequest"), gov.nih.nlm.kss.query.meta.AUIDetailsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getAUIDetails", _params, new javax.xml.namespace.QName("", "getAUIDetailsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getAUIDetails"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getAUIDetails") == null) {
            _myOperations.put("getAUIDetails", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getAUIDetails")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "TermIdRequest"), gov.nih.nlm.kss.query.meta.TermIdRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getTermsForLUI", _params, new javax.xml.namespace.QName("", "getTermsForLUIReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "TermIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getTermsForLUI"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getTermsForLUI") == null) {
            _myOperations.put("getTermsForLUI", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getTermsForLUI")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "LUIRequest"), gov.nih.nlm.kss.query.meta.LUIRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findLUI", _params, new javax.xml.namespace.QName("", "findLUIReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "TermIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findLUI"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findLUI") == null) {
            _myOperations.put("findLUI", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findLUI")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "SourceRequest"), gov.nih.nlm.kss.query.meta.SourceRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("describeSources", _params, new javax.xml.namespace.QName("", "describeSourcesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://source.meta.models.kss.nlm.nih.gov", "SourceGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "describeSources"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("describeSources") == null) {
            _myOperations.put("describeSources", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("describeSources")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "DescribeChangesRequest"), gov.nih.nlm.kss.query.meta.DescribeChangesRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("describeUMLSChanges", _params, new javax.xml.namespace.QName("", "describeUMLSChangesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "ReleaseDeltaGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "describeUMLSChanges"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("describeUMLSChanges") == null) {
            _myOperations.put("describeUMLSChanges", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("describeUMLSChanges")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "MeSHEntryRequest"), gov.nih.nlm.kss.query.meta.MeSHEntryRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getMeSHEntries", _params, new javax.xml.namespace.QName("", "getMeSHEntriesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://meshentry.meta.models.kss.nlm.nih.gov", "MeSHEntryGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getMeSHEntries"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getMeSHEntries") == null) {
            _myOperations.put("getMeSHEntries", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getMeSHEntries")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "MeSHInfoRequest"), gov.nih.nlm.kss.query.meta.MeSHInfoRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getMeSHInfo", _params, new javax.xml.namespace.QName("", "getMeSHInfoReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://meshentry.meta.models.kss.nlm.nih.gov", "MeSHInfoGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getMeSHInfo"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getMeSHInfo") == null) {
            _myOperations.put("getMeSHInfo", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getMeSHInfo")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SearchStringRequest"), gov.nih.nlm.kss.query.sem.SearchStringRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findSemNetId", _params, new javax.xml.namespace.QName("", "findSemNetIdReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemNetIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "findSemNetId"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findSemNetId") == null) {
            _myOperations.put("findSemNetId", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findSemNetId")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "ListSemTypeIdsRequest"), gov.nih.nlm.kss.query.sem.ListSemTypeIdsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("listSemTypeIds", _params, new javax.xml.namespace.QName("", "listSemTypeIdsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemNetIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listSemTypeIds"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("listSemTypeIds") == null) {
            _myOperations.put("listSemTypeIds", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("listSemTypeIds")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypePropsRequest"), gov.nih.nlm.kss.query.sem.SemTypePropsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getSemTypeProperties", _params, new javax.xml.namespace.QName("", "getSemTypePropertiesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticTypeGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSemTypeProperties"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSemTypeProperties") == null) {
            _myOperations.put("getSemTypeProperties", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSemTypeProperties")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypeAncestorsRequest"), gov.nih.nlm.kss.query.sem.SemTypeAncestorsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getSemTypeAncestors", _params, new javax.xml.namespace.QName("", "getSemTypeAncestorsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticTypeGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSemTypeAncestors"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSemTypeAncestors") == null) {
            _myOperations.put("getSemTypeAncestors", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSemTypeAncestors")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypeSiblingsRequest"), gov.nih.nlm.kss.query.sem.SemTypeSiblingsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getSemTypeSiblings", _params, new javax.xml.namespace.QName("", "getSemTypeSiblingsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticTypeGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSemTypeSiblings"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSemTypeSiblings") == null) {
            _myOperations.put("getSemTypeSiblings", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSemTypeSiblings")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "ListSemRelationIdsRequest"), gov.nih.nlm.kss.query.sem.ListSemRelationIdsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("listSemRelationIds", _params, new javax.xml.namespace.QName("", "listSemRelationIdsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemNetIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listSemRelationIds"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("listSemRelationIds") == null) {
            _myOperations.put("listSemRelationIds", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("listSemRelationIds")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemRelationPropsRequest"), gov.nih.nlm.kss.query.sem.SemRelationPropsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getSemRelationProperties", _params, new javax.xml.namespace.QName("", "getSemRelationPropertiesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticRelationGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSemRelationProperties"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSemRelationProperties") == null) {
            _myOperations.put("getSemRelationProperties", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSemRelationProperties")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemRelationAncestorsRequest"), gov.nih.nlm.kss.query.sem.SemRelationAncestorsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getSemRelationAncestors", _params, new javax.xml.namespace.QName("", "getSemRelationAncestorsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticRelationGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSemRelationAncestors"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSemRelationAncestors") == null) {
            _myOperations.put("getSemRelationAncestors", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSemRelationAncestors")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "AssociativeRelExistsRequest"), gov.nih.nlm.kss.query.sem.AssociativeRelExistsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("existsAssociativeRelation", _params, new javax.xml.namespace.QName("", "existsAssociativeRelationReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "AssociativeRelExistence"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "existsAssociativeRelation"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("existsAssociativeRelation") == null) {
            _myOperations.put("existsAssociativeRelation", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("existsAssociativeRelation")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "AssociativeRelationsRequest"), gov.nih.nlm.kss.query.sem.AssociativeRelationsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getAssociativeRelations", _params, new javax.xml.namespace.QName("", "getAssociativeRelationsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "AssociativeRelationGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getAssociativeRelations"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getAssociativeRelations") == null) {
            _myOperations.put("getAssociativeRelations", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getAssociativeRelations")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "HierRelRelExistsRequest"), gov.nih.nlm.kss.query.sem.HierRelRelExistsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("existsHierRelRelation", _params, new javax.xml.namespace.QName("", "existsHierRelRelationReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "HierRelRelExistence"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "existsHierRelRelation"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("existsHierRelRelation") == null) {
            _myOperations.put("existsHierRelRelation", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("existsHierRelRelation")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemGroupListRequest"), gov.nih.nlm.kss.query.sem.SemGroupListRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("listSemGroups", _params, new javax.xml.namespace.QName("", "listSemGroupsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemGroupGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listSemGroups"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("listSemGroups") == null) {
            _myOperations.put("listSemGroups", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("listSemGroups")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://sem.query.kss.nlm.nih.gov", "SemTypesForGroupRequest"), gov.nih.nlm.kss.query.sem.SemTypesForGroupRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("listSemTypesForGroup", _params, new javax.xml.namespace.QName("", "listSemTypesForGroupReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "SemNetIdGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listSemTypesForGroup"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("listSemTypesForGroup") == null) {
            _myOperations.put("listSemTypesForGroup", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("listSemTypesForGroup")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "LexicalRecordRequest"), gov.nih.nlm.kss.query.LexicalRecordRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getLexicalRecords", _params, new javax.xml.namespace.QName("", "getLexicalRecordsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getLexicalRecords"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getLexicalRecords") == null) {
            _myOperations.put("getLexicalRecords", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getLexicalRecords")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://query.kss.nlm.nih.gov", "DictionaryRequest"), gov.nih.nlm.kss.query.DictionaryRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("listDictionaries", _params, new javax.xml.namespace.QName("", "listDictionariesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://models.kss.nlm.nih.gov", "DictionaryGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listDictionaries"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("listDictionaries") == null) {
            _myOperations.put("listDictionaries", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("listDictionaries")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ListSourceRankingsRequest"), gov.nih.nlm.kss.query.meta.ListSourceRankingsRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("listSourceRankings", _params, new javax.xml.namespace.QName("", "listSourceRankingsReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://rank.meta.models.kss.nlm.nih.gov", "SourceRankGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "listSourceRankings"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("listSourceRankings") == null) {
            _myOperations.put("listSourceRankings", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("listSourceRankings")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "SourceHistoryRequest"), gov.nih.nlm.kss.query.meta.SourceHistoryRequest.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getSourceChanges", _params, new javax.xml.namespace.QName("", "getSourceChangesReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "SourceHistoryGroup"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://kss.nlm.nih.gov", "getSourceChanges"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getSourceChanges") == null) {
            _myOperations.put("getSourceChanges", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getSourceChanges")).add(_oper);
    }

    public UMLSKSServiceSoapBindingSkeleton() {
        this.impl = new gov.nih.nlm.kss.UMLSKSServiceSoapBindingImpl();
    }

    public UMLSKSServiceSoapBindingSkeleton(gov.nih.nlm.kss.UMLSKSServicePortType impl) {
        this.impl = impl;
    }
    public gov.nih.nlm.kss.models.RowGroup query(gov.nih.nlm.kss.query.XMLQueryRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.RowGroup ret = impl.query(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.mapping.MapSetGroup getMapping(gov.nih.nlm.kss.query.meta.MapRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.mapping.MapSetGroup ret = impl.getMapping(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.KSStringGroup words(gov.nih.nlm.kss.query.WordRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.KSStringGroup ret = impl.words(request);
        return ret;
    }

    public java.lang.String identity(gov.nih.nlm.kss.query.UMLSKSRequest request) throws java.rmi.RemoteException
    {
        java.lang.String ret = impl.identity(request);
        return ret;
    }

    public java.lang.String getCurrentUMLSVersion(gov.nih.nlm.kss.query.CurrentUMLSRequest request) throws java.rmi.RemoteException
    {
        java.lang.String ret = impl.getCurrentUMLSVersion(request);
        return ret;
    }

    public boolean login(java.lang.String in0, java.lang.String in1) throws java.rmi.RemoteException
    {
        boolean ret = impl.login(in0, in1);
        return ret;
    }

    public java.lang.String[] listUMLSReleases(gov.nih.nlm.kss.query.ListUMLSReleasesRequest request) throws java.rmi.RemoteException
    {
        java.lang.String[] ret = impl.listUMLSReleases(request);
        return ret;
    }

    public java.lang.String getSoftwareVersion(gov.nih.nlm.kss.query.SWVersionRequest request) throws java.rmi.RemoteException
    {
        java.lang.String ret = impl.getSoftwareVersion(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.KSStringGroup normalizeString(gov.nih.nlm.kss.query.NormalizeStringRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.KSStringGroup ret = impl.normalizeString(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.KSStringGroup undiacritic(gov.nih.nlm.kss.query.UndiacriticRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.KSStringGroup ret = impl.undiacritic(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByApproximateMatch(gov.nih.nlm.kss.query.ConceptIdApproximateMatchRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup ret = impl.findCUIByApproximateMatch(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.SpellingSuggestionsGroup suggestSpelling(gov.nih.nlm.kss.query.SuggestSpellingRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.SpellingSuggestionsGroup ret = impl.suggestSpelling(request);
        return ret;
    }

    public java.lang.String getRawRecords(gov.nih.nlm.kss.query.RawRecordsRequest request) throws java.rmi.RemoteException
    {
        java.lang.String ret = impl.getRawRecords(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.TableGroup describeRawTables(gov.nih.nlm.kss.query.DescribeTablesRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.TableGroup ret = impl.describeRawTables(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByExact(gov.nih.nlm.kss.query.meta.ConceptIdExactRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup ret = impl.findCUIByExact(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByNormString(gov.nih.nlm.kss.query.meta.ConceptIdNormStringRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup ret = impl.findCUIByNormString(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByNormWord(gov.nih.nlm.kss.query.meta.ConceptIdNormWordRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup ret = impl.findCUIByNormWord(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByWord(gov.nih.nlm.kss.query.meta.ConceptIdWordRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup ret = impl.findCUIByWord(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByRightTruncation(gov.nih.nlm.kss.query.meta.ConceptIdRightTruncationRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup ret = impl.findCUIByRightTruncation(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIByLeftTruncation(gov.nih.nlm.kss.query.meta.ConceptIdLeftTruncationRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup ret = impl.findCUIByLeftTruncation(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIBySemType(gov.nih.nlm.kss.query.meta.ConceptIdSemTypeRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup ret = impl.findCUIBySemType(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup findCUIBySabCode(gov.nih.nlm.kss.query.meta.ConceptIdSabCodeRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.ConceptIdGroup ret = impl.findCUIBySabCode(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.ConceptGroup getConceptProperties(gov.nih.nlm.kss.query.meta.ConceptRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.ConceptGroup ret = impl.getConceptProperties(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.DocEntryGroup listDocEntryTypes(gov.nih.nlm.kss.query.meta.DocEntryRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.DocEntryGroup ret = impl.listDocEntryTypes(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.StringIdGroup getStringsForSUI(gov.nih.nlm.kss.query.meta.StringIdRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.StringIdGroup ret = impl.getStringsForSUI(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.StringIdGroup findSUI(gov.nih.nlm.kss.query.meta.SUIRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.StringIdGroup ret = impl.findSUI(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.StringIdGroup getAUIDetails(gov.nih.nlm.kss.query.meta.AUIDetailsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.StringIdGroup ret = impl.getAUIDetails(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.TermIdGroup getTermsForLUI(gov.nih.nlm.kss.query.meta.TermIdRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.TermIdGroup ret = impl.getTermsForLUI(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.concept.TermIdGroup findLUI(gov.nih.nlm.kss.query.meta.LUIRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.concept.TermIdGroup ret = impl.findLUI(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.source.SourceGroup describeSources(gov.nih.nlm.kss.query.meta.SourceRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.source.SourceGroup ret = impl.describeSources(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.deltas.ReleaseDeltaGroup describeUMLSChanges(gov.nih.nlm.kss.query.meta.DescribeChangesRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.deltas.ReleaseDeltaGroup ret = impl.describeUMLSChanges(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.meshentry.MeSHEntryGroup getMeSHEntries(gov.nih.nlm.kss.query.meta.MeSHEntryRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.meshentry.MeSHEntryGroup ret = impl.getMeSHEntries(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.meshentry.MeSHInfoGroup getMeSHInfo(gov.nih.nlm.kss.query.meta.MeSHInfoRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.meshentry.MeSHInfoGroup ret = impl.getMeSHInfo(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup findSemNetId(gov.nih.nlm.kss.query.sem.SearchStringRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.units.SemNetIdGroup ret = impl.findSemNetId(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup listSemTypeIds(gov.nih.nlm.kss.query.sem.ListSemTypeIdsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.units.SemNetIdGroup ret = impl.listSemTypeIds(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup getSemTypeProperties(gov.nih.nlm.kss.query.sem.SemTypePropsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup ret = impl.getSemTypeProperties(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup getSemTypeAncestors(gov.nih.nlm.kss.query.sem.SemTypeAncestorsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup ret = impl.getSemTypeAncestors(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup getSemTypeSiblings(gov.nih.nlm.kss.query.sem.SemTypeSiblingsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.units.HierSemanticTypeGroup ret = impl.getSemTypeSiblings(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup listSemRelationIds(gov.nih.nlm.kss.query.sem.ListSemRelationIdsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.units.SemNetIdGroup ret = impl.listSemRelationIds(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup getSemRelationProperties(gov.nih.nlm.kss.query.sem.SemRelationPropsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup ret = impl.getSemRelationProperties(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup getSemRelationAncestors(gov.nih.nlm.kss.query.sem.SemRelationAncestorsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.units.HierSemanticRelationGroup ret = impl.getSemRelationAncestors(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.rels.AssociativeRelExistence existsAssociativeRelation(gov.nih.nlm.kss.query.sem.AssociativeRelExistsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.rels.AssociativeRelExistence ret = impl.existsAssociativeRelation(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.rels.AssociativeRelationGroup getAssociativeRelations(gov.nih.nlm.kss.query.sem.AssociativeRelationsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.rels.AssociativeRelationGroup ret = impl.getAssociativeRelations(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.rels.HierRelRelExistence existsHierRelRelation(gov.nih.nlm.kss.query.sem.HierRelRelExistsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.rels.HierRelRelExistence ret = impl.existsHierRelRelation(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.units.SemGroupGroup listSemGroups(gov.nih.nlm.kss.query.sem.SemGroupListRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.units.SemGroupGroup ret = impl.listSemGroups(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.sem.units.SemNetIdGroup listSemTypesForGroup(gov.nih.nlm.kss.query.sem.SemTypesForGroupRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.sem.units.SemNetIdGroup ret = impl.listSemTypesForGroup(request);
        return ret;
    }

    public java.lang.String getLexicalRecords(gov.nih.nlm.kss.query.LexicalRecordRequest request) throws java.rmi.RemoteException
    {
        java.lang.String ret = impl.getLexicalRecords(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.DictionaryGroup listDictionaries(gov.nih.nlm.kss.query.DictionaryRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.DictionaryGroup ret = impl.listDictionaries(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.rank.SourceRankGroup listSourceRankings(gov.nih.nlm.kss.query.meta.ListSourceRankingsRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.rank.SourceRankGroup ret = impl.listSourceRankings(request);
        return ret;
    }

    public gov.nih.nlm.kss.models.meta.deltas.SourceHistoryGroup getSourceChanges(gov.nih.nlm.kss.query.meta.SourceHistoryRequest request) throws java.rmi.RemoteException
    {
        gov.nih.nlm.kss.models.meta.deltas.SourceHistoryGroup ret = impl.getSourceChanges(request);
        return ret;
    }

}
