/**
 * AuthorizationPortSoapBindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.umlsks.authorization;

public class AuthorizationPortSoapBindingSkeleton implements gov.nih.nlm.umlsks.authorization.AuthorizationPortType, org.apache.axis.wsdl.Skeleton {
    private gov.nih.nlm.umlsks.authorization.AuthorizationPortType impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getProxyGrantTicket", _params, new javax.xml.namespace.QName("", "getProxyGrantTicketReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        _oper.setElementQName(new javax.xml.namespace.QName("urn:authorization.umlsks.nlm.nih.gov", "getProxyGrantTicket"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getProxyGrantTicket") == null) {
            _myOperations.put("getProxyGrantTicket", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getProxyGrantTicket")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getProxyTicket", _params, new javax.xml.namespace.QName("", "getProxyTicketReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        _oper.setElementQName(new javax.xml.namespace.QName("urn:authorization.umlsks.nlm.nih.gov", "getProxyTicket"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getProxyTicket") == null) {
            _myOperations.put("getProxyTicket", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getProxyTicket")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("validateProxyTicket", _params, new javax.xml.namespace.QName("", "validateProxyTicketReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        _oper.setElementQName(new javax.xml.namespace.QName("urn:authorization.umlsks.nlm.nih.gov", "validateProxyTicket"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("validateProxyTicket") == null) {
            _myOperations.put("validateProxyTicket", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("validateProxyTicket")).add(_oper);
    }

    public AuthorizationPortSoapBindingSkeleton() {
        this.impl = new gov.nih.nlm.umlsks.authorization.AuthorizationPortSoapBindingImpl();
    }

    public AuthorizationPortSoapBindingSkeleton(gov.nih.nlm.umlsks.authorization.AuthorizationPortType impl) {
        this.impl = impl;
    }
    public java.lang.String getProxyGrantTicket(java.lang.String in0, java.lang.String in1) throws java.rmi.RemoteException
    {
        java.lang.String ret = impl.getProxyGrantTicket(in0, in1);
        return ret;
    }

    public java.lang.String getProxyTicket(java.lang.String in0, java.lang.String in1) throws java.rmi.RemoteException
    {
        java.lang.String ret = impl.getProxyTicket(in0, in1);
        return ret;
    }

    public java.lang.String validateProxyTicket(java.lang.String in0, java.lang.String in1) throws java.rmi.RemoteException
    {
        java.lang.String ret = impl.validateProxyTicket(in0, in1);
        return ret;
    }

}
