/**
 * ConceptRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.query.meta;

public class ConceptRequest  extends gov.nih.nlm.kss.query.meta.CUIInputRequest  implements java.io.Serializable {
    private java.lang.String[] SABs;

    private java.lang.String[] contextTypes;

    private java.lang.String[] cooccurrenceTypes;

    private boolean includeConceptAttrs;

    private boolean includeContexts;

    private boolean includeCooccurrences;

    private boolean includeDefinitions;

    private boolean includeRelations;

    private boolean includeRelationshipAttrs;

    private boolean includeSemanticGroups;

    private boolean includeSemanticTypes;

    private boolean includeSuppressibles;

    private boolean includeTerminology;

    private java.lang.String language;

    private java.lang.String[] relationTypes;

    public ConceptRequest() {
    }

    public ConceptRequest(
           java.lang.String casTicket,
           java.lang.String release,
           long CVF,
           java.lang.String CUI,
           java.lang.String[] SABs,
           java.lang.String[] contextTypes,
           java.lang.String[] cooccurrenceTypes,
           boolean includeConceptAttrs,
           boolean includeContexts,
           boolean includeCooccurrences,
           boolean includeDefinitions,
           boolean includeRelations,
           boolean includeRelationshipAttrs,
           boolean includeSemanticGroups,
           boolean includeSemanticTypes,
           boolean includeSuppressibles,
           boolean includeTerminology,
           java.lang.String language,
           java.lang.String[] relationTypes) {
        super(
            casTicket,
            release,
            CVF,
            CUI);
        this.SABs = SABs;
        this.contextTypes = contextTypes;
        this.cooccurrenceTypes = cooccurrenceTypes;
        this.includeConceptAttrs = includeConceptAttrs;
        this.includeContexts = includeContexts;
        this.includeCooccurrences = includeCooccurrences;
        this.includeDefinitions = includeDefinitions;
        this.includeRelations = includeRelations;
        this.includeRelationshipAttrs = includeRelationshipAttrs;
        this.includeSemanticGroups = includeSemanticGroups;
        this.includeSemanticTypes = includeSemanticTypes;
        this.includeSuppressibles = includeSuppressibles;
        this.includeTerminology = includeTerminology;
        this.language = language;
        this.relationTypes = relationTypes;
    }


    /**
     * Gets the SABs value for this ConceptRequest.
     * 
     * @return SABs
     */
    public java.lang.String[] getSABs() {
        return SABs;
    }


    /**
     * Sets the SABs value for this ConceptRequest.
     * 
     * @param SABs
     */
    public void setSABs(java.lang.String[] SABs) {
        this.SABs = SABs;
    }


    /**
     * Gets the contextTypes value for this ConceptRequest.
     * 
     * @return contextTypes
     */
    public java.lang.String[] getContextTypes() {
        return contextTypes;
    }


    /**
     * Sets the contextTypes value for this ConceptRequest.
     * 
     * @param contextTypes
     */
    public void setContextTypes(java.lang.String[] contextTypes) {
        this.contextTypes = contextTypes;
    }


    /**
     * Gets the cooccurrenceTypes value for this ConceptRequest.
     * 
     * @return cooccurrenceTypes
     */
    public java.lang.String[] getCooccurrenceTypes() {
        return cooccurrenceTypes;
    }


    /**
     * Sets the cooccurrenceTypes value for this ConceptRequest.
     * 
     * @param cooccurrenceTypes
     */
    public void setCooccurrenceTypes(java.lang.String[] cooccurrenceTypes) {
        this.cooccurrenceTypes = cooccurrenceTypes;
    }


    /**
     * Gets the includeConceptAttrs value for this ConceptRequest.
     * 
     * @return includeConceptAttrs
     */
    public boolean isIncludeConceptAttrs() {
        return includeConceptAttrs;
    }


    /**
     * Sets the includeConceptAttrs value for this ConceptRequest.
     * 
     * @param includeConceptAttrs
     */
    public void setIncludeConceptAttrs(boolean includeConceptAttrs) {
        this.includeConceptAttrs = includeConceptAttrs;
    }


    /**
     * Gets the includeContexts value for this ConceptRequest.
     * 
     * @return includeContexts
     */
    public boolean isIncludeContexts() {
        return includeContexts;
    }


    /**
     * Sets the includeContexts value for this ConceptRequest.
     * 
     * @param includeContexts
     */
    public void setIncludeContexts(boolean includeContexts) {
        this.includeContexts = includeContexts;
    }


    /**
     * Gets the includeCooccurrences value for this ConceptRequest.
     * 
     * @return includeCooccurrences
     */
    public boolean isIncludeCooccurrences() {
        return includeCooccurrences;
    }


    /**
     * Sets the includeCooccurrences value for this ConceptRequest.
     * 
     * @param includeCooccurrences
     */
    public void setIncludeCooccurrences(boolean includeCooccurrences) {
        this.includeCooccurrences = includeCooccurrences;
    }


    /**
     * Gets the includeDefinitions value for this ConceptRequest.
     * 
     * @return includeDefinitions
     */
    public boolean isIncludeDefinitions() {
        return includeDefinitions;
    }


    /**
     * Sets the includeDefinitions value for this ConceptRequest.
     * 
     * @param includeDefinitions
     */
    public void setIncludeDefinitions(boolean includeDefinitions) {
        this.includeDefinitions = includeDefinitions;
    }


    /**
     * Gets the includeRelations value for this ConceptRequest.
     * 
     * @return includeRelations
     */
    public boolean isIncludeRelations() {
        return includeRelations;
    }


    /**
     * Sets the includeRelations value for this ConceptRequest.
     * 
     * @param includeRelations
     */
    public void setIncludeRelations(boolean includeRelations) {
        this.includeRelations = includeRelations;
    }


    /**
     * Gets the includeRelationshipAttrs value for this ConceptRequest.
     * 
     * @return includeRelationshipAttrs
     */
    public boolean isIncludeRelationshipAttrs() {
        return includeRelationshipAttrs;
    }


    /**
     * Sets the includeRelationshipAttrs value for this ConceptRequest.
     * 
     * @param includeRelationshipAttrs
     */
    public void setIncludeRelationshipAttrs(boolean includeRelationshipAttrs) {
        this.includeRelationshipAttrs = includeRelationshipAttrs;
    }


    /**
     * Gets the includeSemanticGroups value for this ConceptRequest.
     * 
     * @return includeSemanticGroups
     */
    public boolean isIncludeSemanticGroups() {
        return includeSemanticGroups;
    }


    /**
     * Sets the includeSemanticGroups value for this ConceptRequest.
     * 
     * @param includeSemanticGroups
     */
    public void setIncludeSemanticGroups(boolean includeSemanticGroups) {
        this.includeSemanticGroups = includeSemanticGroups;
    }


    /**
     * Gets the includeSemanticTypes value for this ConceptRequest.
     * 
     * @return includeSemanticTypes
     */
    public boolean isIncludeSemanticTypes() {
        return includeSemanticTypes;
    }


    /**
     * Sets the includeSemanticTypes value for this ConceptRequest.
     * 
     * @param includeSemanticTypes
     */
    public void setIncludeSemanticTypes(boolean includeSemanticTypes) {
        this.includeSemanticTypes = includeSemanticTypes;
    }


    /**
     * Gets the includeSuppressibles value for this ConceptRequest.
     * 
     * @return includeSuppressibles
     */
    public boolean isIncludeSuppressibles() {
        return includeSuppressibles;
    }


    /**
     * Sets the includeSuppressibles value for this ConceptRequest.
     * 
     * @param includeSuppressibles
     */
    public void setIncludeSuppressibles(boolean includeSuppressibles) {
        this.includeSuppressibles = includeSuppressibles;
    }


    /**
     * Gets the includeTerminology value for this ConceptRequest.
     * 
     * @return includeTerminology
     */
    public boolean isIncludeTerminology() {
        return includeTerminology;
    }


    /**
     * Sets the includeTerminology value for this ConceptRequest.
     * 
     * @param includeTerminology
     */
    public void setIncludeTerminology(boolean includeTerminology) {
        this.includeTerminology = includeTerminology;
    }


    /**
     * Gets the language value for this ConceptRequest.
     * 
     * @return language
     */
    public java.lang.String getLanguage() {
        return language;
    }


    /**
     * Sets the language value for this ConceptRequest.
     * 
     * @param language
     */
    public void setLanguage(java.lang.String language) {
        this.language = language;
    }


    /**
     * Gets the relationTypes value for this ConceptRequest.
     * 
     * @return relationTypes
     */
    public java.lang.String[] getRelationTypes() {
        return relationTypes;
    }


    /**
     * Sets the relationTypes value for this ConceptRequest.
     * 
     * @param relationTypes
     */
    public void setRelationTypes(java.lang.String[] relationTypes) {
        this.relationTypes = relationTypes;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConceptRequest)) return false;
        ConceptRequest other = (ConceptRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.SABs==null && other.getSABs()==null) || 
             (this.SABs!=null &&
              java.util.Arrays.equals(this.SABs, other.getSABs()))) &&
            ((this.contextTypes==null && other.getContextTypes()==null) || 
             (this.contextTypes!=null &&
              java.util.Arrays.equals(this.contextTypes, other.getContextTypes()))) &&
            ((this.cooccurrenceTypes==null && other.getCooccurrenceTypes()==null) || 
             (this.cooccurrenceTypes!=null &&
              java.util.Arrays.equals(this.cooccurrenceTypes, other.getCooccurrenceTypes()))) &&
            this.includeConceptAttrs == other.isIncludeConceptAttrs() &&
            this.includeContexts == other.isIncludeContexts() &&
            this.includeCooccurrences == other.isIncludeCooccurrences() &&
            this.includeDefinitions == other.isIncludeDefinitions() &&
            this.includeRelations == other.isIncludeRelations() &&
            this.includeRelationshipAttrs == other.isIncludeRelationshipAttrs() &&
            this.includeSemanticGroups == other.isIncludeSemanticGroups() &&
            this.includeSemanticTypes == other.isIncludeSemanticTypes() &&
            this.includeSuppressibles == other.isIncludeSuppressibles() &&
            this.includeTerminology == other.isIncludeTerminology() &&
            ((this.language==null && other.getLanguage()==null) || 
             (this.language!=null &&
              this.language.equals(other.getLanguage()))) &&
            ((this.relationTypes==null && other.getRelationTypes()==null) || 
             (this.relationTypes!=null &&
              java.util.Arrays.equals(this.relationTypes, other.getRelationTypes())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getSABs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSABs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSABs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getContextTypes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getContextTypes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getContextTypes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCooccurrenceTypes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCooccurrenceTypes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCooccurrenceTypes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += (isIncludeConceptAttrs() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIncludeContexts() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIncludeCooccurrences() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIncludeDefinitions() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIncludeRelations() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIncludeRelationshipAttrs() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIncludeSemanticGroups() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIncludeSemanticTypes() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIncludeSuppressibles() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIncludeTerminology() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getLanguage() != null) {
            _hashCode += getLanguage().hashCode();
        }
        if (getRelationTypes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRelationTypes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRelationTypes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConceptRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://meta.query.kss.nlm.nih.gov", "ConceptRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SABs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SABs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contextTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contextTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cooccurrenceTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cooccurrenceTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeConceptAttrs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeConceptAttrs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeContexts");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeContexts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeCooccurrences");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeCooccurrences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeDefinitions");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeDefinitions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeRelations");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeRelations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeRelationshipAttrs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeRelationshipAttrs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeSemanticGroups");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeSemanticGroups"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeSemanticTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeSemanticTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeSuppressibles");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeSuppressibles"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeTerminology");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeTerminology"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("language");
        elemField.setXmlName(new javax.xml.namespace.QName("", "language"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relationTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relationTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
