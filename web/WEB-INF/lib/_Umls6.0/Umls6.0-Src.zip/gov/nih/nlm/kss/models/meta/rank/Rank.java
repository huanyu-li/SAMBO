/**
 * Rank.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.rank;

public class Rank  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String TTY;

    private int overallRank;

    private boolean suppressible;

    public Rank() {
    }

    public Rank(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String TTY,
           int overallRank,
           boolean suppressible) {
        super(
            key,
            performanceMode);
        this.TTY = TTY;
        this.overallRank = overallRank;
        this.suppressible = suppressible;
    }


    /**
     * Gets the TTY value for this Rank.
     * 
     * @return TTY
     */
    public java.lang.String getTTY() {
        return TTY;
    }


    /**
     * Sets the TTY value for this Rank.
     * 
     * @param TTY
     */
    public void setTTY(java.lang.String TTY) {
        this.TTY = TTY;
    }


    /**
     * Gets the overallRank value for this Rank.
     * 
     * @return overallRank
     */
    public int getOverallRank() {
        return overallRank;
    }


    /**
     * Sets the overallRank value for this Rank.
     * 
     * @param overallRank
     */
    public void setOverallRank(int overallRank) {
        this.overallRank = overallRank;
    }


    /**
     * Gets the suppressible value for this Rank.
     * 
     * @return suppressible
     */
    public boolean isSuppressible() {
        return suppressible;
    }


    /**
     * Sets the suppressible value for this Rank.
     * 
     * @param suppressible
     */
    public void setSuppressible(boolean suppressible) {
        this.suppressible = suppressible;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Rank)) return false;
        Rank other = (Rank) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.TTY==null && other.getTTY()==null) || 
             (this.TTY!=null &&
              this.TTY.equals(other.getTTY()))) &&
            this.overallRank == other.getOverallRank() &&
            this.suppressible == other.isSuppressible();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getTTY() != null) {
            _hashCode += getTTY().hashCode();
        }
        _hashCode += getOverallRank();
        _hashCode += (isSuppressible() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Rank.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://rank.meta.models.kss.nlm.nih.gov", "Rank"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TTY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TTY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overallRank");
        elemField.setXmlName(new javax.xml.namespace.QName("", "overallRank"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppressible");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suppressible"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
