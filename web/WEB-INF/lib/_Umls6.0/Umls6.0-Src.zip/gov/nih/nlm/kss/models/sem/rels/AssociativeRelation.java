/**
 * AssociativeRelation.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.sem.rels;

public class AssociativeRelation  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private gov.nih.nlm.kss.models.sem.units.HierSemanticType LHS;

    private gov.nih.nlm.kss.models.sem.units.HierSemanticType RHS;

    private int linkStatus;

    private gov.nih.nlm.kss.models.sem.units.HierSemanticRelation relation;

    public AssociativeRelation() {
    }

    public AssociativeRelation(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.models.sem.units.HierSemanticType LHS,
           gov.nih.nlm.kss.models.sem.units.HierSemanticType RHS,
           int linkStatus,
           gov.nih.nlm.kss.models.sem.units.HierSemanticRelation relation) {
        super(
            key,
            performanceMode);
        this.LHS = LHS;
        this.RHS = RHS;
        this.linkStatus = linkStatus;
        this.relation = relation;
    }


    /**
     * Gets the LHS value for this AssociativeRelation.
     * 
     * @return LHS
     */
    public gov.nih.nlm.kss.models.sem.units.HierSemanticType getLHS() {
        return LHS;
    }


    /**
     * Sets the LHS value for this AssociativeRelation.
     * 
     * @param LHS
     */
    public void setLHS(gov.nih.nlm.kss.models.sem.units.HierSemanticType LHS) {
        this.LHS = LHS;
    }


    /**
     * Gets the RHS value for this AssociativeRelation.
     * 
     * @return RHS
     */
    public gov.nih.nlm.kss.models.sem.units.HierSemanticType getRHS() {
        return RHS;
    }


    /**
     * Sets the RHS value for this AssociativeRelation.
     * 
     * @param RHS
     */
    public void setRHS(gov.nih.nlm.kss.models.sem.units.HierSemanticType RHS) {
        this.RHS = RHS;
    }


    /**
     * Gets the linkStatus value for this AssociativeRelation.
     * 
     * @return linkStatus
     */
    public int getLinkStatus() {
        return linkStatus;
    }


    /**
     * Sets the linkStatus value for this AssociativeRelation.
     * 
     * @param linkStatus
     */
    public void setLinkStatus(int linkStatus) {
        this.linkStatus = linkStatus;
    }


    /**
     * Gets the relation value for this AssociativeRelation.
     * 
     * @return relation
     */
    public gov.nih.nlm.kss.models.sem.units.HierSemanticRelation getRelation() {
        return relation;
    }


    /**
     * Sets the relation value for this AssociativeRelation.
     * 
     * @param relation
     */
    public void setRelation(gov.nih.nlm.kss.models.sem.units.HierSemanticRelation relation) {
        this.relation = relation;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AssociativeRelation)) return false;
        AssociativeRelation other = (AssociativeRelation) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.LHS==null && other.getLHS()==null) || 
             (this.LHS!=null &&
              this.LHS.equals(other.getLHS()))) &&
            ((this.RHS==null && other.getRHS()==null) || 
             (this.RHS!=null &&
              this.RHS.equals(other.getRHS()))) &&
            this.linkStatus == other.getLinkStatus() &&
            ((this.relation==null && other.getRelation()==null) || 
             (this.relation!=null &&
              this.relation.equals(other.getRelation())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLHS() != null) {
            _hashCode += getLHS().hashCode();
        }
        if (getRHS() != null) {
            _hashCode += getRHS().hashCode();
        }
        _hashCode += getLinkStatus();
        if (getRelation() != null) {
            _hashCode += getRelation().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AssociativeRelation.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "AssociativeRelation"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LHS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "LHS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RHS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RHS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("linkStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "linkStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://units.sem.models.kss.nlm.nih.gov", "HierSemanticRelation"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
