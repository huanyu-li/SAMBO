/**
 * CxtMember.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.context;

public class CxtMember  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String AUI2;

    private java.lang.String CUI2;

    private java.lang.String CXS;

    private java.lang.String HCD;

    private java.lang.String REL;

    private java.lang.String XC;

    private java.lang.String rank;

    public CxtMember() {
    }

    public CxtMember(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String AUI2,
           java.lang.String CUI2,
           java.lang.String CXS,
           java.lang.String HCD,
           java.lang.String REL,
           java.lang.String XC,
           java.lang.String rank) {
        super(
            key,
            performanceMode);
        this.AUI2 = AUI2;
        this.CUI2 = CUI2;
        this.CXS = CXS;
        this.HCD = HCD;
        this.REL = REL;
        this.XC = XC;
        this.rank = rank;
    }


    /**
     * Gets the AUI2 value for this CxtMember.
     * 
     * @return AUI2
     */
    public java.lang.String getAUI2() {
        return AUI2;
    }


    /**
     * Sets the AUI2 value for this CxtMember.
     * 
     * @param AUI2
     */
    public void setAUI2(java.lang.String AUI2) {
        this.AUI2 = AUI2;
    }


    /**
     * Gets the CUI2 value for this CxtMember.
     * 
     * @return CUI2
     */
    public java.lang.String getCUI2() {
        return CUI2;
    }


    /**
     * Sets the CUI2 value for this CxtMember.
     * 
     * @param CUI2
     */
    public void setCUI2(java.lang.String CUI2) {
        this.CUI2 = CUI2;
    }


    /**
     * Gets the CXS value for this CxtMember.
     * 
     * @return CXS
     */
    public java.lang.String getCXS() {
        return CXS;
    }


    /**
     * Sets the CXS value for this CxtMember.
     * 
     * @param CXS
     */
    public void setCXS(java.lang.String CXS) {
        this.CXS = CXS;
    }


    /**
     * Gets the HCD value for this CxtMember.
     * 
     * @return HCD
     */
    public java.lang.String getHCD() {
        return HCD;
    }


    /**
     * Sets the HCD value for this CxtMember.
     * 
     * @param HCD
     */
    public void setHCD(java.lang.String HCD) {
        this.HCD = HCD;
    }


    /**
     * Gets the REL value for this CxtMember.
     * 
     * @return REL
     */
    public java.lang.String getREL() {
        return REL;
    }


    /**
     * Sets the REL value for this CxtMember.
     * 
     * @param REL
     */
    public void setREL(java.lang.String REL) {
        this.REL = REL;
    }


    /**
     * Gets the XC value for this CxtMember.
     * 
     * @return XC
     */
    public java.lang.String getXC() {
        return XC;
    }


    /**
     * Sets the XC value for this CxtMember.
     * 
     * @param XC
     */
    public void setXC(java.lang.String XC) {
        this.XC = XC;
    }


    /**
     * Gets the rank value for this CxtMember.
     * 
     * @return rank
     */
    public java.lang.String getRank() {
        return rank;
    }


    /**
     * Sets the rank value for this CxtMember.
     * 
     * @param rank
     */
    public void setRank(java.lang.String rank) {
        this.rank = rank;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CxtMember)) return false;
        CxtMember other = (CxtMember) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.AUI2==null && other.getAUI2()==null) || 
             (this.AUI2!=null &&
              this.AUI2.equals(other.getAUI2()))) &&
            ((this.CUI2==null && other.getCUI2()==null) || 
             (this.CUI2!=null &&
              this.CUI2.equals(other.getCUI2()))) &&
            ((this.CXS==null && other.getCXS()==null) || 
             (this.CXS!=null &&
              this.CXS.equals(other.getCXS()))) &&
            ((this.HCD==null && other.getHCD()==null) || 
             (this.HCD!=null &&
              this.HCD.equals(other.getHCD()))) &&
            ((this.REL==null && other.getREL()==null) || 
             (this.REL!=null &&
              this.REL.equals(other.getREL()))) &&
            ((this.XC==null && other.getXC()==null) || 
             (this.XC!=null &&
              this.XC.equals(other.getXC()))) &&
            ((this.rank==null && other.getRank()==null) || 
             (this.rank!=null &&
              this.rank.equals(other.getRank())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAUI2() != null) {
            _hashCode += getAUI2().hashCode();
        }
        if (getCUI2() != null) {
            _hashCode += getCUI2().hashCode();
        }
        if (getCXS() != null) {
            _hashCode += getCXS().hashCode();
        }
        if (getHCD() != null) {
            _hashCode += getHCD().hashCode();
        }
        if (getREL() != null) {
            _hashCode += getREL().hashCode();
        }
        if (getXC() != null) {
            _hashCode += getXC().hashCode();
        }
        if (getRank() != null) {
            _hashCode += getRank().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CxtMember.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://context.meta.models.kss.nlm.nih.gov", "CxtMember"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AUI2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AUI2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUI2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CUI2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CXS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CXS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HCD");
        elemField.setXmlName(new javax.xml.namespace.QName("", "HCD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "REL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("XC");
        elemField.setXmlName(new javax.xml.namespace.QName("", "XC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rank");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rank"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
