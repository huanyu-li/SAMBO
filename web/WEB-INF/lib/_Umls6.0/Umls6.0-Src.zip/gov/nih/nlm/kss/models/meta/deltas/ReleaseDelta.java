/**
 * ReleaseDelta.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.deltas;

public class ReleaseDelta  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private gov.nih.nlm.kss.models.meta.deltas.ConceptDelta[] deltas;

    private java.lang.String release;

    public ReleaseDelta() {
    }

    public ReleaseDelta(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.models.meta.deltas.ConceptDelta[] deltas,
           java.lang.String release) {
        super(
            key,
            performanceMode);
        this.deltas = deltas;
        this.release = release;
    }


    /**
     * Gets the deltas value for this ReleaseDelta.
     * 
     * @return deltas
     */
    public gov.nih.nlm.kss.models.meta.deltas.ConceptDelta[] getDeltas() {
        return deltas;
    }


    /**
     * Sets the deltas value for this ReleaseDelta.
     * 
     * @param deltas
     */
    public void setDeltas(gov.nih.nlm.kss.models.meta.deltas.ConceptDelta[] deltas) {
        this.deltas = deltas;
    }


    /**
     * Gets the release value for this ReleaseDelta.
     * 
     * @return release
     */
    public java.lang.String getRelease() {
        return release;
    }


    /**
     * Sets the release value for this ReleaseDelta.
     * 
     * @param release
     */
    public void setRelease(java.lang.String release) {
        this.release = release;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ReleaseDelta)) return false;
        ReleaseDelta other = (ReleaseDelta) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.deltas==null && other.getDeltas()==null) || 
             (this.deltas!=null &&
              java.util.Arrays.equals(this.deltas, other.getDeltas()))) &&
            ((this.release==null && other.getRelease()==null) || 
             (this.release!=null &&
              this.release.equals(other.getRelease())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDeltas() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDeltas());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDeltas(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRelease() != null) {
            _hashCode += getRelease().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ReleaseDelta.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "ReleaseDelta"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deltas");
        elemField.setXmlName(new javax.xml.namespace.QName("", "deltas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://deltas.meta.models.kss.nlm.nih.gov", "ConceptDelta"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("release");
        elemField.setXmlName(new javax.xml.namespace.QName("", "release"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
