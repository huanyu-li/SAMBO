/**
 * StringInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.concept;

public class StringInfo  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private gov.nih.nlm.kss.models.meta.concept.StringSource[] SS;

    private java.lang.String STR;

    private java.lang.String STT;

    private java.lang.String SUI;

    public StringInfo() {
    }

    public StringInfo(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.models.meta.concept.StringSource[] SS,
           java.lang.String STR,
           java.lang.String STT,
           java.lang.String SUI) {
        super(
            key,
            performanceMode);
        this.SS = SS;
        this.STR = STR;
        this.STT = STT;
        this.SUI = SUI;
    }


    /**
     * Gets the SS value for this StringInfo.
     * 
     * @return SS
     */
    public gov.nih.nlm.kss.models.meta.concept.StringSource[] getSS() {
        return SS;
    }


    /**
     * Sets the SS value for this StringInfo.
     * 
     * @param SS
     */
    public void setSS(gov.nih.nlm.kss.models.meta.concept.StringSource[] SS) {
        this.SS = SS;
    }


    /**
     * Gets the STR value for this StringInfo.
     * 
     * @return STR
     */
    public java.lang.String getSTR() {
        return STR;
    }


    /**
     * Sets the STR value for this StringInfo.
     * 
     * @param STR
     */
    public void setSTR(java.lang.String STR) {
        this.STR = STR;
    }


    /**
     * Gets the STT value for this StringInfo.
     * 
     * @return STT
     */
    public java.lang.String getSTT() {
        return STT;
    }


    /**
     * Sets the STT value for this StringInfo.
     * 
     * @param STT
     */
    public void setSTT(java.lang.String STT) {
        this.STT = STT;
    }


    /**
     * Gets the SUI value for this StringInfo.
     * 
     * @return SUI
     */
    public java.lang.String getSUI() {
        return SUI;
    }


    /**
     * Sets the SUI value for this StringInfo.
     * 
     * @param SUI
     */
    public void setSUI(java.lang.String SUI) {
        this.SUI = SUI;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof StringInfo)) return false;
        StringInfo other = (StringInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.SS==null && other.getSS()==null) || 
             (this.SS!=null &&
              java.util.Arrays.equals(this.SS, other.getSS()))) &&
            ((this.STR==null && other.getSTR()==null) || 
             (this.STR!=null &&
              this.STR.equals(other.getSTR()))) &&
            ((this.STT==null && other.getSTT()==null) || 
             (this.STT!=null &&
              this.STT.equals(other.getSTT()))) &&
            ((this.SUI==null && other.getSUI()==null) || 
             (this.SUI!=null &&
              this.SUI.equals(other.getSUI())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getSS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSTR() != null) {
            _hashCode += getSTR().hashCode();
        }
        if (getSTT() != null) {
            _hashCode += getSTT().hashCode();
        }
        if (getSUI() != null) {
            _hashCode += getSUI().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(StringInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SS");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringSource"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STR");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "STT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
