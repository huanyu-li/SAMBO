/**
 * TermId.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.meta.concept;

public class TermId  extends gov.nih.nlm.kss.models.KSObj  implements java.io.Serializable {
    private java.lang.String LAT;

    private java.lang.String LUI;

    private gov.nih.nlm.kss.models.meta.concept.StringInfo[] stringInfos;

    public TermId() {
    }

    public TermId(
           java.lang.String key,
           boolean performanceMode,
           java.lang.String LAT,
           java.lang.String LUI,
           gov.nih.nlm.kss.models.meta.concept.StringInfo[] stringInfos) {
        super(
            key,
            performanceMode);
        this.LAT = LAT;
        this.LUI = LUI;
        this.stringInfos = stringInfos;
    }


    /**
     * Gets the LAT value for this TermId.
     * 
     * @return LAT
     */
    public java.lang.String getLAT() {
        return LAT;
    }


    /**
     * Sets the LAT value for this TermId.
     * 
     * @param LAT
     */
    public void setLAT(java.lang.String LAT) {
        this.LAT = LAT;
    }


    /**
     * Gets the LUI value for this TermId.
     * 
     * @return LUI
     */
    public java.lang.String getLUI() {
        return LUI;
    }


    /**
     * Sets the LUI value for this TermId.
     * 
     * @param LUI
     */
    public void setLUI(java.lang.String LUI) {
        this.LUI = LUI;
    }


    /**
     * Gets the stringInfos value for this TermId.
     * 
     * @return stringInfos
     */
    public gov.nih.nlm.kss.models.meta.concept.StringInfo[] getStringInfos() {
        return stringInfos;
    }


    /**
     * Sets the stringInfos value for this TermId.
     * 
     * @param stringInfos
     */
    public void setStringInfos(gov.nih.nlm.kss.models.meta.concept.StringInfo[] stringInfos) {
        this.stringInfos = stringInfos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TermId)) return false;
        TermId other = (TermId) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.LAT==null && other.getLAT()==null) || 
             (this.LAT!=null &&
              this.LAT.equals(other.getLAT()))) &&
            ((this.LUI==null && other.getLUI()==null) || 
             (this.LUI!=null &&
              this.LUI.equals(other.getLUI()))) &&
            ((this.stringInfos==null && other.getStringInfos()==null) || 
             (this.stringInfos!=null &&
              java.util.Arrays.equals(this.stringInfos, other.getStringInfos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLAT() != null) {
            _hashCode += getLAT().hashCode();
        }
        if (getLUI() != null) {
            _hashCode += getLUI().hashCode();
        }
        if (getStringInfos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getStringInfos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getStringInfos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TermId.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "TermId"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LAT");
        elemField.setXmlName(new javax.xml.namespace.QName("", "LAT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LUI");
        elemField.setXmlName(new javax.xml.namespace.QName("", "LUI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stringInfos");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stringInfos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://concept.meta.models.kss.nlm.nih.gov", "StringInfo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
