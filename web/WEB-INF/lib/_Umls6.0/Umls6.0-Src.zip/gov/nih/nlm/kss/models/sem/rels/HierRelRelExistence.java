/**
 * HierRelRelExistence.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.kss.models.sem.rels;

public class HierRelRelExistence  extends gov.nih.nlm.kss.models.KSObject  implements java.io.Serializable {
    private java.lang.String LHSSemRel;

    private java.lang.String RHSSemRel;

    private int exists;

    private java.lang.String relation;

    public HierRelRelExistence() {
    }

    public HierRelRelExistence(
           java.lang.String key,
           boolean performanceMode,
           gov.nih.nlm.kss.query.UMLSKSRequest queryInput,
           java.lang.String release,
           java.lang.String LHSSemRel,
           java.lang.String RHSSemRel,
           int exists,
           java.lang.String relation) {
        super(
            key,
            performanceMode,
            queryInput,
            release);
        this.LHSSemRel = LHSSemRel;
        this.RHSSemRel = RHSSemRel;
        this.exists = exists;
        this.relation = relation;
    }


    /**
     * Gets the LHSSemRel value for this HierRelRelExistence.
     * 
     * @return LHSSemRel
     */
    public java.lang.String getLHSSemRel() {
        return LHSSemRel;
    }


    /**
     * Sets the LHSSemRel value for this HierRelRelExistence.
     * 
     * @param LHSSemRel
     */
    public void setLHSSemRel(java.lang.String LHSSemRel) {
        this.LHSSemRel = LHSSemRel;
    }


    /**
     * Gets the RHSSemRel value for this HierRelRelExistence.
     * 
     * @return RHSSemRel
     */
    public java.lang.String getRHSSemRel() {
        return RHSSemRel;
    }


    /**
     * Sets the RHSSemRel value for this HierRelRelExistence.
     * 
     * @param RHSSemRel
     */
    public void setRHSSemRel(java.lang.String RHSSemRel) {
        this.RHSSemRel = RHSSemRel;
    }


    /**
     * Gets the exists value for this HierRelRelExistence.
     * 
     * @return exists
     */
    public int getExists() {
        return exists;
    }


    /**
     * Sets the exists value for this HierRelRelExistence.
     * 
     * @param exists
     */
    public void setExists(int exists) {
        this.exists = exists;
    }


    /**
     * Gets the relation value for this HierRelRelExistence.
     * 
     * @return relation
     */
    public java.lang.String getRelation() {
        return relation;
    }


    /**
     * Sets the relation value for this HierRelRelExistence.
     * 
     * @param relation
     */
    public void setRelation(java.lang.String relation) {
        this.relation = relation;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HierRelRelExistence)) return false;
        HierRelRelExistence other = (HierRelRelExistence) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.LHSSemRel==null && other.getLHSSemRel()==null) || 
             (this.LHSSemRel!=null &&
              this.LHSSemRel.equals(other.getLHSSemRel()))) &&
            ((this.RHSSemRel==null && other.getRHSSemRel()==null) || 
             (this.RHSSemRel!=null &&
              this.RHSSemRel.equals(other.getRHSSemRel()))) &&
            this.exists == other.getExists() &&
            ((this.relation==null && other.getRelation()==null) || 
             (this.relation!=null &&
              this.relation.equals(other.getRelation())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLHSSemRel() != null) {
            _hashCode += getLHSSemRel().hashCode();
        }
        if (getRHSSemRel() != null) {
            _hashCode += getRHSSemRel().hashCode();
        }
        _hashCode += getExists();
        if (getRelation() != null) {
            _hashCode += getRelation().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HierRelRelExistence.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://rels.sem.models.kss.nlm.nih.gov", "HierRelRelExistence"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LHSSemRel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "LHSSemRel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RHSSemRel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RHSSemRel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exists");
        elemField.setXmlName(new javax.xml.namespace.QName("", "exists"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
